#! /bin/bash

SRC=$1
DEST=$2
cp $SRC/include/net/sock.h $DEST
cp $SRC/net/ipv4/af_inet.c $DEST
cp $SRC/include/linux/socket.h $DEST
cp $SRC/include/asm-i386/socket.h $DEST/asmumarchsocket.h
cp $SRC/net/netsyms.c $DEST
cp $SRC/net/ipv4/Makefile $DEST
cp $SRC/net/ipv4/Config.in $DEST

