/* dcp.c - an implemenetation of the DCCP protocol			     */
/* ------------------------------------------------------------------------- */
/*  Copyright (c) 2005 The University of Waikato, Hamilton, New Zealand.

    This code has been developed by the University of Waikato WAND
    research group. For further information please see http://www.wand.net.nz/

    This code has been based on the work of other developers:
    	Patrick McManus (mcmanus@ducksong.com)
	Lulea Univeristy of Technology

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.		     */
/* ------------------------------------------------------------------------- */

#include <linux/config.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/skbuff.h>
#include <linux/netdevice.h>
#include <linux/in.h>
#include <linux/if_arp.h>
#include <linux/init.h>
#include <net/checksum.h>

#include <net/sock.h>
#include <net/ip.h>
#include <net/protocol.h>
#include <net/inet_common.h>

#include <asm/semaphore.h>
#include <linux/spinlock.h>
#include <linux/timer.h>
#include <linux/delay.h>
#include <linux/poll.h>
#include <linux/mm.h>

#include <linux/vmalloc.h> //vmalloc ;)

/* obviously, for kmalloc */ 
/* for struct file_operations, register_chrdev() */ 
#include <linux/fs.h>

/* this header files wraps some common module-space operations ... 
   here we use mem_map_reserve() macro */ 
#include <linux/wrapper.h> 

/* needed for virt_to_phys() */ 
#include <asm/io.h> // virt_to_phys()

#define DCCP_STAT_EXTERN

#ifdef MODULE

#include "compat.h"
#include "queue.h"
#include "dccp_tfrc.h"
#include "dccp_tfrc_lookup.h"
#include "dccp_tfrc_print.h"
#else

#include "dcp_super.h"

#endif /* MODULE */

//#define KERNEL_ASSERT_ON
#ifdef KERNEL_ASSERT_ON
#define KERNEL_ASSERT(expr)	if (!(expr)) 				   
printk(KERN_DEBUG "KASSERT: %s:%d - Assertion failed! (%s) ",	   __FILE__, __LINE__, #expr)
#else
#define KERNEL_ASSERT(expr)
#endif



#include <linux/config.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/sched.h>
#include <linux/kernel.h>

#include <linux/time.h>
#include <linux/timer.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/semaphore.h>


#include <net/sock.h>


//#include <sys/param.h>
//#include <sys/systm.h>
//#include <sys/domain.h>
//#include <sys/kernel.h>
//#include <sys/lock.h>
//#include <sys/malloc.h>
//#include <sys/mbuf.h>
//#include <sys/proc.h>
//#include <sys/protosw.h>
//#include <sys/signalvar.h>
//#include <sys/socket.h>
//#include <sys/socketvar.h>
//#include <sys/sx.h>
//#include <sys/sysctl.h>
//#include <sys/syslog.h>

//#include <net/if.h>
//#include <net/route.h>

//#include <netinet/in.h>
//#include <netinet/in_systm.h>
//#include <netinet/in_pcb.h>
//#include <netinet/in_var.h>

//#include <netinet/ip.h>
//#include <netinet/ip_icmp.h>
//#include <netinet/icmp_var.h>
//#include <netinet/ip_var.h>
//#include <netinet/dccp.h>
//#include <netinet/dccp_var.h>

#define LOG_INFO 1
#define DCP_DEBUG 10 

//outcommented by BJORN
//#define TFRCDEBUG



//#define TFRCDEBUGTIMERS



/*#define NOTFRCSENDER
#define NOTFRCRECV*/
//#define TFRC_DEBUG((LOG_INFO, (printk(

#ifdef TFRCDEBUG
#define TFRC_DEBUG(args) do_weird_debug args
#else
#define TFRC_DEBUG(args)
#endif


#ifdef TFRCDEBUGTIMERS
#define TFRC_DEBUG_TIME(args) log args
#else
#define TFRC_DEBUG_TIME(args)
#endif

/* Timeval operations */
const struct timeval delta_half = {0,TFRC_OPSYS_TIME_GRAN/2};

/*
 * Half time value struct (accurate to +- 0.5us)
 * args:  tvp  -  pointer to timeval structure
 * Tested u:OK
 */
#define HALFTIMEVAL(tvp) \
do { \
	if((tvp)->tv_sec & 1) \
		(tvp)->tv_usec += 1000000; \
			(tvp)->tv_sec = (tvp)->tv_sec >> 1; \
			(tvp)->tv_usec = (tvp)->tv_usec >> 1; \
}while(0)

/* Sender side */

/* Calculate new t_ipi (inter packet interval) by
 *    t_ipi = s/X_inst; 
 * args:  ccbp - pointer to sender ccb block
 * Tested u:OK - Note: No check for x=0 -> t_ipi ={0xFFF...,0xFFF}
 */
#define CALCNEWTIPI(ccbp)                              \
do{                                            \
	ccbp->t_ipi.tv_sec = (long) ( ((double) (ccbp->s)) / (ccbp->x) );                    \
		ccbp->t_ipi.tv_usec = (long) (( ((double)(ccbp->s)) / (ccbp->x) - ccbp->t_ipi.tv_sec)*((double)1000000.0));   \
}while (0)

/* Calculate new delta by 
 *    delta = min(t_ipi/2, t_gran/2);
 * args: ccbp - pointer to sender ccb block 
 * Tested u:OK
 */
#define CALCNEWDELTA(ccbp)                             \
do {                                          \
	ccbp->delta = delta_half;                  \
		if (ccbp->t_ipi.tv_sec == 0 && ccbp->t_ipi.tv_usec < TFRC_OPSYS_TIME_GRAN){     \
			ccbp->delta = ccbp->t_ipi;              \
				HALFTIMEVAL(&(ccbp->delta));            \
		}                                          \
} while (0)



/******************************************************/
/* things that could be useful in a userspace program */

#define SOCK_DCCP        6 		/* for api purposes */

#define SOL_DCCP            269  
#define SO_HANDSHAKE_DATA          1	/* sockopt */
#define SO_ALLOW_HANDSHAKE_DATA    2

/* the following is an optional struct for connect() or bind()..
   if a normal sockaddr_in is used instead, a service of 0 is assumed. 
   accept() returns normal sockaddr_in's */

/* service names should be supplied in network byte order */

struct sockaddr_dcp
{
	struct sockaddr_in in;
	unsigned int service;
};

/******************************************************/

#define DCCP_PROTO 33

#define DCP_INITIAL_CWND      3
#define DCP_TIMEOUT          (2*HZ)	 	/* 2 second */
#define DCP_MAX_TRIES         6	         /* really 6-1 = 5 */
#define DCP_TIMEWAIT_LEN     (30*HZ)     /* 30 seconds */
#define DCP_MIN_RTT          (HZ >> 3)   /* 1/8 of a second, that's 12 jiffies on i386 */
#define DCP_RESPOND_TIMEOUT  (15*HZ)
#define MAX_DCP_REQUEST_SZ    284
#define DCP_NUMDUPACKS        3

/* states */

#define DCP_REQUESTING    1
#define DCP_OPEN          2
#define DCP_LISTENING     3
#define DCP_RESPOND       4
#define DCP_HALF_CLOSE    5
#define DCP_TIMEWAIT      6
#define DCP_CLOSED        7		/* same as TCP_CLOSE, don't change value */

#define TYPE_REQUEST     0x00
#define TYPE_RESPONSE    0x10
#define TYPE_DATA        0x20
#define TYPE_ACK         0x30
#define TYPE_DATAACK     0x40
#define TYPE_CLOSEREQ    0x50
#define TYPE_CLOSE       0x60
#define TYPE_RESET       0x70
#define TYPE_MOVE        0x80
#define TYPE_INVALID     0xF0

#define DCP_OPT_PAD      00
#define DCP_OPT_DISCARD  01
#define DCP_OPT_IGNORED  32
#define DCP_OPT_ASK      33
#define DCP_OPT_CHOOSE   34
#define DCP_OPT_ANSWER   35
#define DCP_OPT_ICOOKIE  36
#define DCP_OPT_ACKV0    37
#define DCP_OPT_ACKV1    38
#define DCP_OPT_RBDROP   39
#define DCP_OPT_TS       40
#define DCP_OPT_TS_ECHO  41
#define DCP_OPT_MOBILE   42
#define DCP_OPT_BCD      43
#define DCP_OPT_WINCOUNT 128       /* Used for DCCP CCID 3 */
#define DCP_OPT_ELAPTIME 193
#define DCP_OPT_LOSSEVENT 192
#define DCP_OPT_RECEIVERATE 194    /* END USED FOR DCCP CCID 3 */
#define DCP_OPT_LOSSINTER 195      /* included for completeness will not be used */


#define DCP_OPT_STATE_KNOWN  1
#define DCP_OPT_STATE_ASKING 2
#define DCP_OPT_STATE_ANS    3

#define DCP_NEG_TYPE_CC        1
#define DCP_NEG_TYPE_ECN       2
#define DCP_NEG_TYPE_ACKRATIO  3
#define DCP_NEG_TYPE_ACKVECTOR 4

#define WHOAMI_UNKNOWN 0
#define WHOAMI_CLIENT  1
#define WHOAMI_SERVER  2
#define WHOAMI_BINDER  3

#define FLAG_ACKSCHED               0x01
#define FLAG_ALLOW_LOADED_HANDSHAKE 0x02

#define DCCP_PORT_BASE  1025
#define DCCP_PORT_RANGE 16000
#define DCCP_PORT_HI    (DCCP_PORT_BASE + DCCP_PORT_RANGE)

#define DCP_SK_HASH_SZ 863

#define INIT_VECTOR_SIZE 512 /* keep as a multiple of 8!! */
/* datatypes */

/* Used to store an outgoing packet in the right format for ip_build_xmit
 *
 * Fields:	h - the DCCP header (including headers) of the packet
 * 		kdb - the handshake data (for connection handshake packets only),  // kdb stands for Kernel Data Block?? - SHANE
 * 		hl - the length of the DCCP header
 * 		kdbl - the length of the handshake data
 * 		iov - the io vector containing the data portion of the packet (except when we're in connection handshake)
 * 		check - the checksum for the future IP packet? We set it to zero as checksum calc for IP will come later
 * */
struct build_t
{
	unsigned char *h,*kdb;
	u16 hl,kdbl;
	struct iovec *iov;
	u32 check;
};

/* Describes a DCCP socket
 *
 * Fields:	sk - the actual socket structure itself
 * 		locala - the address of the local end of the connection
 * 		remotea - the address of the remote end of the connection
 * 		svc - the service code
 * 		lp - the local port number for the connection
 * 		rp - the remote port number for the connection
 * 		p - the previous entry in the DCCP socket list
 * 		n - the next entry in the DCCP socket list
 * */
struct dccp_sk_list_t
{
	struct sock *sk;
	u32 locala, remotea, svc;
	u16 lp, rp;
	struct dccp_sk_list_t *p, *n;
};

/* Used to represent an outgoing ACK that is acknowledging previously received ACKs, rather than incoming data
 *
 * Fields:	localseq - the sequence number of the outgoing ACK
 * 		ackthru - the acknowledgement number of the outgoing ACK
 * 		next - the next member of the clist
 * */
struct ack_collapse_t
{
	u32 localseq, ackthru;
	struct ack_collapse_t *next;
};



/* global allocations - mostly counters and locks */
static struct dccp_sk_list_t *dccp_sk_hash[DCP_SK_HASH_SZ];
static spinlock_t dccp_port_lock;
static spinlock_t dccp_reset_lock;
static u16 dccp_port;
static rwlock_t dccp_table_lock[16];
static unsigned char dccp_port_map[DCCP_PORT_RANGE/8+1];
static kmem_cache_t *dccp_slab, *dccp_slab_sk, *dccp_slab_ack;

/* *sk used for resets when no connection exists */
static struct inode reset_inode;
static struct socket *reset_socket = &reset_inode.u.socket_i;
static struct tq_struct itask;

/* prototypes */

static void dccp_reset (struct sock *sk, u32 reason);
static void dccp_send_close (struct sock *sk, unsigned char close_or_closeR);
static int unregister_dccp_sk (struct sock *sk);
static void dccp_port_release (u16 i);
static int dccp_port_claim (u16 i);
static inline void dccp_update_ackn (unsigned int *t, struct sk_buff *skb);
static inline void new_rtt_sample (struct dcp_opt *tp, u16 M);
static int credit_pkt (struct sock *sk, u32 sn);
static inline int increment_ackvector (struct sock *sk, u32 sn);
static u32 dccp_whatis_ackn (struct sk_buff *skb);
static void dccp_write_24 (u32 *s, char *d, int inc);
static inline unsigned char dcp_write_ndp (u16 *ndp, int inc);
static unsigned char *dccp_generate_ackvector (struct sock *sk, int *l);
static int dccp_getfrag(const void *p, char * to, unsigned int offset, unsigned int fraglen) ;
static inline int  check_clist (struct dcp_opt *tp, u32 sn);
void inet_sock_release(struct sock *sk);
static void dccp_half_closed (void *vsk);
static u16 dccp_parse_option (struct sk_buff *skb, unsigned char option,u16 *ics);
static void generic_option_negotiation (struct dcp_opt *tp);
static inline void rcvr_ratio_inbounds (struct dcp_opt *tp);
static inline unsigned char value_in_ackvector (struct sock *sk, u32 sn);
static void  dccp_schedule_ack (void *vsk);

/* External declarations */
extern int dccp_get_option(char *, int, int, char *,int);

/* Forward declarations */
void  tfrc_time_no_feedback(void *ccb);
void  tfrc_time_send(void *ccb);
void  tfrc_set_send_timer(struct tfrc_send_ccb *cb, struct timeval t_now);
void  tfrc_updateX(struct tfrc_send_ccb *cb, struct timeval t_now);
double tfrc_calcX(u_int16_t s, u_int32_t R, double p);
void  tfrc_send_term(void *ccb);
/* Forward declarations */
double tfrc_calcImean(struct tfrc_recv_ccb *cb);
void tfrc_recv_send_feedback(struct tfrc_recv_ccb *cb);
int tfrc_recv_add_hist(struct tfrc_recv_ccb *cb, struct r_hist_entry *packet);
void tfrc_recv_detectLoss(struct tfrc_recv_ccb *cb);
u_int32_t tfrc_recv_calcFirstLI(struct tfrc_recv_ccb *cb);
void tfrc_recv_updateLI(struct tfrc_recv_ccb *cb, long seq_loss, u_int8_t win_loss);
void *tfrc_recv_init(struct dccpcb *pcb);
void *tfrc_send_init(struct dccpcb* pcb);
void tfrc_send_packet_recv(void *ccb, char *options, int optlen);
void tfrc_recv_packet_recv(void *ccb, char *options, int optlen);
void tfrc_send_free(void *ccb);
void tfrc_recv_free(void *ccb);
int tfrc_send_packet(void *ccb, long datasize);
void tfrc_send_packet_sent(void *ccb, int moreToSend, long datasize);

/* Weights used to calculate loss event rate */
const double tfrc_recv_w[] = {1, 1, 1, 1, 0.8, 0.6, 0.4, 0.2};

/* macros */


/* Find a data packet in history
 * args:  cb - ccb of receiver
 *        elm - pointer to element (variable)
 *        num - number in history (variable)
 * returns:  elm points to found packet, otherwise NULL
 * Tested u:OK
 */
#define TFRC_RECV_FINDDATAPACKET(cb,elm,num) \
do{ \
	elm = STAILQ_FIRST(&((cb)->hist)); \
		while((elm) != NULL){ \
			if((elm)->type == DCCP_TYPE_DATA || (elm)->type == DCCP_TYPE_DATAACK) \
				(num)--; \
					if(num == 0) \
						break; \
							elm = STAILQ_NEXT((elm), linfo); \
		} \
} while (0)

/* Find next data packet in history
 * args:  cb - ccb of receiver
 *        elm - pointer to element (variable)
 * returns:  elm points to found packet, otherwise NULL
 * Tested u:OK
 */
#define TFRC_RECV_NEXTDATAPACKET(cb,elm) \
do{ \
	if(elm != NULL){ \
		elm = STAILQ_NEXT(elm, linfo); \
			while((elm) != NULL && (elm)->type != DCCP_TYPE_DATA && (elm)->type != DCCP_TYPE_DATAACK){ \
				elm = STAILQ_NEXT((elm), linfo); \
			} \
	} \
} while (0)


#define DCP_DATA_EVENT         (tp->rcvq_h != tp->rcvq_t)
#define DCP_DATA_EVENT_TO      ((tp->rcvq_h != tp->rcvq_t) || tp->timer_expired)
#define DCP_DATA_EVENT_OPEN    ((tp->rcvq_h != tp->rcvq_t) || (sk->state != DCP_OPEN) || tp->shake_defer)

#define wrapdec_24(i) ((!i) ? i=0xffffff : --i)
//#define wrapdec_24(i) ((!i) ? 0xffffff : --i)
//#define wrapdec_24(i) if (i >0) i--; else i=0xffffff;  

/* code */

/* Gets an option from a provided option list and copies it into a buffer.
 * Designed for use with TFRC as standard DCCP options are dealt with in other functions, i.e. generic_option_parse()
 *
 * Parameters:	options - the options list
 * 		optlen - the length of the options list
 * 		type - the option id that is being looked for
 * 		buffer - the buffer to copy the option into
 * 		buflen - the length of the buffer
 * */
int dccp_get_option(char *options, int optlen, int type, char *buffer, int buflen)
{

	int i, j, size;
	u_int8_t t;
   
#if DCP_DEBUG > 0
	printk("TFRC reckons it wants to get an OPTION\n");
#endif

	for (i=0; i < optlen; ) {
		t = options[i++];
		// options with codes less than 32 are only one byte
		if(t >= 32){		  
			size = options[i++] - 2;
			if (t == type) {
				// buffer would overflow!
				if(size > buflen)
					return 0;
				// copying option code into the buffer
				for (j=0; j<size; j++)
					buffer[j] = options[i++];
				return size;
			}
			i += size;
		}
	}
	/* If we get here the option was not found */

	return 0;
}

/* Adds an option to the option list.
 * Used by TFRC to append TFRC-specific options. Standard DCCP options are dealt with in other functions
 *
 * Parameters:	tp - the dcp_opt structure describing the current connection
 * 		type - the type of option to append
 * 		option - the option data
 * 		optlen - the length of the option data
 * */
int  dccp_add_option(struct dcp_opt *tp, u_int8_t type, char *option , u_int8_t optlen){
	/* NOTE: Just in case you're confused, the +2 used throughout this function is because optlen does
	 * not include the option type and size bytes, just the data. */
	
	spin_lock (&tp->rsem);   //lock this for the length feild to avoid race conditions
   
#if DCP_DEBUG > 0
	printk("TFRC reckons it wants to append an OPTION %i\n",type);
#endif
   	// making sure we've got space to add the option
	if (tp->opt_a_sz + optlen +2 > DCP_OPTASZ)
	{
#if DCP_DEBUG > 2 
		printk("DCCP run out of space for %i len(%i) using %d of %d\n",type,optlen, tp->opt_a_sz, DCP_OPTASZ);

#endif
      //shuldent spinlock be released befor return? I try, BJORN.
      spin_unlock(&tp->rsem);
		return 1;
	}
	tp->opt_append[tp->opt_a_sz++] = type;
	tp->opt_append[tp->opt_a_sz++] = optlen+2;
	memcpy(&tp->opt_append[tp->opt_a_sz],option,optlen);
	tp->opt_a_sz+=optlen; //+2 here creates a DOS attack that takes out the other side and ethereal. NICE..
	// so is the above line wrong then??? - SHANE
	spin_unlock (&tp->rsem);	
	//This should be easy enough!
	return 0;
}

//ASSUME LOCK HERE MOFO~!

/* Schedules an ACK if necessary under TFRC
 *
 * Parameters:	tp - the dcp_opt structure describing the connection
 * 		extra - unused
 * */
int dccp_output(register struct dcp_opt *tp, unsigned char extra )
{

#if DCP_DEBUG > 0
	printk("TFRC reckons it wants to SEND a packet\n");
#endif
	// if an ack has been scheduled, start arranging for one
	if((!(tp->flags & FLAG_ACKSCHED)))
	{

#if DCP_DEBUG > 0
		printk("TFRC did schedule an ack\n");
#endif

		//	tp->atask.data =sk;
		tp->flags |= FLAG_ACKSCHED;
		schedule_task(&tp->atask);
	}
	//Told mcmanaus to schedule that sucker.

	//dccp_schedule_ack_locked(tp, sk); //HACKQ! atask hopefully holds the socket descriptor, if it doesn't it was like that when i found it....

	//	wake_up (&tp->newdata);  //TODO: what does this actullay achieve, i just copied it from dccp_schedule_ack..
	KERNEL_ASSERT(0);

	return 0;
}

/* Converts the packet buffer into a build_t structure - used for packets not involved with the connection handshake
 * 
 * Parameters:	b - a previously declared build_t structure
 * 		h - the packet buffer representing the header of the packet to be transmitted
 * 		hl - the length of the packet header
 * 		iov - the data portion of the packet
 * */
inline static int mkbuildt (struct build_t *b, unsigned char *h, u16 hl, struct iovec *iov)
{
	b->h = h;
	b->hl = hl;
	b->iov = iov;
	b->check = 0;
	b->kdb= NULL;			/* occasionally (on handshake) we'll have data not from an iovec,
							   but from a kernel buffer.. */
	b->kdbl =0;
	return 0;
}

/* Converts the packet buffer into a build_t structure - used for connection handshake packets 
 *
 * Parameters	b - a previously declared build_t structure
 * 		h - the packet buffer representing the header of the packet to be transmitted 
 * 		hl - the length of the packet header
 * 		kdb - the data portion of the packet
 * 		kbdl - the length of the data portion of the packet
 * */
inline static int mkbuildt_k (struct build_t *b, unsigned char *h, u16 hl, unsigned char *kdb, int kdbl)
{
	b->h = h;
	b->hl = hl;
	b->iov = NULL;
	b->check = 0;
	b->kdb=kdb;
	b->kdbl =kdbl;
	return 0;
}

/* A hash function for sockets, based on the remote address, remote port and local port
 *
 * Parameters:	ra - the remote address for the connection that uses this socket
 * 		rp - the remote port for the connection that uses this socket
 * 		lp - the local port for the connection that uses this socket
 */
static inline u16 skhash (u32 ra, u16 rp, u16 lp)
{
	u32 t;

	t = ra * rp *lp + rp + lp +ra;
	return t % DCP_SK_HASH_SZ;
}

/* Finds a socket in the sock hashtable
 *
 * Parameters:	locala - the IP address of the local end of the connection, needed for matching
 * 		remotea - the IP address of the remote end of the connection, needed for hashing and matching
 * 		svc - the service code for the socket, needed for matching bound sockets
 * 		lp - the port used at the local end of the connection, needed for hashing and matching
 * 		rp - the port used at the remote end of the connection, needed for hashing and matching
 * 		ptype - the type of packet received, used to distinguish between bound and connected sockets
 * */
static struct sock *lookup_dccp_sk ( u32 locala, u32 remotea, u32 svc,
		u16 lp, u16 rp, unsigned char ptype)
{
	struct dccp_sk_list_t *p, *el, *dccp_sk_list;
	u16 n,nl;

	/* bound sockets (not connected) have a zeroed ra and rport */
	el = NULL;

	// if the packet is a request then we aren't connected yet, use 0 for ra and rp
	if (ptype == TYPE_REQUEST)
		n = skhash(0,0,lp);
	else
		n = skhash(remotea,rp,lp);

	nl = n & 0xF;

	read_lock (dccp_table_lock+nl);	
	dccp_sk_list = dccp_sk_hash[n];

	// cycle through the list of sockets matching the skhash, looking for a socket whose attributes match
	// the ones given as parameters
	if (ptype == TYPE_REQUEST)
	{
		/*printk ("looking for request in chain %d - %X %d %d\n",n,locala, ntohs(lp),ntohs(rp)); */
		
		for (p = dccp_sk_list;  (p && (!el)); p = p->n)
		{
			// ra and rp cannot be set because we aren't connected!
			if  ( (!p->remotea) && (!p->rp) && (p->lp == lp) && (p->svc == svc) &&
					((!locala) || (locala == p->locala)))
				el = p;		
			/*printk ("%p %X %d %X %d %X, %X %d %X %d %X\n",el,
			  remotea, ntohs(rp), locala, ntohs(lp), svc,
			  p->remotea, ntohs(p->rp), p->locala, ntohs(p->lp), p->svc); */
		}
	}
	else
	{
		for (p = dccp_sk_list;  (p && (!el)); p = p->n)
			if  ((remotea == p->remotea) && (lp == p->lp) && (rp == p->rp)     /* normal connected case  */
					&& ((!locala) || (locala == p->locala))) /* svc isn't considerd here */
				el = p;
	}

	read_unlock (dccp_table_lock+nl);

	// return NULL if we didn't find a matching socket
	return el ? el->sk : NULL;
}
/*
   inline static void output_stats( struct sock *sk;)
   {
#if DCP_DEBUG > 2
struct dcp_opt *tp;

tp = &(sk->tp_pinfo.tp_dcp);

printk("ackr:%d\trtt:%d\tcwnd:%d\trcvr:%d\twndcount:%djiffies:%ld\n", tp->ackratio, tp->rtt, tp->cwnd,tp->rcvr_ratio,tp->wndcount,jiffies);



#endif
}
*/

/* Translates the DCCP header information into local variables  
 *
 * Parameters: 	skb - the sk_buff containing the DCCP packet
 * 		la - the location IP address 
 * 		ra - the remote IP address 
 * 		svc - the service code
 * 		lp - the location port
 * 		rp - the remote port
 * 		*/
static unsigned char parse_dccp_pkt (struct sk_buff *skb,
		u32 *la, u32 *ra, u32 *svc,
		u16 *lp, u16 *rp)
{
	u32 t;
	u16 rcheck,tc,lcheck;
	unsigned char cslen,hl,rv;

	if (skb->len < 12)
		return TYPE_INVALID;

	// saving a copy of the checksum and then zeroing it for computation
	memcpy (&rcheck,skb->data+10,2);
	memset (skb->data+10,0,2);	/* zero it for computation */

	// getting checksum coverage field
	cslen = skb->data[9] & 0x0F;

	/* OK, I think the processing of cslen here is not up to date with the latest specs
	 * IF cslen is 0 then checksum covers the whole packet
	 * Otherwise the checksum covers cslen - 1 * 4 bytes of the application data, plus all the headers, options etc
	 * IF cslen - 1 * 4 is greater than the length of the application data, then the packet must be ignored.
	 * - SHANE
	 */
	if (cslen==15)
		tc = skb->len;
	else
	{
		// hl = header length
		hl = skb->data[8];
		tc = ((int)cslen+ (int)hl)  *4;
		tc = (tc < skb->len) ? tc : skb->len;
	}
	// checksum is broken1
	t = 0;
	t = csum_partial (skb->data,tc,t);
	lcheck = csum_fold (t);

	memcpy (skb->data+10,&rcheck,2); /* put it back */

	if (rp) memcpy (rp,skb->data,2);
	if (lp) memcpy (lp,skb->data+2,2);

	// rv = packet type
	rv = skb->data[4] & 0xF0;

	if (lcheck != rcheck)
	{

#if DCP_DEBUG > 0
		printk ("dccp check-mismatch (%d: type %d) over %d of %d: sending %X, Rcv %X\n",
				ntohs (*lp),rv,
				tc,skb->len,rcheck,lcheck);
#endif

		return TYPE_INVALID; 
	}



	// svc = service code
	if (rv == TYPE_REQUEST)
	{
		if (skb->len < 16)
			return TYPE_INVALID;
		if (svc) 
			memcpy (svc,skb->data+12,4); 
	}
	else
		if (svc) 
			*svc = 0;

	if (ra) 
		*ra =  skb->nh.iph->saddr;
	if (la) 
		*la = skb->nh.iph->daddr;

	return rv;

}

/* Asks for the socket to send a CLOSE packet. Called via tp->ctask.
 *
 * Parameters:	vsk - the socket which must send the CLOSE packet
 */
static void dccp_safe_close (void *vsk)
{
	struct sock *sk = vsk;

	dccp_send_close (sk,TYPE_CLOSE);      /* send close */
	return;
}

/* Asks for the socket to send a RESET packet. Called via tp->rtask.
 *
 * Parameters:	sk - the socket which must send the CLOSE packet
 */
static void dccp_safe_reset (void *vsk)
{				/* we are only invoked by server side when a close or reset comes int */
	struct sock *sk = vsk;

	dccp_reset (sk,0);
	unregister_dccp_sk(sk);
	return;
}



/* Creates an ACK packet and sends it, as long as we've got too many unacked packets. Called via tp->atask.
 *
 * Parameters:	vsk - the socket on which the connection is taking place
 */
static void  dccp_schedule_ack (void *vsk)
{
	struct sock *sk = vsk;
	struct dcp_opt *tp;
	struct build_t b;
	unsigned char *pbuf,*ackv,*mt;
	struct ipcm_cookie ipc;
	struct rtable *rt;
	int ackvl,nma;

   spin_lock (&tp->rsem);	
	tp = &(sk->tp_pinfo.tp_dcp);
	nma =1;
	//spin_lock (&tp->rsem);	
#if DCP_DEBUG > 2
	printk ("acktimer\n"); 
#endif

	if ((sk->state == DCP_OPEN) && // we're due to send an ACK, according to the ACK vector
			(tp->unacked >= tp->ackratio))

	{
		ipc.oif = sk->bound_dev_if;
		ipc.opt = sk->protinfo.af_inet.opt;
		ipc.addr = sk->daddr;

		pbuf = kmem_cache_alloc (dccp_slab,GFP_ATOMIC);

		memcpy (pbuf,&sk->sport,2);
		memcpy (pbuf+2,&sk->dport,2);

		pbuf[4] = TYPE_ACK;	/* ack pkt, includes the 4 rsvd bits */


		pbuf[8] = 0x04;		/* header length - 4 32 bit words */

		pbuf[9] = dcp_write_ndp (&tp->ndp,1);	/* ndp=tp->ndp and cslen=15 */

		memset (pbuf+10,0,2);		/* checksum - starts at 0 for calc */

		pbuf[12] = 0;			/* reserved */
		tp->unacked = 0;		/* cause we're locked */

		dccp_write_24 (&tp->ackn, pbuf+13,0); 

		generic_option_negotiation (tp); /* cleaned out by genackvector */
		ackv =dccp_generate_ackvector (sk, &ackvl); /* keep before seqno++ */
		dccp_write_24 (&tp->seq, pbuf+5,1); /* incs sn for me */


		// if we have an ack vector to append
		if (ackvl)
		{
			pbuf[8] += ackvl /4;
			if ((ackvl + 16) > MAX_DCP_REQUEST_SZ) //if the ackvl is too long to fit in pbuf, then make pbuf bigger
			{
				nma = 0;
				//mt = kmalloc(ackvl+16,GFP_ATOMIC);
            mt = vmalloc(ackvl+16);
				memcpy (mt,pbuf,16);
				kmem_cache_free (dccp_slab,pbuf);
				pbuf = mt;
			}
		   memcpy (pbuf+16,ackv,ackvl);
		}

		// build and send our ACK
		ip_route_output(&rt, sk->daddr, sk->saddr,RT_CONN_FLAGS(sk) , ipc.oif);

		mkbuildt (&b, pbuf, 16+ackvl,NULL);
		ip_build_xmit (sk,dccp_getfrag, &b,16+ackvl,&ipc,rt,MSG_DONTWAIT); 

		if (nma)
			kmem_cache_free (dccp_slab,pbuf);
		else{
          vfree(pbuf);
			//kfree (pbuf);
         }

		//kfree (ackv);
      vfree(ackv);
	}

	// an ACK is no longer scheduled so update the flags
	tp->flags &= ~FLAG_ACKSCHED;
	spin_unlock (&tp->rsem);	

	wake_up (&tp->newdata);  
	return;
}




/* Closes the connection following the end of the TIMEWAIT state
 *
 * Parameters:	s - the socket which is to be closed
 */
static void *dcp_handle_timewait (unsigned long s)
{
	struct sock *sk;
	struct dcp_opt *tp;

	sk = (struct sock *)s;
	tp = &(sk->tp_pinfo.tp_dcp);

#if DCP_DEBUG > 1
	printk ("TIMEWAIT Complete\n");
#endif

	sk->state = DCP_CLOSED;
	unregister_dccp_sk (sk);  
	return NULL;
}

/*  Gets the sequence number from a given packet
 *
 *  Parameters:	skb - the sk_buff containing the packet
 */
static inline u32 whatis_seqno (struct sk_buff *skb)
{
	u32 c;

	/* the seq_no occupies three bytes so we need to do a little calculating to get the number */

	/* ackn is the highest serial # we've seen */
	c  = ((unsigned char) skb->data[5]) * 0x10000;
	c += ((unsigned char) skb->data[6]) * 0x100;
	c += ((unsigned char) skb->data[7]);
	return c;
}


/* Sets the ack number to match the sequence number of the received packet. The difference between the old ack number and the sequence
 * number must be less than 1001.
 *
 * Parameters:	t - the ack number to be updated
 * 		skb - the received packet containing the sequence number to update to
 */
static inline void dccp_update_ackn (unsigned int *t, struct sk_buff *skb)
{
	unsigned int c, diff;

	// getting the sequence number from the packet
	c = whatis_seqno (skb);

	/* we only want to update *t if c > *t (allowing for wraps),
	   but we've got to do it sanely.. if c is more than 1000 greater than
	   t we'll ignore - todo why +/- 1000 */

	if (c >= *t)
		diff = c - *t;
	else				/* wrap */
		diff = c + (0x1000000 - *t);

	if ((diff<=1000)  || (*t == 0xefffffff)||
			(0x1000000 - diff <= 1000)    )
		*t =c;

	return;
}

/* Sets the number of received but unacked packets to zero. Only should be used when opening or closing a connection.
 *
 * Parameters:	tp - the structure containing all the miscellaneous information regarding a half-connection
 */
static void inline clear_unacked (struct dcp_opt *tp)
{
	spin_lock (&tp->rsem);	
	tp->unacked = 0;
	spin_unlock(&tp->rsem);
	return;
}

/* Returns the number of bytes of header information prior to the option fields
 *
 * Parameters:	type - the type of packet we want to know the header length of
 */
static inline int optionoffset (unsigned char type)
{
	int p =0;
	//-TOM should type be &0xf0 ??
	/* Possibly, depends how much you trust the packet to have the reserved bits correctly set to zero. I'll do it anyway - SHANE */
	type = type & 0xF0;
	
	switch (type)
	{
		case TYPE_DATA:
			p = 12;
			break;

		case TYPE_REQUEST:
		case TYPE_RESPONSE:
		case TYPE_DATAACK:
		case TYPE_ACK:
		case TYPE_CLOSEREQ:
		case TYPE_CLOSE:
			p = 16;
			break;

		case TYPE_RESET:
			p = 20;
			break;

		case TYPE_MOVE:
			p = 28;
			break;
	}
	return p;
}

/* Checks to see if the given sequence number has been acknowledged - i.e. it is in the congestion window vector 
 * 
 * Parameters:	sk - the socket upon which the connection is taking place
 * 		sn - the sequence number being searched for in the congestion window
 */
static inline u32 value_in_cwndvector (struct sock *sk, u32 sn)
{				/* todo - this is a wildly inefficient way of doing this */
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	u32 gap;
	unsigned char *t;

	if (tp->cv_ts == tp->cv_hs)	/* empty */
		return 0;		/* missing */

	if (sn >= tp->cv_ts)
		gap = (sn - tp->cv_ts);
	else				/* sn has wrapped but ts hasn't */
		gap = (sn + (0x1000000 - tp->cv_ts));

	if (gap > tp->cv_sz) 
		return 0;

	t = tp->cv_tp + (gap*4);
	if (t >= (tp->cwndvector + (tp->cv_sz*4)))
		t -= (tp->cv_sz *4);	/* wrapped */

	return *( (u32 *) t);
}

/* Checks the Ack Vector buffer stored locally to see if any acknowledgements have been lost
 *
 * Parameters: 	sk - the socket that the connection uses
 * */
static int noackloss (struct sock *sk)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	/* csn = current sequence number */
	u32 csn;
	u16 v,rv;

	rv = 1;

	v = 0;
	// ackc_wsn is highest sequence number that has been checked for loss previously
	if (tp->ackc_wsn == 0x1000000)
		tp->ackc_wsn = tp->av_ts;

	
	// go backwards through ack vector until we get 3 received acks
	for (csn=tp->av_hs;
			((tp->ackc_wsn != csn) && (v < DCP_NUMDUPACKS));
			csn = wrapdec_24(csn))
		if (value_in_ackvector(sk,csn) != 3)
			v++;


	if (v==DCP_NUMDUPACKS)
	{
		// Do we have any unreceived acks following our three received acks?
		// If so, we have some ack loss
		while (tp->ackc_wsn != csn)
		{
			if (value_in_ackvector (sk,csn) == 3) /* missing */
			{
				rv = 0;
				break;
			}
			csn = wrapdec_24(csn);
		}
	}

	// I'm not 100% sure with this. I think ackc_wsn should be set to csn when we exit the for loop. There'll
	// be a little overlap, but the current method runs the risk of not detecting ack loss on packets that were
	// sent just prior to this function call - SHANE
	tp->ackc_wsn = tp->av_hs;

	return rv;
}

/* Changes flags to represent the fact that there may be room in the congestion window again
 *
 * Parameters:	sk - the socket which may now have space in its cwnd
 * */
static void dcp_writeable (struct sock *sk)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct socket *sock = sk->socket; 

	/* for poll sleepers */
	// if we've got room in the congestion window now, set things up so that we can send packets again
	if (tp->outstanding < tp->cwnd)
	{
		clear_bit(SOCK_NOSPACE, &sock->flags);
		
		if (sk->sleep && waitqueue_active(sk->sleep))
			wake_up_interruptible(sk->sleep);

		if (sock->fasync_list && !(sk->shutdown&SEND_SHUTDOWN))
			sock_wake_async(sock, 2, POLL_OUT);
	}
	return;
}


/* Processes the ack vector for CCID 2. Updates congestion window and ack ratios as necessary, based on
 * the frequency and loss of acknowledgements.
 *
 * Parameters:	sk - the socket which the connection is active on
 * 		skb - the sk_buff containing the DCCP packet with the ack vector
 * 		type - the type of DCCP packet in skb
 */
static void intake_acks (struct sock *sk, struct sk_buff *skb, unsigned char type)
	/* we return number of packets acked */
{				/* rsem lock held */
	u32 rackn,c4=0,csn;
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	unsigned char *p, *eop,i,j,v, congevent,lookforts,*data; /* todo, this really belongs in a bottom half */
	int rv =0;

	// TFRC need not bother...
	if (tp->ccid !=2)
		return;
	if ((type == TYPE_REQUEST) || (type == TYPE_DATA)) return ; /* have no ackn */

	rackn =  dccp_whatis_ackn (skb);

	//	rv += credit_pkt (sk,rackn);

	if (((sk->state == DCP_OPEN) &&    tp->checkingrtt))
	{
		lookforts = 1;
		c4 = tp->checkingsn;
	}
	else
		lookforts = 0;

	//Check if this is the ack for a rtt finding packet
	if (lookforts && (c4 == rackn))
	{				/* todo, accept timestamp here,
					   either on specific sn or any old timestamp */
		new_rtt_sample (tp, jiffies - tp->checkingrtt);
		tp->checkingrtt = 0;
		lookforts = 0;
	}

	p = skb->data + optionoffset (skb->data[4]);
	data = skb->data + (skb->data[8] * 4);

	// Cycling through option list, looking for any ACK VECTOR options to process
	while ( p < data)
		// Option codes less than 32 are always one byte so we can instantly skip
		if (*p < 32)
			p++;
		else
		{
			/* Don't go off the end of the skbuff!  */
			if (!( ((p+1) - skb->data) < skb->len)) 
				return ;

			// this is where the next option starts
			eop = p + p[1];
#if DCP_DEBUG > 2
			printk ("%d EOP LEN (w=%d) type=%d optlen=%d (eop is %d from b), p is %d from b\n",
					tp->whoami, skb->len,
					type,p[1],eop-skb->data,
					p-skb->data); 
#endif

			if ((eop - skb->data) > skb->len)
				return ;		/* we're clear to end of option */

			// We only do this for the ACK vector option
			if ((*p == DCP_OPT_ACKV0) || (*p == DCP_OPT_ACKV1))
				for (p+=2; p < eop;p++)
				{
					v = *p >> 7 ;	/* really 6, but we don't know what to do with ecn bit yet - todo */
					v = !v;
					// if the state is RECEIVED
					if (v)
					{
						// why is the below line commented out - it looks kinda important - SHANE
						//						rv += credit_pkt (sk,rackn);

						if (lookforts && (c4 == rackn))
						{				/* todo, accept timestamp here,
										   either on specific sn or any old timestamp */
							new_rtt_sample (tp, jiffies - tp->checkingrtt);
							tp->checkingrtt = 0;
							lookforts = 0;
						}       
					}


					rackn = wrapdec_24(rackn);
					// getting the run length and crediting all those packets
					j = *p & 0x3F;
					for (i=0;i<j;i++)
					{
						// Since this has appeared three times now it could probably be made into a separate function - SHANE
						if (v)
						{
							// Same again - should really uncomment this stuff at some stage
							//							rv += credit_pkt (sk,rackn);
							if (lookforts && (c4 == rackn))
							{				/* todo, accept timestamp here,
											   either on specific sn or any old timestamp */
								new_rtt_sample (tp, jiffies - tp->checkingrtt);
								tp->checkingrtt = 0;
								lookforts = 0;
							}       
						}

						rackn = wrapdec_24(rackn);
					}
				}
			else
				p = eop;
		}

	if (rv)			/* acked new data - grow cwnd */
	{
		if (tp->cwnd < tp->ssthresh) /* slowstart */
		{
			/* Increase congestion window by one for every ACK received */
			tp->cwnd++;
			rcvr_ratio_inbounds(tp);
			dcp_writeable(sk);	/* for polling sleepers */
		}

		else			/* avoidance */
		{
			/* Every time the congestion window is filled, increase the size of it by one */
			/* avoidp represents the number of acked outgoing packets in the congestion window */
			tp->avoidp += tp->rcvr_ratio;
			if (tp->avoidp >= tp->cwnd) /* a windows worth of acks */
			{
				tp->cwnd++;
				rcvr_ratio_inbounds(tp);
				dcp_writeable(sk);	/* for polling sleepers */
				tp->avoidp = 0;

			}
		}
#if DCP_DEBUG > 2
		printk ("%d positive cwnd adjustment, now %d (R%d)\n",tp->whoami,tp->cwnd,tp->avoidp);
#endif

	}


	/* check to see if we've created a fast retransmit case
	   by being the third newer packet to be acked in front of
	   an older one.. we'll scan from newest going back, loooking for
	   NUMDUPACKS (3) hits, after that we'll fill in any outstandings (and
	   dec ctr) where we find them */
	if (tp->outstanding && rv)
	{
		congevent = 0;
		v = 0;
		for (csn=tp->cv_hs;
				((tp->cv_ts != csn) && (v < DCP_NUMDUPACKS));
				csn = wrapdec_24(csn))
			if (value_in_cwndvector(sk,csn))
				v++;

		if (v==DCP_NUMDUPACKS)
		{
			// finding all the sequence numbers that have not been acked and crediting them
			while ((tp->cv_ts != csn) && tp->outstanding)
			{
				if (!value_in_cwndvector (sk,csn)) /* missing */
				{
					congevent = 1;
					// we know it is lost, so we can credit it safely enough
					rv += credit_pkt (sk,csn); 
				}

				csn = wrapdec_24(csn);
			}

		}
		if (congevent)
		{
#if DCP_DEBUG > 1
			printk ("LOSS DETECTED - cwnd now %d\n",tp->cwnd);
#endif
			tp->checkingrtt = tp->checkingsn = 0;	/* karn says we don't want to count any outstanding window measures */
			tp->cwnd = tp->cwnd /2; /* halve congestion window in response to loss */
			tp->avoidp = 0;

			if (!tp->cwnd)
				tp->cwnd = 1;
			tp->ssthresh = tp->cwnd;
			rcvr_ratio_inbounds(tp);
		}

	}


	// ackc = count of congestion windows that have not seen any loss of acks
	// ackp = number of packets that have been credited in the current window
	if (rv)
	{
		tp->ackp += rv;
		if (tp->ackp >= tp->cwnd)
		{			/* full window of data */
			tp->ackp = 0;
			if (noackloss(sk))
			{
				tp->ackc++;
				if ((tp->rcvr_ratio > 1) && /* reduce ackratio - see lots of acks as path is clear */
						(tp->ackc >= tp->cwnd / (tp->rcvr_ratio * tp->rcvr_ratio - tp->rcvr_ratio)))
				{
					tp->rcvr_ratio--;
					rcvr_ratio_inbounds(tp);
					tp->ackc = 0;
				}
			}
			else
			{			/* we're losing acks, so we want to up ackratio to send less of them
						   and ease congestion*/
				tp->rcvr_ratio *= 2;
				tp->ackc = 0;
				rcvr_ratio_inbounds(tp);
			}
		}
	}

	return;
}

/* Updates the receiver's ack ratio value to ensure it conforms to the CCID 2 specifications (cc. March 2003!)
 *
 * Parameters:	tp - the dcp_opt structure containing the congestion window and ack ratio information for this connection
 * */
static inline void rcvr_ratio_inbounds (struct dcp_opt *tp)
{
	/* Copied from the CCID 2 specs:
	 * There are three constraints on the Ack Ratio.  First, it is always
	 * an integer.  Second, it is never greater than half the congestion
	 * window (with fractions rounded up).  Third, it is at least two for a
	 * congestion window of four or more packets.
	 * */
	if (tp->rcvr_ratio > (tp->cwnd/2))
	{
		tp->rcvr_ratio = tp->cwnd/2;
		if (tp->cwnd % 2)
			tp->rcvr_ratio++;
	}

	if ((tp->cwnd >= 4) && (tp->rcvr_ratio < 2))
		tp->rcvr_ratio = 2;
	return;

}

/* Generates a DCCP Answer option i.e. a confirm option, in response to a DCCP Change, or Ask, option and adds it to the list of options
 * to be included in the next outgoing packet
 *
 * Parameters:	tp - the DCCP-related information for the sending socket
 * 		type - the option number that is being confirmed
 * 		val - the value for the confirmed option
 */
static inline void genanswer (struct dcp_opt *tp, unsigned char type, unsigned char val)
{
	if (tp->opt_a_sz + 4 > DCP_OPTASZ)
		return;

	tp->opt_append[tp->opt_a_sz++] = DCP_OPT_ANSWER;		
	tp->opt_append[tp->opt_a_sz++] = 4;
	tp->opt_append[tp->opt_a_sz++] = type;
	tp->opt_append[tp->opt_a_sz++] = val;

	return;
}

/* Generates a DCCP Choose option, i.e a prefer option, and adds it to the list of options to be included in the next outgoing packet
 *
 * Parameters: 	tp - the DCCP-related information for the sending socket
 * 		type - the option number that we are stating our preferences for
 * 		val - the prefered value for the option
 */
// NOTE: It appears that we only allow a single preferred value - this is not in line with the protocol specs. We should support multiple
// values.
static inline void genchoose (struct dcp_opt *tp, unsigned char type, unsigned char val)
{
	if (tp->opt_a_sz + 4 > DCP_OPTASZ)
		return;

	tp->opt_append[tp->opt_a_sz++] = DCP_OPT_CHOOSE;
	tp->opt_append[tp->opt_a_sz++] = 4;
	tp->opt_append[tp->opt_a_sz++] = type;
	tp->opt_append[tp->opt_a_sz++] = val;

	return;
}

/* Parses and deals with the options that follow the generic packet header
 *
 * Parameters:	skb - the sk_buff containing the received packet
 * 		sk - the socket relating to the outgoing connection which will respond to the packet
 */
static void generic_option_parse (struct sk_buff *skb, struct sock *sk)
{
	unsigned char *p, *eop, *b, *t,g;
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);

	if (skb->len < 16) return; 
	// start of the options field
	p = skb->data + optionoffset (skb->data[4]);
	// end of the options field
	b =  skb->data + (skb->data[8] * 4); //IS THIS A BUFFER OVERFLOW??

	//This is a snaeky place to put it.
	while ( p < b)
	{
		// padding and discard options only take up a single byte
		if (*p < 32)
			eop = p+1;
		else
		{
			// making sure that the option does not go past the end of the packet
			if (!( ((p+1) - skb->data) < skb->len))
				break;

			eop = p + p[1];
			if ((eop - skb->data) > skb->len)
				break;

		}

		switch (*p)
		{
			case DCP_OPT_PAD:
			case DCP_OPT_DISCARD:
			case DCP_OPT_IGNORED:
			case DCP_OPT_ICOOKIE:
			case DCP_OPT_ACKV0:
			case DCP_OPT_ACKV1:
			case DCP_OPT_RBDROP:
			case DCP_OPT_TS_ECHO:
			case DCP_OPT_MOBILE:
			case DCP_OPT_BCD:
				break;		/* essentially ignore because we're handled other places */

			case  DCP_OPT_WINCOUNT:  /* CCID 3 specific */
				if ((eop - p) == 3)
				{

				}
				break;

			case DCP_OPT_LOSSEVENT: /* CCID 3 specific */
				if ((eop - p) == 6)
				{

					tp->losseventrate = ntohl((u32) *(p+2)); //is this right?



				}
				break;
			case  DCP_OPT_TS: /* Timestamp */
				if ((eop - p) == 6) // if statements like this are simple length checking
				{
					// copying the timestamp so that we can echo it back on the next packet
					tp->ts_r_stamp = jiffies;
					memcpy (&tp->ts_r,p+2,4);
				}
				break;

			case DCP_OPT_ASK: /* If we see this, then we are being asked to change the value of a feature at this location */

				if ((eop-p)>=4)
					switch (p[2])
					{
						case DCP_NEG_TYPE_CC: /* Congestion control negotiation */
							g = 0;

							if (!(tp->negibuf & 0x01))
							{
								// This for loop is a bit shoddy. Without braces, only the first value for CCID in the
								// ASK option will be used. With braces, only the last value will be used.
								// POSSIBLE FIX: replace current for statement with - for (t = p+3; t < eop && g == 0; t++) and
								// insert braces around loop. Close brace needs to be placed before if (!g).
								//
								// FIXED - SHANE
								for (t = p+3; t< eop && g == 0;t++) {
									
									if (*t == 2)
									{
#if DCP_DEBUG > 1
										printk ("%d: responding to ask ccid 2 by setting ccid and generating answer\n",tp->whoami);
#endif
										tp->ccid = 2;
										genanswer (tp,DCP_NEG_TYPE_CC,2);
										g=1;
										break;

									}
									else if(*t ==3)
									{
										//This is CCID 3!
                              
#if DCP_DEBUG > 0
										printk("%d: Got an ask for CCID 3\n",tp->whoami);
#endif
                              
										tp->ccid=3;
										genanswer(tp,DCP_NEG_TYPE_CC,3);
										g=1; //I think this means we setup a CCID.

#if DCP_DEBUG > 0
										printk("INIT RECV TFRC\n");
#endif
										tp->recv_ccb = tfrc_recv_init(tp);
										break;
									}
								}
								// If none of the CCIDs in the ASK option are acceptable, tell the sender we like CCID 2
								// SUGGESTION: We could also prefer CCID 3 as well!
								if (!g)
									genchoose (tp,DCP_NEG_TYPE_CC,2);
							}
							tp->negibuf |= 0x01;

							break;

						case DCP_NEG_TYPE_ACKRATIO: /* Ack Ratio negotiation */
							if (!(tp->negibuf &0x02))
							{
								// Are we only allowing one byte for ack ratio option, specs suggest two bytes should be used - SHANE
								if (p[3])
								{
									tp->ackratio = p[3];
#if DCP_DEBUG > 1
									printk ("%d: responding to ask ackratio by setting acratio to %d, and generating answer\n",tp->whoami,p[3]);
#endif
								}

								genanswer (tp,DCP_NEG_TYPE_ACKRATIO,tp->ackratio);
							}
							tp->negibuf |= 0x02;

							break;

						case DCP_NEG_TYPE_ACKVECTOR: /* Send Ack Vector option negotiation */
							if (!(tp->negibuf & 0x04))
							{
								if (p[3])
								{
									tp->uav = p[3];
#if DCP_DEBUG > 1
									printk ("%d: responding to ask use ackvector by setting uav to %d, and generating answer\n",tp->whoami,p[3]);
#endif
								}

								genanswer (tp,DCP_NEG_TYPE_ACKVECTOR,p[3]);
							}
							tp->negibuf |= 0x04;

							break;
						/* I guess it's too bad if we get any other options come through - SHANE */
						default:
							break;
					}

				break;

			/* A Prefer option where the feature location specifies the options it prefers */
			case DCP_OPT_CHOOSE:
				if ((eop-p)>=4)
					switch (p[2])
					{
						// I guess we don't actually do anything in relation to the sender's preferred values.
						// Instead, we just go into a negotiation state. If we don't do anything about this later
						// on, I guess something could be done to make this better - SHANE
						case DCP_NEG_TYPE_CC:
							tp->ccid_state = DCP_OPT_STATE_ASKING;
							break;

						case DCP_NEG_TYPE_ACKRATIO:
							tp->rcvr_ratio_state = DCP_OPT_STATE_ASKING;
							break;

						case DCP_NEG_TYPE_ACKVECTOR:
							tp->uav_state = DCP_OPT_STATE_ASKING;
							break;
						default:
							break;
					}
				break;

			/* Confirm feature option */
			// If Host A receives a confirm, that sets the value for the A to B half-connection
			case DCP_OPT_ANSWER:
				if ((eop-p)>=4)
					switch (p[2])
					{
						case DCP_NEG_TYPE_CC:
#if DCP_DEBUG > 1
							printk ("%d confirmed assigned remote ccid of %d EEEEP %d\n",tp->whoami,p[3],tp->ccid);
#endif
							tp->ccid_state = DCP_OPT_STATE_KNOWN;
							tp->ccid = p[3]; //Why is this not here before??
                     
#if DCP_DEBUG > 0
							printk ("ccid of %d %d EEEEP\n",tp->whoami,p[3]);
#endif
                     
							if (tp->ccid == 3)
							{
								///WOOOH lets call some fbd stuff


								printk("LOADING TFRC\n");
								tp->send_ccb = tfrc_send_init(tp); //This works too well it scares me lots

							}
							break;

						case DCP_NEG_TYPE_ACKRATIO:
#if DCP_DEBUG > 1
							printk ("%d confirmed assigned remote ackratio of %d\n",tp->whoami,p[3]);
#endif
							tp->rcvr_ratio = p[3];
							tp->rcvr_ratio_state = DCP_OPT_STATE_KNOWN;
							break;

						case DCP_NEG_TYPE_ACKVECTOR:
#if DCP_DEBUG > 1
							printk ("%d confirmed assigned remote use of ackvector of %d\n",tp->whoami,p[3]);
#endif
							tp->uav_state = DCP_OPT_STATE_KNOWN;
							tp->uav = p[3];
							break;
						default:
							break;
					}
				break;

			// unknown feature number
			default:
				if (tp->opt_a_sz + 4 <=DCP_OPTASZ)
				{
					tp->opt_append[tp->opt_a_sz++] = DCP_OPT_IGNORED;
					tp->opt_append[tp->opt_a_sz++] = 4;
					tp->opt_append[tp->opt_a_sz++] = *p;
					tp->opt_append[tp->opt_a_sz++] = ( (eop -p) > 2) ? p[2] : 0;
				}

				break;

		}
		p = eop;
	}

	return;
}

/* Puts a connection into the timewait state after receiving a RESET packet
 *
 * Parameters:	sk - the socket on which the connection is taking place
 * */
static void enter_timewait (struct sock *sk)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);

#if DCP_DEBUG > 2
	printk ("entering TIMEWAIT\n"); 
#endif
	sk->state = DCP_TIMEWAIT;

	tp->rto_num = 0x1000000;
	
	// setting up a timer to expire when the timewait state should end
	del_timer_sync (&tp->timewait_t);
	tp->timewait_t.data = (unsigned long) sk;
	tp->timewait_t.function = (void *) dcp_handle_timewait;
	tp->timewait_t.expires = jiffies + DCP_TIMEWAIT_LEN;
	add_timer (&tp->timewait_t);
	return;
}

/* A continuation of processing a received packet. Here we deal with the acks attached to the packet, arrange
 * to ack this packet eventually, add the packet to the received queue, update the connection state if necessary,
 * and schedule the appropriate responses to CLOSEREQ, CLOSE and RESET packets
 *
 * Parameters:	sk - the socket on which the packet was received
 * 		skb - the sk_buff containing the received packet
 */
static int dccp_enq_rcv (struct sock *sk, struct sk_buff *skb)
{
	int err;
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	unsigned char type;

	err = 0;

	type =skb->data[4];

#if DCP_DEBUG > 2
	printk ("PACKET IN: Whoami=%02X, Type=%02X, state=%d, length=%d, interrupt=%d\n",
			tp->whoami,type,sk->state,skb->len,in_interrupt()); 
#endif
	spin_lock (&tp->rsem);	

	dccp_update_ackn (&tp->ackn,skb); /* ackn is the ackn we send, taken from seqno in every pkt */
	tp->unacked++;		/* protected by rsem */

	increment_ackvector (sk, whatis_seqno (skb));	/* note that recvd packet has to be acked */
	intake_acks (sk,skb,type);	/* give credit for acks received */
	if (tp->whoami != WHOAMI_BINDER)
		generic_option_parse (skb,sk);


	if (tp->ccid ==3 && sk->state == DCP_OPEN) //don't do it if we're terming or everything will goto hell, and back
	{//McManus does some dirty so we have to shift right 4 to play nice
		tp->len_rcv = skb->len; //TODO is this right??
		tp->type_rcv = skb->data[4] >> 4; 
		tp->seq_rcv = whatis_seqno (skb); //Hope this works
		tp->ack_rcv = dccp_whatis_ackn (skb);	
		tp->ndp_rcv = skb->data[9] & 0xf0;
		tp->ndp_rcv >>=4;// shift it left buddy
#if DCP_DEBUG > 2
		printk("Tell TFRC about packet of type %d recieved with %d len of opts\n",
				tp->type_rcv, (skb->data + (skb->data[8] * 4))
				- ( skb->data + optionoffset (skb->data[4])));
#endif
		//tell tfrc about this packet, i bet it would like to know..
		tfrc_send_packet_recv(tp->send_ccb,
				skb->data + optionoffset (skb->data[4]),
				(skb->data + (skb->data[8] * 4))
				- ( skb->data + optionoffset (skb->data[4]))); 

		tfrc_recv_packet_recv(tp->recv_ccb,
				skb->data + optionoffset (skb->data[4]),
				(skb->data + (skb->data[8] * 4))
				- ( skb->data + optionoffset (skb->data[4]))); 


	}

	if ((type == TYPE_ACK) &&(sk->state == DCP_OPEN))
	{
		kfree_skb(skb);		/* todo - process options */

		skb = NULL;

	}
	else
		// check we have space in the receive queue for the packet
		if (((tp->rcvq_t +1) %DCP_RCVQ_SZ) == tp->rcvq_h)
			err = -ENOBUFS;
		else
		{
			/* queue it */
			tp->rcvq[tp->rcvq_t] = skb;
			if (++tp->rcvq_t == DCP_RCVQ_SZ)
				tp->rcvq_t = 0;
		}

	if (!err)
	{        
		//TODO [TOM] maybe need to add CCID 3 here!
		/* if we've got too many unacked packets, we should schedule an
		   ack - by the time that runs it may be obviated though. */
		if ((tp->unacked >= tp->ackratio) &&
				(!(tp->flags & FLAG_ACKSCHED)) &&
				(tp->ccid == 2) &&
				(sk->state == DCP_OPEN))
		{
			tp->atask.data =sk;
			tp->flags |= FLAG_ACKSCHED;
			schedule_task(&tp->atask);
		}


		// we've been asked to close the connection by the client
		if ((tp->whoami == WHOAMI_SERVER) && 
				((type == TYPE_CLOSE)||(type==TYPE_RESET))&& 
				((sk->state == DCP_HALF_CLOSE) ||(sk->state == DCP_OPEN)) )
		{

			if ( (sk->state == DCP_OPEN) || (type == TYPE_CLOSE))
			{
				tp->rtask.data = sk;	/* send reset */
				schedule_task(&tp->rtask);
			}

			sk->state = DCP_CLOSED; 
		}

		// we've been told by the server that the connection is being reset
		if ((tp->whoami == WHOAMI_CLIENT) && 
				(type==TYPE_RESET) && 
				((sk->state == DCP_REQUESTING) || (sk->state == DCP_OPEN)) )
		{
#if DCP_DEBUG > 1
			printk ("dccp client has been reset!\n");
#endif
			enter_timewait (sk);
		}

		// the server has sent us a close request
		if ((tp->whoami == WHOAMI_CLIENT) && 
				(type==TYPE_CLOSEREQ)&& 
				(sk->state == DCP_OPEN))
		{
#if DCP_DEBUG > 2
			printk ("closereq being acted upon\n");
#endif
			sk->state = DCP_HALF_CLOSE;
			tp->ctask.data = sk;	/* send close */
			schedule_task(&tp->ctask);
		}
	}

	spin_unlock (&tp->rsem);	  

	if (!err)
		wake_up (&tp->newdata);

	return err;

}

/* Performs initial processing on a received packet
 *
 * Parameters:	skb - the sk_buff containing the received packet
 */
static int dccp_rcv (struct sk_buff *skb)
{
	struct sock *sk;
	u32 locala, remotea, svc;
	u16 lport, rport;
	unsigned char ptype;

	/* extract the info we need to get the list lookup */
	if ((ptype = parse_dccp_pkt (skb,&locala,&remotea,&svc,&lport,&rport)) == TYPE_INVALID)
	{

		printk ("dccp: Packet is not a valid DCCP packet\n");
		goto drop;
	}


	/* lookup the sk for it.. */
	sk = lookup_dccp_sk(0,remotea,svc,lport,rport,ptype);

	if (!sk)
	{
		printk ("dccp: rcvd dccp packet for non existant session %08X:%d to %08X:%d (svc=%X)\n",
				remotea,ntohs(rport),locala,ntohs(lport),svc);
		goto rst;
	}


	/* if found we want to signal newdata via wake_up() after
	   placing skb in a circular q.. */
	if (dccp_enq_rcv (sk,skb))
	{
#if DCP_DEBUG > 0
		printk ("dccp: rcvd dccp packet but there doesn't seem to be any room for it\n");
#endif
		goto drop;
	}

	/* don't touch skb after this point - it's either been xferred to another handler,
	   or freed completely if it was just an ack */
	//TODO: [TOM] MAYBE here is better for CCID3?
	//no here is in the upper half and its baaad here@!


	return 0;			/* OK! */

rst:
	if ( (skb->data[4] != TYPE_RESET))
	{
		itask.data = skb;	/* some risk of lost resets here - thats ok by me */
		if (schedule_task(&itask))
			return 0;
	}

drop:
	/* we'll drop the packet if we can't find the sk, or if there
	   is no room in the q */
	/* if we don't queue this thing up we want to drop it */

#if DCP_DEBUG > 0
	printk ("dccp: dropping packet\n");
#endif

	kfree_skb(skb);
	return 0;
}


static struct inet_protocol dccp_protocol = {
handler:	dccp_rcv,
err_handler:	NULL,
protocol:	DCCP_PROTO, /* 33 as per eddie kohler 4/25/2002 */
name:		"DCCP"
};

/* Sets a different outstanding packet to be the round trip time estimator, 
 * in the event of the previous round trip time measurement timing out without a response
 *
 * Parameters:	vd - the socket on which the connection is taking place
 * */
static void *dccp_charged_timeout (unsigned long vd)
{
	/* ok - we've had an RTO timer go off */
	struct sock *sk;
	struct dcp_opt *tp;
	u32 ld,lsn;

	sk = (struct sock *)vd;
	tp = &(sk->tp_pinfo.tp_dcp);

	spin_lock (&tp->rsem);   
	
	// if the timer is actually set and the outstanding timer packet is in the congestion window
	if ((tp->rto_num != 0x1000000) &&   (ld = value_in_cwndvector (sk,tp->rto_num)))
	{
		// nope, we haven't actually timed out - ideally, we wouldn't reach this point
		if ((jiffies - ld) < tp->rto)
		{			/* just reschedule it */

			tp->retransmit_timer.expires = ld + tp->rto;      
			mod_timer (&tp->retransmit_timer,tp->retransmit_timer.expires);
		}
		else
		{	
#if DCP_DEBUG > 1		
			printk ("PACKET TIMEOUT %d\n",tp->rto_num);
#endif
			// The outstanding timer packet has not been acked before the timeout
			tp->checkingrtt = tp->checkingsn = 0;	/* karn says we don't want to count any outstanding window measures */
			lsn = tp->rto_num;
			tp->rto_num = 0x1000000;
			// we've given up on this packet so remove it from the congestion window
			credit_pkt(sk,lsn); 

			// Our timing info has to come from another outstanding packet asap
			while ((tp->cv_ts != tp->cv_hs) && tp->outstanding)
			{
				tp->retransmit_timer.function = (void *) dccp_charged_timeout;
				tp->retransmit_timer.data = (unsigned long) sk;
				// we use cv_tp because it should be the next packet ACKed
				tp->retransmit_timer.expires = *((u32 *)tp->cv_tp) + tp->rto;      

				// making sure our timer isn't due to expire sometime in the past 
				if (tp->retransmit_timer.expires <= jiffies)
				{
#if DCP_DEBUG > 2
					printk ("CONCURRENT PACKET TO %d\n",tp->cv_ts);
#endif
					credit_pkt(sk,tp->cv_ts); 
				}
				else
				{
					/*printk ("would set new rto timer to %d (delta %d)\n",
					  tp->retransmit_timer.expires,
					  tp->retransmit_timer.expires - jiffies); */

					tp->rto_num = tp->cv_ts; 
					add_timer (&tp->retransmit_timer);     
					break;
				}

			}
			
			// all data packets have been lost so adjust cwnd, ssthresh et al.
			if (jiffies > tp->timeout_barrier) /* can't adj more than once a window*/
			{
				tp->timeout_barrier = jiffies + tp->rtt;
				tp->ssthresh = tp->cwnd/2;
				tp->cwnd = 1;
				if (!tp->ssthresh)
					tp->ssthresh = 1;
				rcvr_ratio_inbounds(tp);
			}


		}
	}
	else
		tp->rto_num = 0x1000000;

	spin_unlock (&tp->rsem);   
	wake_up (&tp->newdata);

	return NULL;
}

/* Updates timer related variables to signify that the packet needs to be re-sent - used with regards to connection
 * handshakes and closing. Not applicable to data or acks
 *
 * Parameters:	s - the socket on which the connection is taking place
 * */
static void *dcp_resend (unsigned long s)
{
	struct sock *sk;
	struct dcp_opt *tp;

	sk = (struct sock *)s;
	tp = &(sk->tp_pinfo.tp_dcp);

	// I presume something checks the value of timer_expired later on to see if a resend is required - SHANE
	tp->timer_expired = 1;
	tp->retries++;
#if DCP_DEBUG > 2
	printk ("dccp: Timer Expired at %d:%X\n",tp->whoami,(unsigned)jiffies);
#endif
	wake_up (&tp->newdata);

	return NULL;
}

/* Updates rtt information based on the new sample received
 *
 * Parameters:	tp - the dcp_opt structure containing the current rtt information	
 * 		M - the rtt estimate
 * */
static inline void new_rtt_sample (struct dcp_opt *tp, u16 M)
{				/* lock held */
	u16 err;

	// deviation calculations
	if (M >= tp->rtt)
	{
		err = M - tp->rtt;
		tp->rtt = tp->rtt + (err >> 3);
	}
	else
	{
		err = tp->rtt - M;
		tp->rtt = tp->rtt - (err >> 3);
	}
	
	tp->rtt_d = tp->rtt_d + ((err - tp->rtt_d) >> 2);
	// updating the timeout value
	tp->rto = tp->rtt + (tp->rtt_d << 2);

	// Updating minimum rtt if necessary
	if (tp->rtt < DCP_MIN_RTT)
		tp->rtt = DCP_MIN_RTT;
#if DCP_DEBUG > 1
	printk ("new rtt sample: %d, rtt is now %d\n",M,tp->rtt);
#endif

	return;
}

/* Initializes the ack and congestion window vectors for a socket
 *
 * Parameters:	sk - the socket for which the vectors need to be initialized
 * */
static int finalize_init(struct sock *sk)
{				/* setup vector trackers */
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);

	tp->av_sz = tp->cv_sz = INIT_VECTOR_SIZE;	/* initially track this number of packets - keep as multiple of 8 */
	tp->av_hs =tp->av_ts = tp->cv_hs = tp->cv_ts = 0;

	//tp->ackvector  =  kmalloc(tp->av_sz/4, GFP_KERNEL); /* 2 bits entry */
   tp->ackvector  =  vmalloc(tp->av_sz/4); /* 2 bits entry */

	//tp->cwndvector =  kmalloc(tp->cv_sz*4,GFP_KERNEL); /* 32 bits per entry */
   tp->cwndvector =  vmalloc(tp->cv_sz*4L); /* 32 bits per entry */ 

	memset (tp->ackvector,0xff,tp->av_sz/4);
	memset (tp->cwndvector,0,tp->cv_sz*4);

	tp->av_tp = tp->ackvector;
	tp->cv_hp = tp->cv_tp = tp->cwndvector;
	tp->av_clist = NULL;

	return 0;
}

/* Updates the congestion window to reflect the receipt of an ack for a particular outstanding packet.
 * Also used to remove packets that are regarded as lost from the congestion window
 *
 * Parameters:	sk - the socket where the connection is taking place
 * 		sn - the sequence number of the packet that has been acked
 * */
static int credit_pkt (struct sock *sk, u32 sn)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	u32 bo,gap,*rt;
	unsigned char *t;
	int rv = 0;

#if DCP_DEBUG > 2  
	printk ("credit request %d\n",sn); 
#endif
	/* rsem lock held */
	/* opposite of charge pkt, in
	   reaction to rcvd ack on cwndvector */
	if (tp->cv_ts == tp->cv_hs)	/* empty */
		goto ackofack_q;

	if (sn >= tp->cv_ts)
		gap = (sn - tp->cv_ts);
	else				/* sn has wrapped but ts hasn't */
		gap = (sn + (0x1000000 - tp->cv_ts));

	if (gap > tp->cv_sz)  /* probably from past */
	{
		/*     printk ("excessive gap %d (sn=%d, ts=%d)\n",gap,sn,tp->cv_ts); */
		goto ackofack_q;
	}
	// four bytes for each entry
	bo = gap*4;
	t = tp->cv_tp+bo;

	if (t >= (tp->cwndvector + (tp->cv_sz*4))) /* wrapped */
		t -= tp->cv_sz*4;
	rt = (u32 *) t;

	if (*rt)			/* packets were set */
	{
		tp->outstanding--;	
#if DCP_DEBUG > 2
		printk ("%d Giving Credit for %d - %d\n",tp->whoami,sn,*rt);  
#endif
		rv++;
		dcp_writeable(sk);	/* for polling sleepers */

		*rt = 0;			/* clear the packet in vector */

		rt = (u32 *) tp->cv_tp;

		// moving the tail pointer ahead to the first un-credited packet in the cwnd, or the head pointer
		// whichever comes first
		while ((tp->cv_hs != tp->cv_ts) && (! *rt))
		{
			tp->cv_tp += 4;
			if (tp->cv_tp >= (tp->cwndvector + (tp->cv_sz*4)))
				tp->cv_tp = tp->cwndvector; /* wrap */

			tp->cv_ts += 1;
			if (tp->cv_ts == 0x1000000)
				tp->cv_ts = 0;

			rt = (u32 *) tp->cv_tp;
		}

		if (tp->rto_num == sn)	/* timer was set for this packet */
		{
			/* see if we've got another outstanding pkt */
			if (tp->outstanding && (tp->cv_hs != tp->cv_ts))
			{
				tp->rto_num = tp->cv_ts;
				tp->retransmit_timer.expires = *rt + tp->rto;      
				mod_timer (&tp->retransmit_timer,tp->retransmit_timer.expires);
			}
			else
			{
				tp->rto_num = 0x1000000; /* not used */
				del_timer_sync (&tp->retransmit_timer); /* cancel it */
			}
		}

		return rv;
	}

ackofack_q:

	check_clist (tp,sn);	/* maybe an ack of ack? */

	return rv;
}


/* Adds a packet to the congestion window 
 *
 * Parameters:	sk - the socket on which the connection is taking place
 * 		sn - the sequence number of the packet being sent
 * */
static inline void charge_pkt (struct sock *sk, u32 sn)
{				/* assume a lock */
	/* charge a sending packet against cwnd - store it's sn so we can
	   credit cwnd when it gets acked */

	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	u32  tc, gap;
	unsigned char *n,*t;
	u32 *rt;
	// only needed for CCID 2
	if (tp->ccid !=2)
		return;

	// congestion window is empty so we're the first entry
	if (tp->cv_ts == tp->cv_hs)
		tp->cv_ts = tp->cv_hs = sn;

	if (sn >= tp->cv_ts)
		gap = (sn - tp->cv_ts);
	else				/* sn has wrapped but ts hasn't */
		gap = (sn + (0x1000000 - tp->cv_ts));

	if (gap > tp->cv_sz) return ; /* probably from past */

	tp->outstanding++;

	// setting the timer if necessary
	if (tp->rto_num == 0x1000000)	/* no timer set */
	{
		tp->rto_num = sn;
		tp->retransmit_timer.function = (void *) dccp_charged_timeout;
		tp->retransmit_timer.data = (unsigned long) sk;
		tp->retransmit_timer.expires = jiffies + tp->rto;      

		add_timer (&tp->retransmit_timer);      
	}


	t = tp->cv_tp+(gap*4);

	if (t >= (tp->cwndvector + (tp->cv_sz*4))) /* wrapped */
		t -= tp->cv_sz*4;

	rt = (u32 *) t;
	*rt = jiffies;		/* set bits */

#if DCP_DEBUG > 2
	printk ("%d Charging for %d - %p\n",tp->whoami,sn,t);
#endif

	// we haven't increment sn yet
	tp->cv_hs = sn +1;

	if (tp->cv_hs == 0x1000000)
		tp->cv_hs = 0;

	tp->cv_hp = t;

	if (gap > (tp->cv_sz - 128))	/* running out of room, should expand cwnd vector */
	{
		//n = kmalloc (tp->cv_sz*8,GFP_ATOMIC);	/* a doubling */
      n = vmalloc (tp->cv_sz*8);	/* a doubling */

		memset (n+tp->cv_sz*4,0x00,tp->cv_sz*4); /* new half all missing */

		tc = (tp->cwndvector + (tp->cv_sz*4)) - tp->cv_tp;	
		memcpy (n,tp->cv_tp, tc); /* tail to end */
		memcpy (n+tc,tp->cwndvector,tp->cv_tp - tp->cwndvector); /* start to tail */

		tp->cv_tp = n;
		tp->cv_sz = tp->cv_sz * 2; /* counted in items, so it's a doubling */
		
      //kfree (tp->cwndvector);
      vfree(tp->cwndvector);
      
		tp->cwndvector = n;
		tp->cv_hp = tp->cv_tp +(gap*4);
	}

#if DCP_DEBUG > 2
	printk ("dccp %d: charge pkt [%d] - outstanding now %d\n",tp->whoami,sn,tp->outstanding);
#endif
	return;
}


/* Updates the ack vector when a packet has been received.
 * 
 * Parameters:	sk - the socket the packet was received on
 * 		sn - the sequence number of the received packet
 * */
static inline int increment_ackvector (struct sock *sk, u32 sn)
{				/* assume a lock */
	/* we've recvd a packet, and want to put it in the local
	   ackvector so that when we send it off the av, it will
	   be included */

	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	u32 offset, tc,gap;
	unsigned char *n,*t;

	tp->av_ts = tp->av_hs = sn;
	

	if (sn >= tp->av_ts)
	{
		gap = (sn - tp->av_ts);
	}
	else				/* sn has wrapped but ts hasn't */
	{
		gap = (sn + (0x1000000 - tp->av_ts));
	}
	offset = gap %4;	/* 2 bit location to mark (hi or lo)*/

	if (gap >= tp->av_sz) 
		return 1;	/* out of range - pkt should be filtered */

	t = tp->av_tp + (gap/4);
	if (t >= (tp->ackvector + (tp->av_sz/4)))
		t -= (tp->av_sz /4);	/* wrapped */

	*t = *t & (~(0x03 << (offset *2)));	/* turn off bits, 00 is rcvd, 11 is missing */

	/* updating ack vector head sequence number */
	tp->av_hs = tp->ackn +1;
	if (tp->av_hs == 0x1000000) /* wrapping again */
		tp->av_hs = 0;

	if (gap > (tp->av_sz - 128))	/* running out of room, should expand ack vector */
	{
		//n = kmalloc (tp->av_sz/2,GFP_ATOMIC);	/* a doubling */
		n = vmalloc (tp->av_sz/2);	/* a doubling */

		memset (n+tp->av_sz/4,0xff,tp->av_sz/4); /* new half all missing */

		tc = (tp->ackvector + (tp->av_sz/4)) - tp->av_tp;	
		memcpy (n,tp->av_tp, tc); /* tail to end */
		memcpy (n+tc,tp->ackvector,tp->av_tp - tp->ackvector); /* start to tail */

		tp->av_tp = n;
		tp->av_sz = tp->av_sz * 2; /* counted in items, so it';s a doubling */
      
		//kfree (tp->ackvector);
	        vfree(tp->ackvector);

		tp->ackvector = n;
	}

	return 0;
}




/* Initialises values for a DCCP socket, particularly the dcp_opt structure
 *
 * Parameters: 	sk - the socket whose values need to be initialised
 * */
static int dccp_sk_init(struct sock *sk)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct page *page;

#if DCP_DEBUG > 1
	printk ("dccp: init\n");
#endif

	sk->state = DCP_CLOSED;
	tp->cwnd = DCP_INITIAL_CWND;
	tp->ssthresh = 0xafff;	/* near infinity */
	tp->outstanding = 0;
	tp->valid4 = DCP_INITIAL_CWND;

	tp->checkingrtt = tp->checkingsn = 0;

	tp->unacked =0;
	tp->ccid = 0;			/* to be set on generation of an answer option,
							   can't send any data at ccid==0 */
	tp->ackn = 0xefffffff;	/* beyond 24bit window - so it's a safe sentinel */

	tp->flags = FLAG_ALLOW_LOADED_HANDSHAKE; /* handshake on, but acksched off to start */
	tp->shake_defer = NULL;

	tp->whoami = WHOAMI_UNKNOWN;
	init_waitqueue_head (&tp->newdata);
	tp->rcvq_h = tp->rcvq_t = 0;
	spin_lock_init (&tp->rsem);

	tp->rtask.routine = dccp_safe_reset;
	tp->rtask.data  = sk;
	tp->ctask.routine = dccp_safe_close;
	tp->ctask.data = sk;
	tp->atask.routine = dccp_schedule_ack;
	tp->atask.data = sk;

	init_timer (&tp->retransmit_timer);
	init_timer (&tp->timewait_t);
	tp->retransmit_timer.function = (void *) dcp_resend;
	tp->retransmit_timer.data = 0;
	tp->retransmit_timer.expires = jiffies;
	// Initial sequence number calculation
   /*for debugging changed to 0 by BJORN.*/
	//tp->seq = (jiffies ^ tp->seq) % 0x1000000 ;	/* 24 bits */
   tp->seq = 0;
	/*  printk ("Assigning ISN of %d\n",tp->seq); */

	tp->rto_num = 0x1000000;	/* no rto timer set */
	tp->timeout_barrier = 0;
	tp->avoidp=0;
	tp->ackc = 0;
	tp->ackp=0;
	tp->ackc_wsn = 0x1000000;

	tp->ndp = 1;
	tp->svc = 0x00;
	tp->retries = 1;
	tp->timer_expired = 0;
	tp->ts_r = tp->ts_r_stamp = 0;
	tp->opt_a_sz = 0;
	tp->negibuf = 0;
	tp->rcvr_ratio  = 1;
	tp->ackratio = 2; //TODO make this back to 2!
	//tp->ackratio = 1;

	tp->uav = 0;
	tp->hsd = NULL;
	tp->hsdlen = 0;

	tp->uav_state = DCP_OPT_STATE_ASKING;
	tp->rcvr_ratio_state =DCP_OPT_STATE_ASKING;
	tp->ccid_state = DCP_OPT_STATE_ASKING;
	//Setup stuff for mmap
	tp->tfrcmem= kmalloc(DCCP_MAP_SIZE,GFP_KERNEL);

	for (page = virt_to_page(tp->tfrcmem); page < virt_to_page(tp->tfrcmem + DCCP_MAP_SIZE); page++) {
		mem_map_reserve(page); 
	}

	return 0;
}

/* Adds a few Change options to the list of options that will be included in the next outgoing packet. These options will
 * describe a few suggested default values for the outgoing half-connection
 *
 * Parameters 	tp - the structure containing all the miscellaneous information regarding an outgoing half-connection
 * */
static void generic_option_negotiation (struct dcp_opt *tp)
{
	// we'll need space for the option
	if (tp->opt_a_sz + 4 > DCP_OPTASZ)
		return;

	// Ack vector on by default
	if (tp->uav_state == DCP_OPT_STATE_ASKING)
	{
		tp->opt_append[tp->opt_a_sz++] = DCP_OPT_ASK;		
		tp->opt_append[tp->opt_a_sz++] = 4;
		tp->opt_append[tp->opt_a_sz++] = DCP_NEG_TYPE_ACKVECTOR;
		tp->opt_append[tp->opt_a_sz++] = 1;
	}

	if (tp->opt_a_sz + 4 > DCP_OPTASZ)
		return;

	if (tp->rcvr_ratio_state == DCP_OPT_STATE_ASKING)
	{
		tp->opt_append[tp->opt_a_sz++] = DCP_OPT_ASK;		
		tp->opt_append[tp->opt_a_sz++] = 4;
		tp->opt_append[tp->opt_a_sz++] = DCP_NEG_TYPE_ACKRATIO;
		tp->opt_append[tp->opt_a_sz++] = tp->rcvr_ratio;
	}

	if (tp->opt_a_sz + 4 > DCP_OPTASZ)
		return;

	// we're defaulting to CCID 3 here
	if (tp->ccid_state == DCP_OPT_STATE_ASKING)
	{
		tp->opt_append[tp->opt_a_sz++] = DCP_OPT_ASK;		
		tp->opt_append[tp->opt_a_sz++] = 4;
		tp->opt_append[tp->opt_a_sz++] = DCP_NEG_TYPE_CC;
		tp->opt_append[tp->opt_a_sz++] = 3;
	}
	/*	if (tp->opt_a_sz + 3 > DCP_OPTASZ)
		{
#if DCP_DEBUG > 2 
printk("DCCP run out of space for window count");
#endif
return;
}
if ( tp->ccid_state == DCP_OPT_STATE_KNOWN && tp->ccid == 3) //Maybe OPT_KNOW is unnedded?
{
tp->opt_append[tp->opt_a_sz++] = DCP_OPT_WINCOUNT;
tp->opt_append[tp->opt_a_sz++] = 3;
tp->opt_append[tp->opt_a_sz++] = tp->wndcount;
}
*/
return;
}


/* Converts a 32-bit sequence number into the 24 bits required for a DCCP header.
 * Note: Current specs use 48 bit sequence numbers now, but we're working off version 1 so this is still OK
 *
 * Parameters:	s - the current sequence number
 * 		d - the place where the 24 bit sequence number is to be placed
 * 		inc - the amount to increment the sequence number by so that it is correct for the next packet
 * */
static void dccp_write_24 (u32 *s, char *d, int inc)
{
	u32 sn;

	/* okay, we need to write out a 24 bit quantity from sn.
	   we write it out MSB, but sn is stored in host byte order */
	sn = *s;
	d[0] = (sn / 0x10000) % 0x100;
	d[1] = (sn / 0x100) % 0x100;
	d[2] = sn % 0x100 ;
	/* naive, but correct */
	
	// Actually, I haven't checked this out myself 100% yet, but it seems to work OK. Should be tested with large seq numbers - SHANE
	
	if (inc)
	{
		*s += inc;
		if (*s == 0x1000000) *s = 0;
		/* printk ("updated seq no to %d\n",*s); */
	}
	return;
}

/* Performs the necessary checksum calculations for an outgoing packet
 *
 * Parameters:	p - the packet in build_t format
 *		to - a char * where the final packet will be stored
 *		offset - the checksum length offset
 * 		fraglen - the length of the packet (including data)
 * */
static int dccp_getfrag(const void *p, char * to, unsigned int offset, unsigned int fraglen) 
{
/* NOTE: Should this be dealing with offset = 15, i.e. checksum covers the entire packet? - SHANE */
	
	const unsigned char *h = ((const struct build_t *)p)->h;
	const unsigned char *kdb = ((const struct build_t *)p)->kdb;
	int hl = ((const struct build_t *)p)->hl;
	int kdbl = ((const struct build_t *)p)->kdbl;
	struct iovec *iov = ((const struct build_t *)p)->iov;
	u32 *check;
	u16 finalcheck;

#if DCP_DEBUG > 2
	printk ("getfrag fraglen=%d, offset=%d, hl=%d\n",fraglen,offset,hl); 
#endif

	check = &(( struct build_t *)p)->check;

	// cslen = 0, only cover the header
	if (offset == 0)
	{
		if (fraglen-hl)
		{
			/* we've either got an iov (normal data) or
			   kdb (handshake data) */
			if (iov)
			{
				// no data should get checksumed - if it does, some parameter is incorrect
				if (csum_partial_copy_fromiovecend(to+hl, iov, offset, fraglen - hl,
							check))
					return -EFAULT;
			}
			else			/* handshake */
			{
				if (kdb)
				{
					// shove handshake data onto the end of the header
					// obviously it is included in the checksum
					*check = csum_partial (kdb,kdbl,*check);
					memcpy (to+hl,kdb,kdbl);
				}
			}
		}

		// no data so just checksum the header
		*check = csum_partial (h,hl,*check);
		memcpy (to,h,hl) ;
		// gotta squeeze into 16 bits
		finalcheck = csum_fold (*check);
		memcpy (to+10,&finalcheck,2);

		/*       printk ("sending checksum is %02X%02X%02X %04X\n",to[5],to[6],to[7],
				 finalcheck);  */
		return 0;

	}
	
	// do checksuming over the first "offset" bytes of the data 
	return csum_partial_copy_fromiovecend(to, iov, offset-hl,   fraglen,check);

}

/* Registers a new DCCP socket and places it into the socket hashmap.
 *
 * Parameters:	sk - the socket to be registered
 * 		la - the ip address of the socket location
 * 		ra - the ip address of the remote end of the socket connection
 * 		svc - the service code for the connection
 * 		lport - the port to bind the socket to at the location
 * 		rport - the port to bind the socket to at the remote
 * */
static int register_dccp_sk (struct sock *sk, u32 la, u32 ra, u32 svc,
		u16 lport, u16 rport)
{
	struct dccp_sk_list_t *el,*t, *dccp_sk_list;
	int rv = 0;
	u16 n,nl;

	/* bound sockets (not connected) have a zeroed ra and rport */

	el = kmem_cache_alloc (dccp_slab_sk,GFP_KERNEL);
	if (!el)
		return 1;

	// copying values into the new socket list entry
	el->sk = sk;
	el->svc = svc;
	el->n = el->p = NULL;

	el->locala = la;
	el->remotea = ra;
	el->lp = lport;
	el->rp = rport;

	n = skhash(ra,rport,lport);
	nl = n & 0xF;

	write_lock (dccp_table_lock+nl);
	dccp_sk_list = dccp_sk_hash[n];

	/*  printk ("%d registering in chain %d - %X %d %d\n", sk->tp_pinfo.tp_dcp.whoami,n,
		ra,ntohs(rport),ntohs(lport));
		*/

	if ((!ra) && (!rport))
	{				/* binder - check list for duplicate */

		t = dccp_sk_list;
		// checking that we don't already have an equivalent socket bound
		while (t)
		{

			/* printk ("COMP %08X %08X\n",la,t->locala); */

			if ( (t->locala == la) && (t->remotea == ra) &&
					(t->lp == lport) && (t->rp == rport))
			{
				printk ("dccp: double binding detected\n");
				rv = 2;
				goto noadd;
			}
			t = t->n;
		}


		if (dccp_port_claim (ntohs(lport)))
		{
			printk ("dccp: binding to port already in use\n");
			rv = 3;
			goto noadd;
		}
	}


	// adding our new socket to the list
	if (dccp_sk_list)
	{
		el->n = dccp_sk_list;
		el->n->p = el;
	}

	dccp_sk_hash[n] = el;
	finalize_init (sk); 

	MOD_INC_USE_COUNT;

	write_unlock (dccp_table_lock+nl);
	return rv;

noadd:
	kmem_cache_free (dccp_slab_sk,el);
	write_unlock (dccp_table_lock+nl);
	return rv;

}

/* Checks if an ACK is scheduled and creates an uninterruptible waiting state until all the scheduled acks have been sent
 * Parameters:	sk - the socket which is being checked for outstanding ACKs
 * */
static void   waitforscheduledack(struct sock *sk)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);

	if ((tp->flags & FLAG_ACKSCHED))
		wait_event (tp->newdata, (!(tp->flags & FLAG_ACKSCHED)));
	return;
}

/* Unregisters a socket and removes any data left in receive queues, etc, before deleting the socket itself. 
 * The socket is also removed from the socket list. By the time the function returns, the socket no longer exists
 * and (hopefully) all the associated data has been cleared from memory. Returns 0 if successful, non-zero otherwise
 *
 * Parameters:	sk - the socket to be unregistered
 * */
static int unregister_dccp_sk (struct sock *sk)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct dccp_sk_list_t *el, *dccp_sk_list;
	struct ack_collapse_t *t;
	int rv;
	u16 n,nl;

	rv =1;

	// if we're a listening server, we don't have a daddr or dport yet	
	if (tp->whoami == WHOAMI_BINDER) 
		n = skhash(0,0,sk->sport);
	else 
		n = skhash(sk->daddr,sk->dport,sk->sport);
	nl = n & 0xF;

	write_lock (dccp_table_lock+nl);
	dccp_sk_list = dccp_sk_hash[n];

	/*  printk ("unregister checking in list %d\n",n); */

	// Iterating over the socket list to find sk and remove it
	el = dccp_sk_list;
	while (el)
	{
		if (el->sk == sk)		/* match! */
		{
			if (el->p)
				el->p->n = el->n;
			else
			{
				dccp_sk_list = el->n;
				dccp_sk_hash[n] = el->n;
			}

			if (el->n)
				el->n->p = el->p;
			break;
		}
		el = el->n;
	}

	write_unlock (dccp_table_lock+nl);

	if (el)
	{
		if (tp->whoami != WHOAMI_SERVER)
			dccp_port_release (el->lp);
		waitforscheduledack(sk);	/* generally very fast */

		//kfree (tp->ackvector);
      vfree (tp->ackvector);

		//kfree (tp->cwndvector);
      vfree (tp->cwndvector);


		while (tp->rcvq_h != tp->rcvq_t )	/* drain anything in the rcv q */
		{
			kfree_skb( tp->rcvq[tp->rcvq_h]); 
			if (++tp->rcvq_h == DCP_RCVQ_SZ)
				tp->rcvq_h = 0;
		}

		t = tp->av_clist;

		// deleting everything in the av_clist
		while (t)
		{
			tp->av_clist = t->next;
			kmem_cache_free (dccp_slab_ack,t);
			t = tp->av_clist;
		}

		if (tp->hsdlen)
			//kfree (tp->hsd);
         vfree(tp->hsd);
		tp->hsdlen = 0;
		tp->hsd = NULL;

		if (tp->shake_defer)
			kfree_skb(tp->shake_defer);
		tp->shake_defer = NULL;

#if DCP_DEBUG > 1
		printk ("%d unregister successful\n",tp->whoami);
#endif
		// finally we can free the socket itself
		kmem_cache_free (dccp_slab_sk,el);
		rv= 0;
		MOD_DEC_USE_COUNT;
	}
	else
	{
#if DCP_DEBUG > 1
		printk ("%d unregister failed\n",tp->whoami);
#endif
		rv= 1;
	}

	return rv;
}

/* Each entry in the dccp_port_map covers eight different ports, cutting down on space. This function checks to see if any
 * of the eight ports covered in a single map entry are available for use. If there is, we return the port number. If not,
 * we return zero.
 *
 * Parameters:	i - the index into the dccp_port_map that we are checking
 * */
static inline int freebit (int i)
{
	unsigned char t,m,b;
	int rv;

	/* i is index into dccp_port_map
	   if we can find a free bit in that character,
	   we'll return a corresponding port (*8+base) and 
	   clear the bit
	   */
	rv = 0;

	t = dccp_port_map[i];
	m = 0x01;

	for (b=0;b<8;b++)
	{
		if (t & m)
		{
			rv = (i*8) + DCCP_PORT_BASE + b;
			dccp_port_map[i] = dccp_port_map[i] & (~m); /* clear bit */
			break;
		}
		m = m << 1;
	}
	return rv;
}

/* Claims the given port for a DCCP socket, provided the port number is in range and available
 *
 * Parameters:	i - the port number to claim
 * */
static int dccp_port_claim (u16 i)
{
	unsigned char *t,b;
	int rv;

	if ((i < DCCP_PORT_BASE) ||
			(i >= DCCP_PORT_HI))
		return 2;			/* out of range */

	/* i is a port # - we need to find it's map */  
	i -= DCCP_PORT_BASE;
	b = i % 8;
	t = dccp_port_map + (i/8);
	rv = 1;

	spin_lock (&dccp_port_lock);
	if ( *t & (1 << b))		/* bit set, means its avail */
	{
		*t = *t & (~(1 << b));	/* claim it */
		rv = 0;
	}

	spin_unlock (&dccp_port_lock);

	return rv;
}

/* Releases a given port number so that future connections may make use of it
 *
 * Parameters: 	i - the port number to be released
 * */
static void dccp_port_release (u16 i)
{
	unsigned char *t,b;

	i = ntohs(i);

#if DCP_DEBUG > 2
	printk ("PORT RELEASE - %d\n",i); 
#endif

	if ((i < DCCP_PORT_BASE) ||
			(i >= DCCP_PORT_HI))
		return;			/* out of range */


	/* i is a port # - we need to find it's map */  
	i -= DCCP_PORT_BASE;
	b = i % 8;
	t = dccp_port_map + (i/8);

	spin_lock (&dccp_port_lock);
	*t = *t | (1 << b);		/* bit set, means its avail */
	spin_unlock (&dccp_port_lock);

	return;
}

/* Finds a free port number within the allowed range that a DCCP socket could use */
static int dccp_port_assignment (void)
{
	u16 rv,i;

	rv = 0;

	spin_lock (&dccp_port_lock);

	// Pretty simple stuff - run through the list of available port numbers and find one that isn't being used
	// The tricky part is that i corresponds to 8 different port numbers, one for each bit. Hence, the need for the freebit function
	for (i=0;(i<DCCP_PORT_RANGE) && (!rv);i++)
	{
		rv=freebit(dccp_port);
		if (!rv)
			if (++dccp_port == DCCP_PORT_RANGE)
				dccp_port = 0;
	}

	spin_unlock (&dccp_port_lock);
	if (!rv)
		printk ("dccp_port_assignment: unable to find a free port to allocate\n");

#if DCP_DEBUG > 1
	printk ("dccp_port_assignment: assigned %d\n",rv);
#endif
	return rv;

}

/* Gets the acknowledgement number from the packet and converts it into a 32 bit integer
 *
 * Parameters:	skb - the sk_buff containing the received packet
 * */
static u32 dccp_whatis_ackn (struct sk_buff *skb)
{
	unsigned int c;
	// too short a packet for an ack number to be included
	if (skb->len < 16)
		return 0;

	c  = ((unsigned char) skb->data[13]) * 0x10000;
	c += ((unsigned char) skb->data[14]) * 0x100;
	c += ((unsigned char) skb->data[15]);

	/* printk ("recvd packet with an ack Num of %d\n",c); */
	return c;
}

/* Sees if the given option is present in a particular packet's option list. Returns the size of the option
 *
 * Parameters:	skb - the sk_buff containing the packet being examined
 * 		option - the option code being searched for
 * 		ics - the number of bytes into the packet that the option is found - if NULL initially, do not change
 * */
static u16 dccp_parse_option (struct sk_buff *skb, unsigned char option,u16 *ics)
{
	unsigned char *p, *eop, *b;

	if (skb->len < 16) return 0;
	// start of options field
	p = skb->data + optionoffset (skb->data[4]);
	// end of options field
	b =  skb->data + (skb->data[8] * 4);

	while ( p < b)
		if (*p < 32)
		// All options will a code less than 32 are always 1 byte	
		{
			if (*p == option)
			{
				if (ics)
					*ics = p-skb->data;
				return 1;
			}
			p++;
		}
		else
		{
			if (!( ((p+1) - skb->data) < skb->len))
				return 0;

			eop = p + p[1];
			if ((eop - skb->data) > skb->len)
				return 0;		/* we're clear to end of option */

			if (*p == option)
			{
				if (ics)
					*ics = p- skb->data;
				return p[1];
			}
			p = eop;
		}

	return 0;

}


/* Begins DCCP connection handshake by transmitting a REQUEST packet. Also waits for the corresponding RESPONSE and
 * acks that appropriately
 *
 * Parameters:	sk - the socket on which we will connect to the server
 * 		uaddr - the socket address of the intended connection point on the server
 * 		addr_len - the size of uaddr
 * */
static int dccp_connect(struct sock *sk, struct sockaddr *uaddr, int addr_len)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct sockaddr_in *rv;
	struct sockaddr_dcp *dcpv;
	struct rtable *rt;
	unsigned char *pbuf,pt;
	struct ipcm_cookie ipc;
	int t,err,i;
	u32  rackn,isn[DCP_MAX_TRIES], stamp[DCP_MAX_TRIES] ;
	struct sk_buff *skb;
	struct build_t b;
	u16 ics,icl;

#if DCP_DEBUG > 1
	printk ("dccp: connect, stat is %d\n",sk->state);
#endif

	// Checking if a connection is already open on this socket
	if (sk->state != DCP_CLOSED)
		return -EISCONN;

	if (addr_len < sizeof(struct sockaddr_in)) 
		return -EINVAL;

	if (addr_len == sizeof (struct sockaddr_dcp))	/* with a service name */
	{
		dcpv = (struct sockaddr_dcp *)uaddr;
		rv = &(dcpv->in);
	}
	else
	{
		rv = (struct sockaddr_in *)uaddr; /* traditional */
		dcpv = NULL;
	}

	if (rv->sin_family != AF_INET) 
		return -EAFNOSUPPORT;

	if ((t = ip_route_connect(&rt,  rv->sin_addr.s_addr, sk->saddr,
					RT_CONN_FLAGS(sk), sk->bound_dev_if)))
		return t;


	if(!sk->saddr)
		sk->saddr = rt->rt_src;		/* Update source address */
	if(!sk->rcv_saddr)
		sk->rcv_saddr = rt->rt_src;

	// Let's score ourselves a port
	sk->num = dccp_port_assignment();
	if (!sk->num)
		return -EAGAIN;		/* no more ports available */

	sk->sport = htons (sk->num);

	/*  sk->sport =  htons (dccp_port_assignment()); */


	sk->daddr = rt->rt_dst;
	sk->dport = rv->sin_port;

	// Not 100% sure what this is about exactly, but it seems OK - SHANE 
	ipc.opt = NULL;
	ipc.oif = sk->bound_dev_if;
	if (!ipc.opt)
		ipc.opt = sk->protinfo.af_inet.opt;
	ipc.addr = sk->daddr;

#if DCP_DEBUG > 1
	printk ("dccp: rcv_saddr %08X, daddr %08X, saddp %X, daddp %X - saddr %X\n",
			sk->rcv_saddr, sk->daddr, sk->num,  sk->dport, sk->saddr); 
#endif

	sk->err = 0;
	sk->done = 0;
	// We're the client who is going to attempt to connect to the server
	tp->whoami = WHOAMI_CLIENT;

	if (dcpv)
		tp->svc = dcpv->service;

#if DCP_DEBUG > 1
	printk ("connecting with service # %d\n",tp->svc);
#endif

	pbuf = kmem_cache_alloc (dccp_slab,GFP_ATOMIC);

	if (!pbuf)
	{
		printk ("dccp: connect failed to allocate buf\n");
		return -ENOBUFS;
	}

	// OK, let's build the REQUEST packet
	memcpy (pbuf,&sk->sport,2);
	memcpy (pbuf+2,&sk->dport,2);


	pbuf[4] = TYPE_REQUEST;	/* req pkt, includes the 4 rsvd bits */


	pbuf[8] = 0x04;		/* header length - 4 32 bit words + options */

	pbuf[9] = 0x1F;		/* 4bits ndp=1, cslen=15 (all) */

	memcpy (pbuf+12,&tp->svc,4);	/* service name */

	generic_option_negotiation (tp);
	if (tp->opt_a_sz)
	{
		memcpy (pbuf+(pbuf[8]*4),tp->opt_append,tp->opt_a_sz);
		pbuf[8] += (tp->opt_a_sz / 4);
		tp->opt_a_sz = 0;
		tp->negibuf = 0;
	}

	sk->state = DCP_REQUESTING;

	// Registering the socket
	if (register_dccp_sk (sk,rt->rt_src,rt->rt_dst,tp->svc,sk->sport,sk->dport))
	{
		kmem_cache_free (dccp_slab,pbuf);
		return -ENOBUFS;
	}

	tp->retries = 1;
	tp->retransmit_timer.data = (unsigned long) sk;

	/* also wait/sleep on tp->newdata */
	skb = NULL;
	tp->timer_expired = 1;
	tp->rtt = 0xffff;
	mkbuildt_k (&b, pbuf, pbuf[8]*4, tp->hsd,tp->hsdlen);
	do
	{

		do
		{
			// Should we get no response after a reasonable amount of time
			if (tp->retries == DCP_MAX_TRIES)
			{
				printk ("connect side unable to complete handshake\n");
				sk->state = DCP_CLOSED;
				unregister_dccp_sk(sk);

				kmem_cache_free (dccp_slab,pbuf);
				return -ETIMEDOUT;
			}

			if (tp->timer_expired)
			{
				//  sending the packet
				stamp[tp->retries - 1]=jiffies; /* increase seqno for rexmit */
				isn[tp->retries-1] = tp->seq;
				dccp_write_24 (&tp->seq, pbuf+5,1); /* essentially a ++ */
				memset (pbuf+10,0,2);		/* checksum - starts at 0 for calc */

				/* syn */
				err=ip_build_xmit (sk,dccp_getfrag, &b,pbuf[8]*4 + tp->hsdlen,&ipc,rt,MSG_DONTWAIT );
#if DCP_DEBUG > 1
				printk ("transmitting dcp connect from %08X to %08X : (err=%d)\n",rt->rt_src, rt->rt_dst,err);
#endif
				tp->retransmit_timer.expires = jiffies + (1<< tp->retries >>1) * DCP_TIMEOUT;
			}

			tp->timer_expired = 0;

			add_timer (&tp->retransmit_timer);

			if (wait_event_interruptible (tp->newdata, DCP_DATA_EVENT_TO ))
			{
				kmem_cache_free (dccp_slab,pbuf);
				del_timer_sync (&tp->retransmit_timer);
				return -ERESTARTSYS;
			}
			del_timer_sync (&tp->retransmit_timer);
		}
		while (tp->timer_expired);

		err =0;
		spin_lock (&tp->rsem);   
		while ((!skb) && (tp->rcvq_h != tp->rcvq_t ) && (!err))
		{
			skb = tp->rcvq[tp->rcvq_h];
			// We can only accept a RESPONSE packet here
			if ((pt=(skb->data[4] & 0xF0)) != TYPE_RESPONSE)
			{
				printk ("dccp connect: dropping non response packet (%X) when in REQUESTING state\n",pt);
				kfree_skb(skb);		/* drop it */
				skb = NULL;
				if (pt == TYPE_RESET)
					err = -ECONNREFUSED;
			}


			if (skb)		
			{
				// the ack number needs to match the initial sequence number
				rackn = dccp_whatis_ackn (skb);
				for (i=0;i<tp->retries;i++)
					if (isn[i] == rackn)
					{
						tp->rtt = jiffies - stamp[i];
						break;
					}

				if (tp->rtt == 0xffff)
				{
					printk ("dccp: connect synack didn't match isn\n");
					kfree_skb(skb);		/* drop it */
					skb = NULL;
				}
			}

			if (++tp->rcvq_h == DCP_RCVQ_SZ)
				tp->rcvq_h = 0;
		}
		spin_unlock (&tp->rsem);
		if (err)
		{
			kmem_cache_free (dccp_slab,pbuf);
			return err;
		}
	}
	while (!skb);

	// update minimum rtt information
	if (tp->rtt < DCP_MIN_RTT)
		tp->rtt = DCP_MIN_RTT;
#if DCP_DEBUG > 1
	printk ("connect got synack (aka response sz =%d) rtt= %d jiffies\n",skb->len,tp->rtt);
#endif
	tp->rtt_d = 0;
	tp->rto = tp->rtt;

	if (skb->len > (skb->data[8] *4))
	{
#if DCP_DEBUG > 1
		printk ("adding data sent with response to incoming q\n");
#endif
		tp->shake_defer =skb;
	}


	/* ---- need to ack the synack (response) -------- */

	if (dccp_parse_option (skb,DCP_OPT_DISCARD,NULL) && 
			tp->hsdlen) /* data on syn, but not collected by server.. gotta resend */
	{
		pbuf[4] = TYPE_DATAACK;
#if DCP_DEBUG > 1
		printk ("connection: server discarded my data - resending\n");
#endif
	}

	else
	{
		pbuf[4] = TYPE_ACK;	/* req pkt, includes the 4 rsvd bits */
		if (tp->hsdlen)
		{			/* we don't need to resend handshake data */
			//kfree (tp->hsd);
         vfree(tp->hsd);
			tp->hsdlen = 0;
			tp->hsd = NULL;
		}
	}


	dccp_write_24 (&tp->seq, pbuf+5,1);

	// I'm guessing that a retransmit of data that was present in the REQUEST packet but dropped by the server does not count as a
	// data packet, otherwise this line should be in the ELSE block above - SHANE
	tp->ndp++;
	// And this would need to be altered too - SHANE
	pbuf[9] = 0x2F;		/* 4bits ndp=2, cslen=15 (all) */

	memset (pbuf+10,0,2);		/* checksum - starts at 0 for calc */

	pbuf[12] =0;

	clear_unacked (tp);
	memcpy (pbuf+13,skb->data+5,3);/* seq no of the synack.. */

	pbuf[8] = 0x04;		/* header length - 5 32 bit words */

	if ((icl = dccp_parse_option (skb,DCP_OPT_ICOOKIE,&ics)))	/* if we got an init cookie on response, echo back */
	{
		memcpy (pbuf+20,skb->data+ics,icl);
		while (icl %4)
			pbuf[20+icl++] = 0;
		pbuf[8] += icl/4;
	}
	generic_option_negotiation (tp);
	// fill in all the other options
	if (tp->opt_a_sz)
	{
		memcpy (pbuf+(pbuf[8]*4),tp->opt_append,tp->opt_a_sz);
		pbuf[8] += (tp->opt_a_sz / 4);
		tp->opt_a_sz = 0;
		tp->negibuf = 0;
	}

	// Connection is open, send off ACK and tidy things up
	sk->state = DCP_OPEN;
	if (!tp->shake_defer)
		kfree_skb(skb);		/* done with synack */

	/* final ack */
	mkbuildt_k (&b, pbuf, pbuf[8]*4, tp->hsd,tp->hsdlen);
	err=ip_build_xmit (sk,dccp_getfrag, &b,pbuf[8]*4 + tp->hsdlen,&ipc,rt,MSG_DONTWAIT );

#if DCP_DEBUG > 1
	printk ("transmitting dcp connect final ack from %08X to %08X : (err=%d)\n",rt->rt_src, rt->rt_dst,err);
#endif
	kmem_cache_free (dccp_slab,pbuf);
	if (tp->hsdlen)
	{			
		//kfree (tp->hsd);
      vfree(tp->hsd);

		tp->hsdlen = 0;
		tp->hsd = NULL;
	}
	return 0;
}


/* Sets the connection state to CLOSED and resets the socket
 *
 * Parameters:	sk - the socket where the connection takes place
 * 		flags - not used
 * */
int dccp_disconnect(struct sock *sk, int flags)
{
	/* stolen right from udp */

#if DCP_DEBUG > 1
	printk ("dccp: disconnect\n");
#endif

	sk->state = DCP_CLOSED;
	sk->daddr = 0;
	sk->dport = 0;
	sk->bound_dev_if = 0;
	if (!(sk->userlocks&SOCK_BINDADDR_LOCK)) {
		sk->rcv_saddr = 0;
		sk->saddr = 0;
	}
	if (!(sk->userlocks&SOCK_BINDPORT_LOCK)) {
		sk->prot->unhash(sk);
		sk->sport = 0;
	}
	sk_dst_reset(sk);
	return 0;
}

/* Deals with input/output commands - required by protocol setup, but doesn't do anything at this stage as no commands
 * are supported
 * 
 * Parameters:	sk - the socket on which the connection is taking place
 * 		cmd - the command to be performed
 * 		arg - the arguments required by the command
 * */
static int dccp_ioctl(struct sock *sk, int cmd, unsigned long arg)
{
#if DCP_DEBUG > 1
	printk ("dccp: ioctl\n");
#endif

	switch (cmd)
	{
		/*		case SIODCPRATEINFO:
				{
				struct dcp_rateinfo ri;
				ri.rate=1000;
				int err;	


				err=  copy_to_user((struct rate_info *) arg ,&ri, sizeof(ri));
				if (err != sizeof(ri))
				return EIO;
				}
				*/		
		default:

			return -ENOIOCTLCMD;
	}
}

/* Required protocol function, again. Sets DCCP socket options to given values. Currently, only deals with
 * options relating to handshake data
 *
 * Parameters:	sk - the socket whose options need to be set
 * 		level - the level, i.e. protocol, for which the option to be set applies
 * 		optname - the option name
 * 		optval - the value the option is to be set to
 * 		optlen - the length of the option value
 * */
static int dccp_setsockopt(struct sock *sk, int level, int optname, 
		char *optval, int optlen)
{
	unsigned char *ld;
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	int err,val;

	/* all setsockopts come through here, we need to recast the non-dccp ones */
#if DCP_DEBUG > 2
	printk ("dccp: setsockopt level=%d,%d\n",level,optname);
#endif

	// we only want to be dealing with DCCP socket options here!!
	if (level != SOL_DCCP)
		return ip_setsockopt(sk, level, optname, optval, optlen);
	err = 0;

	spin_lock (&tp->rsem);
	switch (optname)
	{
		// we've got some data we need to send during connection handshake
		case SO_HANDSHAKE_DATA:
			// if the connection is active then we shouldn't be worrying about handshake data
			if ((sk->state != DCP_CLOSED) &&
					(sk->state != DCP_LISTENING))
			{
				err = -EISCONN;
				goto sod;
			}

			printk ("%d bytes of handshake data submitted\n",optlen);

			if (optlen)
			{
				//ld = kmalloc (optlen,GFP_ATOMIC);
            ld = vmalloc (optlen);
				// getting the handshake data
				if (copy_from_user(ld, optval, optlen))
				{
					err = -EFAULT;
					goto sod;
				}
			}
			else
				ld = NULL;
			
			// updating hsd and hsdlen
			if (tp->hsdlen)
				//kfree (tp->hsd);
        			vfree(tp->hsd);
			tp->hsdlen = optlen;
			tp->hsd = ld;
			break;

		// we want to allow (or disallow) handshake data
		case SO_ALLOW_HANDSHAKE_DATA:
			// gotta be closed before we start fiddling with handshake parameters
			if (sk->state != DCP_CLOSED)
			{
				err = -EISCONN;
				goto sod;
			}
			
			// it needs to be an integer
			if (optlen < sizeof (int))
			{
				err = -EINVAL;
				goto sod;
			}

			if (get_user(val, (int *)optval))
			{
				err = -EFAULT;
				goto sod;
			}
			// setting the flag
			if (val) 
				tp->flags |= FLAG_ALLOW_LOADED_HANDSHAKE;
			else
				tp->flags &= ~FLAG_ALLOW_LOADED_HANDSHAKE;
			break;

		default:
			return -ENOPROTOOPT;
			break;
	}

sod:
	spin_unlock (&tp->rsem);

	return err;
}

/* Places the value of a DCCP socket option into the optval variable. Currently only supports the
 * Allow Handshake Data option.
 *
 * Parameters:	sk - the socket which we are getting the option from
 * 		level - the level at which the option occurs
 * 		optname - the name of the option being looked up
 * 		optval - the value of the option will be stored here
 * 		optlen - the length of the option value 
 * */
static int dccp_getsockopt(struct sock *sk, int level, int optname, 
		char *optval, int *optlen)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	int val,len,err;

#if DCP_DEBUG > 2
	printk ("dccp: getsockopt\n");
#endif

	// we only want to be dealing with DCCP level options
	if (level != SOL_DCCP)
		return ip_getsockopt(sk, level, optname, optval, optlen);
	err = 0;

	if(get_user(len,optlen))
		return -EFAULT;

	spin_lock (&tp->rsem);
	switch (optname)
	{
		case SO_ALLOW_HANDSHAKE_DATA:
			// the option is an integer
			if (len < sizeof (int))
			{
				err = -EINVAL;
				goto sod;
			}
			if (tp->flags & FLAG_ALLOW_LOADED_HANDSHAKE)
				val = 1;
			else
				val = 0;

			if(put_user(sizeof (val), optlen))
			{
				err =  -EFAULT;
				goto sod;
			}

			if(put_user(val, (int *)optval))
			{
				err =  -EFAULT;
				goto sod;
			}

			break;

		default:
			return -ENOPROTOOPT;
			break;
	}

sod:
	spin_unlock (&tp->rsem);
	return err;

}

/* Converts the non-data packet count into the necessary format for placement in the packet header. Assumes that
 * the checksum length field is going to be 15.
 * 
 * Parameters:	ndp - the current non-data packet count
 * 		inc - the amount to increment the ndp count by
 * */
static inline unsigned char dcp_write_ndp (u16 *ndp, int inc)
{
	/*  ndp shares a single octet with the checksum length field. ndp covers the first four bits
	 *  while cslen covers the last four bits. As a result, ndp needs to be left-shifted four bits.
	 *  Also, cslen is always set to 15 in this implementation so the last four bits need to be
	 *  all set to 1. A cslen of 15 means that the checksum will cover the entire packet.
	 * */
	unsigned char rv,a;

	rv = *ndp;
	rv = rv << 4;
	rv = (rv | 0x0F) & 0xFF;

	/* Incrementing ndp and dealing with any wrap around - we can only fit ndp in four bits so this will occur often */
	if (inc)
	{
		a = *ndp +1;
		a = a % 0x10;
		*ndp = a;
	}
	return rv;
}

/* Creates and sends a RESET packet when there is no dcp_opt structure available i.e. there is no existing connection.
 * Used to send RESET packets when a connection does not exist e.g. rejecting a REQUEST packet. Reset reason is unspecified.
 *
 * Parameters:	v - the outgoing socket on the machine that the RESET is to be sent to
 * */
static void orphaned_reset (void *v)

{
	u32 sip, dip;
	unsigned char *pbuf;
	struct sk_buff *skb = v;
	struct build_t b;
	struct ipcm_cookie ipc;
	struct rtable *rt;

#if DCP_DEBUG > 1
	printk ("orphaned reset\n");
#endif

	dip = skb->nh.iph->saddr; /* remote addr */
	sip = skb->nh.iph->daddr;

	pbuf = kmem_cache_alloc (dccp_slab,GFP_ATOMIC);

	memcpy (pbuf,skb->data+2,2);	/* local port */
	memcpy (pbuf+2,skb->data,2);	/* dest port */

	pbuf[4] = TYPE_RESET;	/*reset pkt, includes the 4 rsvd bits */
	memset (pbuf+5,0,3);		/* seqno = 0 */
	pbuf[9] = 0x1F;
	memset (pbuf+10,0,2);		/* checksum - starts at 0 for calc */

	pbuf[12] = 0;			/* reserved */
	memset (pbuf+13,0,3);		/* ackn */

	memset (pbuf+16,0,4);		/* reason 0 */

	pbuf[8] = 0x05;		/* header length - 5 32 bit words */

	/* no options on the reset - no tp to pull from anyhow */
	mkbuildt (&b, pbuf, 20,NULL);

	spin_lock (&dccp_reset_lock);

	ipc.oif = reset_socket->sk->bound_dev_if;
	ipc.opt = reset_socket->sk->protinfo.af_inet.opt;
	ipc.addr = reset_socket->sk->daddr;

	ip_route_output(&rt, dip, sip, 0, ipc.oif);

	ip_build_xmit (reset_socket->sk,dccp_getfrag, &b,20,&ipc,rt,MSG_DONTWAIT);

	spin_unlock (&dccp_reset_lock);

	kmem_cache_free (dccp_slab,pbuf);
	kfree_skb(skb);

	return;
}

/* Creates and sends a RESET packet. Does NOT close the connection
 *
 * Parameters:	sk - the socket on which the reset will be sent
 * 		reason - the 4 bytes that describe the reason for sending the RESET packet.
 * */
static void dccp_reset (struct sock *sk, u32 reason)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	unsigned char *pbuf;
	struct build_t b;
	struct ipcm_cookie ipc;
	struct rtable *rt;

#if DCP_DEBUG > 1
	printk ("dccp: %d send reset\n",tp->whoami);
#endif

	// getting IP info for the sending function
	ipc.oif = sk->bound_dev_if;
	ipc.opt = sk->protinfo.af_inet.opt;
	ipc.addr = sk->daddr;

	// building the RESET packet
	pbuf = kmem_cache_alloc (dccp_slab,GFP_ATOMIC);

	memcpy (pbuf,&sk->sport,2);
	memcpy (pbuf+2,&sk->dport,2);

	pbuf[4] = TYPE_RESET;	/* data-ack pkt, includes the 4 rsvd bits */

	spin_lock (&tp->rsem);
	dccp_write_24 (&tp->seq, pbuf+5,1); /* incs sn for me */

	pbuf[8] = 0x05;		/* header length - 5 32 bit words */

	pbuf[9] = dcp_write_ndp (&tp->ndp,1);	/* ndp=tp->ndp and cslen=15 */

	memset (pbuf+10,0,2);		/* checksum - starts at 0 for calc */

	pbuf[12] = 0;			/* reserved */

	dccp_write_24 (&tp->ackn, pbuf+13,0); 
	memcpy (pbuf+16,&reason,4); // dealing with the reason field - reason has been prebuilt earlier
	spin_unlock (&tp->rsem);

	ip_route_output(&rt, sk->daddr, sk->saddr, RT_CONN_FLAGS(sk), ipc.oif);

	mkbuildt (&b, pbuf, 20,NULL);	/* no options on reset */
	// Sending the packet
	ip_build_xmit (sk,dccp_getfrag, &b,20,&ipc,rt,MSG_DONTWAIT);

	// tidying up TFRC
	if (tp->ccid == 3)
	{
		printk("Killing TFRC!\n");
		if(tp->send_ccb !=NULL)
			tfrc_send_free(tp->send_ccb);
		if(tp->recv_ccb !=NULL)
			tfrc_recv_free(tp->recv_ccb);


	}
	kmem_cache_free (dccp_slab,pbuf);

	return;
}


/* Finds the State for a particular sequence number in the Ack Vector buffer stored locally.
 *
 * Parameters:	sk - the socket on which the connection is taking place
 * 		sn - the sequence number being looked up in the ack vector
 * */
static inline unsigned char value_in_ackvector (struct sock *sk, u32 sn)
{				/* todo - this is a wildly inefficient way of doing this */
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	u32 gap;
	unsigned char *t, sv;

	if (tp->av_ts == tp->av_hs)	/* empty */
		return 0x03;		/* missing */

	if (sn >= tp->av_ts)
		gap = (sn - tp->av_ts);
	else				/* sn has wrapped but ts hasn't */
		gap = (sn + (0x1000000 - tp->av_ts));

	if (gap > tp->av_sz) 
		return 0x03; /* out of range */

	
	t = tp->av_tp + (gap/4);
	if (t >= (tp->ackvector + (tp->av_sz/4)))
		t -= (tp->av_sz /4);	/* wrapped */

	/* My understanding is that 2 bits are used to store the state for each ack. There is no length
	 * encoding going on here, therefore av_ts, av_ts + 1, ... av_ts + 3 are all stored in the av_tp byte.
	 * av_ts + 4 through to av_ts + 7 are stored in av_tp + 1, and so on. */

	/* Acks appear in reverse order within each byte. An example is given below to make things clearer:  
	* |3 2 1 0|7 6 5 4|11 10 9 8| etc. 
	* Why is it this way? I've got no idea but it is consistent at both ends so it should work OK - SHANE
	 * */
	sv = (gap %4) * 2;

	return (*t & (0x03 << sv)) >> sv;
}

/* Checks the clist to see if an incoming ack is acknowledging an ACK we sent earlier.
 *
 * Parameters:	tp - the dcp_opt structure containing all the connection information
 * 		sn - the ack number of the received ACK
 * */
static inline int  check_clist (struct dcp_opt *tp, u32 sn)
{
	struct ack_collapse_t *t, *z, **p;
	u32 gap;

	p = &(tp->av_clist);

	for (t=tp->av_clist; t; t= t->next)
	{

		/* Aha! We've found the sequence number in the av_clist - we've got ourselves an ACK of an ACK... 
		 * This means we can shrink the ack vector because some of the ack information has definitely reached the other
		 * end. */
		if (sn == t->localseq)
		{
			
			/* ackthru represents the highest ackn of the original sent ACK i.e. everything up to ackthru has
			 * now been fully acknowledged */
			if (t->ackthru >= tp->av_ts)
				gap = (t->ackthru - tp->av_ts);
			else				/* sn has wrapped but ts hasn't */
				gap = (t->ackthru + (0x1000000 - tp->av_ts));

#if DCP_DEBUG > 2
			printk ("%d ABLE TO SHRINK ACKVECTOR TO %d (gap=%d)\n",tp->whoami,t->ackthru,gap);
#endif
			if (gap < 8192)
			{
				gap = gap /4;	/* blocks */
				if (gap)
				{
					// shifting the tail pointer and seq. no forward
					tp->av_ts += gap * 4;

					if (tp->av_ts > tp->ackc_wsn)
					{
						tp->ackc_wsn = tp->av_ts;
						if (tp->ackc_wsn >= 0x1000000)
							tp->ackc_wsn -= 0x1000000;
					}

					if (tp->av_ts >= 0x1000000)
						tp->av_ts -= 0x1000000;

					if (tp->av_ts > tp->ackc_wsn)
						tp->ackc_wsn = tp->av_ts; /* before and after wrap */

					tp->av_tp += gap;
					if (tp->av_tp >= (tp->ackvector + (tp->av_sz/4)))
						tp->av_tp -= tp->av_sz/4;
				}
			}

			*p = NULL;

			// deleting clist entries, as all these outdated ACKs have been acknowledged when ackthru got acknowledged
			do
			{
				z = t;
				t = t->next;
				kmem_cache_free (dccp_slab_ack,z);
			}
			while (t);


			return 1;
		}
		p = &(t->next);
	}


	return 0;
}

//                                 add_clist (tp,lm,tp->seq);

/* Adds an entry to the clist which represents outgoing acks that acknowledge received acks
 *
 * Parameters:	tp - the dcp_opt structure containing connection information
 * 		remote - the sequence number of the received ack
 * 		local - the local sequence number
 * */
static inline void add_clist (struct dcp_opt *tp, u32 remote, u32 local)
{
	struct ack_collapse_t *ac;

	ac = kmem_cache_alloc (dccp_slab_ack,GFP_ATOMIC);
	if (!ac) return;

	ac->next = tp->av_clist;
	ac->localseq = local;
	ac->ackthru = remote;
	tp->av_clist = ac;
	return;
}

/* Creates the ack vector option by converting the local ack vector buffer into the appropriate
 * packet buffer
 *
 * Parameters:	sk - the socket on which the connection is taking place
 * 		l - the current length of the packet which the ack vector option is intended for
 * */
static unsigned char *dccp_generate_ackvector (struct sock *sk, int *l)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	unsigned char *pbuf,v,oldv,b, *d,leno;
	u32 n,ll,lm;
	signed short r;
	u16 y;

	//pbuf = kmalloc((tp->av_sz/4)+(tp->av_sz/125)+14+tp->opt_a_sz, GFP_ATOMIC);  
   pbuf = vmalloc((tp->av_sz/4)+(tp->av_sz/125)+14+tp->opt_a_sz); 
	pbuf[0] = 38;
	pbuf[1]=2;
	ll = 1;

	d = pbuf+2;

	if (tp->av_ts == tp->av_hs)
		goto dn;
	if (!tp->uav)
		goto dn;

	n = tp->ackn;
	r=-1;
	b =0;
	leno=0;

#if DCP_DEBUG > 2
	printk ("%d [%d] generate_ackvector: from %d to %d (=%d)\n",tp->whoami,tp->seq,tp->av_ts, n,tp->av_hs-1);
#endif

	oldv = value_in_ackvector(sk,n);
	y = 0;
	lm = n;

	do
	{
		b = (n == tp->av_ts);
		v = value_in_ackvector (sk,n); 
		if (!(v & 0x02))		/* rcvd */ /* I think this should be v & 0x03, or even better would be v | 0x02 - SHANE */ 
		{
			// if we have three unreceived, we've got entries in the ack vector for which we didn't
			// receive data packets
			if (++y == 3)
				add_clist (tp,lm,tp->seq);
		}
		else
			lm = n;

		// Add another byte to the ack vector, because either the state has changed or we've filled the six bits we allocate to length
		if ((v != oldv) || (r==63))
		{
			if (++leno >= 254)	/* need new option */
			{
				pbuf[ll] = 255;
				ll += 255;
				*d++ = 38;
				*d++ = 2;
				leno = 1;
			}
			/*	  printk ("av runlength (%X) covers %d\n",oldv,r); */

			// put the length in
			*d = r;
			// put the old state in there
			*d = *d | (oldv << 6);
			d++;

			oldv = v;
			r= 0;
		}
		else 
			// same state as before, increment the length counter
			r++;

		n = wrapdec_24(n);
	}
	while (!b);

	// putting the last byte in
	if (++leno >= 254)	/* need new option */
	{
		pbuf[ll] = 255;
		ll += 255;
		*d++ = 38;
		*d++ = 2;
		leno = 1;
	}

	/*  printk ("av runlength (%X) covers %d\n",oldv,r); */
	*d = r;
	*d = *d | (oldv << 6);
	d++;

	pbuf[ll] = 2+leno;


dn:
	/* if we have an outstanding timestamp echo request we're going to tack it on here */
	if (tp->ts_r_stamp)
	{
		*d++ = DCP_OPT_TS_ECHO;
		*d++ = 10;
		memcpy (d,&tp->ts_r,4);
		d+=4;
		tp->ts_r = jiffies - tp->ts_r_stamp;
		tp->ts_r = tp->ts_r * 1000000 / HZ; /* microseconds */
		tp->ts_r = htonl (tp->ts_r);
		memcpy (d,&tp->ts_r,4);
		d+=4;
	}
	// putting the rest of the outstanding options in
	if (tp->opt_a_sz)
	{
		memcpy (d,tp->opt_append,tp->opt_a_sz);
		d+= tp->opt_a_sz;
		tp->opt_a_sz = 0;
		tp->negibuf = 0;
	}



	/* we want to be on an 4 byte alignment when we're done */
	while ((d-pbuf) % 4)
		*d++ = 0;

	// update packet length information
	*l = d-pbuf;

	return pbuf;
}

/* Creates and sends either a CLOSE or CLOSEREQ packet
 *
 * Parameters:	sk - the socket on which the connection is taking place
 * 		close_or_closeR - the type of packet to create, either CLOSE or CLOSEREQ
 * */
static void dccp_send_close (struct sock *sk, unsigned char close_or_closeR)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct build_t b;
	unsigned char *pbuf;
	struct ipcm_cookie ipc;
	struct rtable *rt;

#if DCP_DEBUG > 1
	if (close_or_closeR == TYPE_CLOSE)
		printk ("%d dccp: send close\n",tp->whoami);
	else
		printk ("%d dccp: send close request\n",tp->whoami);
#endif

	ipc.oif = sk->bound_dev_if;
	ipc.opt = sk->protinfo.af_inet.opt;
	ipc.addr = sk->daddr;

	pbuf = kmem_cache_alloc (dccp_slab,GFP_ATOMIC);
	memcpy (pbuf,&sk->sport,2);
	memcpy (pbuf+2,&sk->dport,2);

	pbuf[4] = close_or_closeR;	

	dccp_write_24 (&tp->seq, pbuf+5,1); /* incs sn for me */

	pbuf[8] = 0x04;		/* header length - 4 32 bit words */

	pbuf[9] = dcp_write_ndp (&tp->ndp,1);	/* ndp=tp->ndp and cslen=15 */

	memset (pbuf+10,0,2);		/* checksum - starts at 0 for calc */

	pbuf[12] = 0;			/* reserved */

	clear_unacked (tp);
	
	dccp_write_24 (&tp->ackn, pbuf+13,0); 

	ip_route_output(&rt, sk->daddr, sk->saddr, RT_CONN_FLAGS(sk), ipc.oif);

	mkbuildt (&b, pbuf, 16,NULL);	/* no need for options here either */
	ip_build_xmit (sk,dccp_getfrag, &b,16,&ipc,rt,MSG_DONTWAIT);

	// Lets finish off TFRC if required
	if (tp->ccid == 3)
	{
		printk("Killing TFRC!\n");
		if(tp->send_ccb !=NULL)
			tfrc_send_free(tp->send_ccb);
		if(tp->recv_ccb !=NULL)
			tfrc_recv_free(tp->recv_ccb);


	}
	kmem_cache_free (dccp_slab,pbuf);

	return;
}


/* return len on success (or subset of len sent?) */
/* Creates and sends a DCCP DATAACK packet
 *
 * Parameters:	sk - the socket on which the packet will be sent
 * 		msg - a msghdr which contains the actual data to be sent
 * 		len - the length of the data
 * */
static int dccp_sendmsg(struct sock *sk, struct msghdr *msg, int len)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct build_t b;
	unsigned char *pbuf,*mt,*ackv,nma;
	struct ipcm_cookie ipc;
	struct rtable *rt;
	int ackvl;

#if DCP_DEBUG > 2
	printk ("dccp %d: sendmsg\n",tp->whoami);  
#endif

	// The connection is not yet fully established
	if (sk->state == DCP_REQUESTING)
		return -EWOULDBLOCK;

	if (sk->state != DCP_OPEN)
		return -ENOTCONN;

	if (!tp->ccid)		/* no cong control algorithm set */
		return -EWOULDBLOCK;

	/* inc the window counter the right ammount! */

	/* devide rtt by 4 */

	tp->wndcount+= 
		(jiffies - tp->lastsend)/(tp->rtt >> 2); //= time in what ever a jiffie is lets hope rtt is in same unit


	/* we're going to need to change the argument to buildxmit
	   so it takes the header we've already been sending.
	   plus msg->msg_iov as the data point.. make sure you add len
	   to header len */
	//Copy addresses
	ipc.oif = sk->bound_dev_if;
	ipc.opt = sk->protinfo.af_inet.opt;
	ipc.addr = sk->daddr;
	/*
	   if (tp->outstanding >=  tp->cwnd)
	//TODO: is this congestion control?????????????????
	if (wait_event_interruptible (tp->newdata, (tp->outstanding < tp->cwnd)))
	return  -ERESTARTSYS;
	*/
	if (sk->state != DCP_OPEN)
		return -ENOTCONN;

	pbuf = kmem_cache_alloc (dccp_slab,GFP_ATOMIC);
	nma=1;
	//Copy ports
	memcpy (pbuf,&sk->sport,2);
	memcpy (pbuf+2,&sk->dport,2);

	pbuf[4] = TYPE_DATAACK;	/* data-ack pkt, includes the 4 rsvd bits */
	pbuf[8] = 0x04;		/* header length - 4 32 bit words */
	memset (pbuf+10,0,2);		/* checksum - starts at 0 for calc */
	pbuf[12] = 0;			/* reserved */

	if(tp->ccid ==3);
	{
#if DCP_DEBUG > 2
		printk("ASK TFRC if we can send please?\n");
#endif
		tp->seq_snd = tp->seq;
		tp->ack_snd = tp->ackn;
		if (!tfrc_send_packet(tp->send_ccb,len))
		{
			//		printk("Thats ok, you won't let us send our packets but we don't hate you");
         
         /*shuldent mem for pbuf be free before retunr?
          * I'll try, BJORN. */
         kmem_cache_free(dccp_slab,pbuf);
          
			return -EWOULDBLOCK;
		}
#if DCP_DEBUG > 2
		printk("Thanks TFRC! (%d sent)\n",tp->seq);
#endif
	}
	spin_lock (&tp->rsem);   

	pbuf[9] = dcp_write_ndp (&tp->ndp,0);	/* ndp=tp->ndp and cslen=15 */
	// We're a DATAACK, there shouldn't be any unacked packets left
	tp->unacked = 0;
	//Write ack
	dccp_write_24 (&tp->ackn, pbuf+13,0); 

	if (tp->valid4 > 0)
		tp->valid4--;
	else
		if (!tp->checkingrtt)	/* track this data packet for rtt sample */
		{
			tp->checkingrtt = jiffies;
			tp->checkingsn = tp->seq; /* sn about to be sent */
			/* todo, add timestamp option */
			tp->valid4 = tp->cwnd;
		}

	charge_pkt (sk,tp->seq);	/* keep before incs sn */


	generic_option_negotiation (tp); /* cleaned out by genackvector */
	ackv =dccp_generate_ackvector (sk, &ackvl); /* keep before seq++ */
	dccp_write_24 (&tp->seq, pbuf+5,1); /* incs sn for me as ++ */

	if (ackvl)
	{
		pbuf[8] += ackvl /4;
		if ((ackvl + 16) > MAX_DCP_REQUEST_SZ)
		{
			nma = 0;
			//mt = kmalloc (ackvl+16,GFP_ATOMIC);
         mt = vmalloc(ackvl+16);
			memcpy (mt,pbuf,16);
			kmem_cache_free (dccp_slab,pbuf);
			pbuf = mt;
		}
		memcpy (pbuf+16,ackv,ackvl);
	}

	spin_unlock (&tp->rsem);   

	// getting the route and updating TFRC
	ip_route_output(&rt, sk->daddr, sk->saddr, RT_CONN_FLAGS(sk), ipc.oif);
	tfrc_send_packet_sent(tp->send_ccb,0,len);

	// building and sending the packet
	mkbuildt (&b, pbuf, 16+ackvl,msg->msg_iov);
	if (ip_build_xmit (sk,dccp_getfrag, &b,16+len+ackvl,&ipc,rt,MSG_DONTWAIT ))
		return -EACCES;

	// freeing the pbuf and ack vector
	if (nma)
		kmem_cache_free (dccp_slab,pbuf);
	else{
       vfree(pbuf);
		//kfree(pbuf);
   }
	//kfree(ackv);
   vfree(ackv);

	return len;

}


/* this is the recv() system call */

/* Waits until a packet enters the receive queue and puts the data portion into an iovec
 * 
 * Parameters:	sk - the socket on which the connection is taking place
 * 		msg - used to store the data portion of the packet
 * 		len - used to store the length of the data portion of the packet
 * 		noblock - 
 * 		flags - doesn't appear to be used?
 * 		addr_len - the length of the packsource address
 * */
int dccp_recvmsg(struct sock *sk, struct msghdr *msg, int len,
		int noblock, int flags, int *addr_len)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct sockaddr_in *sin = (struct sockaddr_in *)msg->msg_name;
	struct sk_buff *skb;
	u16 headerlen;
	int rv;
	char pf;

#if DCP_DEBUG > 2
	printk ("dccp %d: recvmsg in\n",tp->whoami);  
#endif
	//This might be a bug? surely it should be able to get the last packets before this happens?
	/* No, it sounds OK to me - SHANE */
	if (sk->state != DCP_OPEN)
		return -ENOTCONN;

	skb = NULL;
	rv = 0;
	pf = 0;

	if (addr_len)
		*addr_len=sizeof(*sin);

	if (noblock && (tp->rcvq_h == tp->rcvq_t) && (!tp->shake_defer))
		return -EWOULDBLOCK;

	do
	{
#if DCP_DEBUG > 2
		printk ("dccp %d: recvmsg premed h=%d t=%d\n",tp->whoami,tp->rcvq_h, tp->rcvq_t);  
#endif

		do
		{
			if (wait_event_interruptible (tp->newdata, DCP_DATA_EVENT_OPEN))
				return  -ERESTARTSYS;

			if (sk->state != DCP_OPEN)
				return -ENOTCONN;

			spin_lock (&tp->rsem);
			// Leave as a single '=', assignment is crucial here
			if ((skb = tp->shake_defer))
			{
				tp->shake_defer = NULL;
#if DCP_DEBUG > 1
				printk ("dccp %d: recvmsg satisfied from defer\n",tp->whoami);
#endif	      
			}
			else
				// checks if there is a new item in the receive queue	
				if (tp->rcvq_h != tp->rcvq_t )
				{
					skb = tp->rcvq[tp->rcvq_h];
					if (++tp->rcvq_h == DCP_RCVQ_SZ)
						tp->rcvq_h = 0;
				}
			spin_unlock (&tp->rsem);
		}
		while (!skb);

		switch (skb->data[4])
		{
			case TYPE_DATAACK:
				dccp_whatis_ackn (skb);	
				/* fall thru to take data */

			case TYPE_REQUEST:	/* this is leftover handshake data */
			case TYPE_RESPONSE:

			case TYPE_DATA:
				// placing the data into a msg iovec
				headerlen = skb->data[8] * 4;
				if (headerlen < skb->len)
				{
					if (skb_copy_datagram_iovec(skb, headerlen, msg->msg_iov,skb->len - headerlen))
						printk ("copy iovec maybe reports an err\n");
					rv = skb->len - headerlen;
				}
				pf = 1;
				break;

			case TYPE_ACK:
				printk("HELLO, do i ever reach here? ack in recv");
				dccp_whatis_ackn (skb);	

				break;


			case TYPE_CLOSEREQ:
			case TYPE_CLOSE:
			case TYPE_RESET:		
			default:			/* ignore */
				break;
		}

		if (sin)
		{
			sin->sin_family = AF_INET;
			sin->sin_port = sk->dport;
			sin->sin_addr.s_addr = skb->nh.iph->saddr;
			memset(sin->sin_zero, 0, sizeof(sin->sin_zero));
		}

		kfree_skb(skb);		
	}
	while ((!pf) &&  (sk->state == DCP_OPEN));

	if (sk->state != DCP_OPEN)
		rv = -ENOTCONN;

#if DCP_DEBUG > 2
	printk ("dccp %d: recvmsg out %d\n",tp->whoami,rv);  
#endif

	return rv;
}

/* Binds a socket for a listening server. The socket has already been created previously
 *
 * Parameters:	sk - the socket that is to be bound
 * 		uaddr - the socket address
 * 		addr_len - the size of uaddr
 * */
static int dccp_bind(struct sock *sk, struct sockaddr *uaddr, int addr_len)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct sockaddr_in *rv;
	struct sockaddr_dcp *dcpv;

#if DCP_DEBUG > 1
	printk ("dccp: bind\n");
#endif

	if (addr_len < sizeof(struct sockaddr_in)) 
		return -EINVAL;

	if (addr_len == sizeof (struct sockaddr_dcp))	/* with a service name */
	{
		dcpv = (struct sockaddr_dcp *)uaddr;
		rv = &(dcpv->in);
	}
	else
	{
		rv = (struct sockaddr_in *)uaddr; /* traditional */
		dcpv = NULL;
	}

	if (rv->sin_family != AF_INET) 
		return -EAFNOSUPPORT;

	// Can't bind the socket if a connection is in progress!
	if (sk->state != DCP_CLOSED)
		return -EISCONN;

	tp->wndcount =0; //Set it to 0 initially, not that it should matter

	// I'm going to be a server so I should be listening
	sk->state = DCP_LISTENING;
	// I'm not a server yet, though!
	tp->whoami = WHOAMI_BINDER;
	if (dcpv)
		tp->svc = dcpv->service;

#if DCP_DEBUG > 1
	printk ("registering on %08X for port %d\n",rv->sin_addr.s_addr,ntohs(rv->sin_port));
#endif

	sk->sport = rv->sin_port;

	// Since we don't know anything about the other end of the connection, we should use 0 for the socket hash until we know differently
	if (register_dccp_sk (sk, rv->sin_addr.s_addr /* local addr */, 0 /* remote addr */ , tp->svc,
				rv->sin_port /* lport */ , 0 /* rport */))
		return -EISCONN;

	return  0;
}

/* Deals with a receive buffer overflow of some sort.
 *
 * Parameters:	sk - the socket on which the packet came in
 * 		skb - the sk_buff representing the packet received
 * */
static int dccp_rcv_skb(struct sock * sk, struct sk_buff * skb)
{
	/* overflow */

#if DCP_DEBUG > 1
	printk ("dccp: rcv_skb\n");
#endif
	// just drop it
	kfree_skb(skb);
	return -1;
}

// The following two functions are only here to fulfill protocol requirements

/* Socket hashing function - doesn't do anything though. skhash should be used instead.
 *
 * Parameters:	sk - the socket to be hashed
 * */
static void dccp_v4_hash(struct sock *sk)
{
#if DCP_DEBUG > 1
	printk ("dccp: v4_hash\n");
#endif

	return;
}

/* Socket unhashing function - just sets the local port to 0.
 *
 * Parameters:	sk - the socket to be unhashed
 * */
static void dccp_v4_unhash(struct sock *sk)
{
#if DCP_DEBUG > 1
	printk ("dccp: v4unhash\n");
#endif
	sk->num = 0;

	return;
}

/* Creates a new DCCP socket and returns a pointer to that new socket. Used to create a socket for the Server to Client
 * half-connection upon receiving a REQUEST packet
 *
 * Parameters: temp - the socket on which the REQUEST was received, used as a model for creating this socket 
 * */
static struct sock *dccp_newsk (struct sock *temp)
{
	struct sock *sk;
	/* do init stuff too */
	sk = sk_alloc(PF_INET, GFP_KERNEL, 1);
	if (sk == NULL) 
		return NULL;

	memcpy (sk,temp,sizeof (*temp));


	sk->protinfo.af_inet.pmtudisc = IP_PMTUDISC_WANT;

	dccp_sk_init(sk);

	sk->destruct = inet_sock_destruct;
	sk->zapped	= 0;
	sk->family	= PF_INET;
	sk->protocol	= DCCP_PROTO;


	sk->protinfo.af_inet.mc_loop	= 1;
	sk->protinfo.af_inet.mc_ttl	= 1;
	sk->protinfo.af_inet.mc_index	= 0;
	sk->protinfo.af_inet.mc_list	= NULL;

	sk->num = 0;

	sk->bound_dev_if =  temp->bound_dev_if;
	sk->protinfo.af_inet.opt = temp->protinfo.af_inet.opt;

	sk->tp_pinfo.tp_dcp.flags =   temp->tp_pinfo.tp_dcp.flags;

	// Sloppy coding: this if condition should be only a single '='
	if ((sk->tp_pinfo.tp_dcp.hsdlen = temp->tp_pinfo.tp_dcp.hsdlen))
	{
		//sk->tp_pinfo.tp_dcp.hsd =   kmalloc (sk->tp_pinfo.tp_dcp.hsdlen, GFP_ATOMIC);
      sk->tp_pinfo.tp_dcp.hsd =   vmalloc (sk->tp_pinfo.tp_dcp.hsdlen);

		memcpy (sk->tp_pinfo.tp_dcp.hsd,temp->tp_pinfo.tp_dcp.hsd,sk->tp_pinfo.tp_dcp.hsdlen);
	}
	else
		sk->tp_pinfo.tp_dcp.hsd = NULL;

	sock_lock_init(sk);
	atomic_set(&sk->refcnt, 2);
	return sk;
}

/* Waits for an incoming connection and performs the Server end of the connection handshake.
 *
 * Parameters: 	sk - the socket that the server is listening on
 * 		flags - something that doesn't appear to be used
 * 		err - an error message will be stored here if appropriate
 * */
static struct sock *dccp_accept(struct sock *sk, int flags, int *err)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	struct sk_buff *skb;
	unsigned char *pbuf;
	u32 la,ra, rackn,isn,stamp;
	u16 lp,rp;
	struct sock *sk2;
	struct ipcm_cookie ipc;
	struct rtable *rt;
	int re;
	struct build_t b;

#if DCP_DEBUG > 1
	printk ("dccp: accept\n");
#endif

	rt = NULL;
	
	// if we aren't listening for an incoming connection then we aren't allowed to accept any incoming DCCP requests
	if (sk->state != DCP_LISTENING)
		goto bail;

	skb = NULL;

	do
	{
		if (wait_event_interruptible (tp->newdata, DCP_DATA_EVENT))
		{
			*err = -ERESTARTSYS;
			return NULL;
		}

		spin_lock (&tp->rsem);   
		// get the sk_buff containing the REQUEST 
		while ((!skb) &&(tp->rcvq_h != tp->rcvq_t ))
		{
			skb = tp->rcvq[tp->rcvq_h];
			// Checking that it is a REQUEST packet!
			if ((skb->len < 12) ||  ((skb->data[4] & 0xF0) != TYPE_REQUEST))
			{
				printk ("dccp accept: dropping non REQUEST packet on a listening socket\n");
				kfree_skb(skb);		/* drop it */
				skb = NULL;
			}
			if (++tp->rcvq_h == DCP_RCVQ_SZ)
				tp->rcvq_h = 0;
		}
		spin_unlock (&tp->rsem);
	}
	while (!skb);

	parse_dccp_pkt (skb,&la,&ra,NULL /*svc*/,&lp,&rp);

#if DCP_DEBUG > 1
	printk ("accept got request (aka syn) packet from %08X:%d\n",ra,ntohs(rp));
#endif
	/* new socket will be (ra,rp,svc,la,lp) */
	/* Create an equivalent socket to represent the Server to Client path */
	spin_lock (&tp->rsem);   
	sk2 = dccp_newsk (sk);
	spin_unlock (&tp->rsem);   

	tp->ackn = 0xefffffff;	/* reset ackn on bound socket */

	if (!sk2)
	{
		*err = -ENOBUFS;
		return NULL;
	}


	sk2->state = DCP_RESPOND;

	/* Just a reminder for me:
	 * 	la = Location Address
	 * 	lp = Location Port
	 * 	ra = Remote Address
	 * 	rp = Remote Port
	 * - SHANE */
	sk2->saddr = la;
	sk2->sport = lp;

	sk2->num = ntohs(lp);

	sk2->daddr =ra;
	sk2->dport = rp;

	sk2->err = 0;
	sk2->done = 0;

	tp = &(sk2->tp_pinfo.tp_dcp);	/* tp to new connected socket */
	tp->whoami = WHOAMI_SERVER;
	*err= 0;
   

	/* -- Send Response Packet -- */
	generic_option_parse (skb,sk2);/* was skipped on enq because whoami=3 */

	pbuf = kmem_cache_alloc (dccp_slab,GFP_ATOMIC);
	if (!pbuf)
	{
		printk ("dccp: accept failed to allocate buf\n");
		*err =  -ENOBUFS;
		return NULL;

	}

	register_dccp_sk (sk2, la,  ra, 0x00, lp,  rp);

	// putting the ports into the header
	memcpy (pbuf,&lp,2);
	memcpy (pbuf+2,&rp,2);

	pbuf[4] = TYPE_RESPONSE;	/* response pkt, includes the 4 rsvd bits */

	isn = tp->seq;
	dccp_write_24 (&tp->seq, pbuf+5,1);

	pbuf[9] = 0x1F;		/* 4bits ndp=1, cslen=15 (all) */

	memset (pbuf+10,0,2);		/* checksum - starts at 0 for calc */

	pbuf[12] = 0;			/* reserved */

	/* ack - isn from request */
	memcpy (pbuf+13,skb->data+5,3);

	clear_unacked (tp);

	pbuf[8] = 0x04;		/* header length - 6 32 bit words */

	/* we're going to use allow loaded handshake here */

	if ((skb->data[8] * 4) < skb->len) /* there is data on the request */
	{
		if (!(tp->flags & FLAG_ALLOW_LOADED_HANDSHAKE)) /*   we can ignore it but need to tell client that */
		{
			pbuf[pbuf[8]*4] = DCP_OPT_DISCARD;
			memset (pbuf+(pbuf[8]*4)+1,0,3);
			pbuf[8] += 1;
		}
		else
		{				/* we're going to have to consume handshake data later on,
						   so store a reference to it and don't free the skb*/
			tp->shake_defer =skb;
		}
	}

	generic_option_negotiation (tp);
	if (tp->opt_a_sz)
	{
		// adding any other options that need to be appended to the RESPONSE
		memcpy (pbuf+(pbuf[8]*4),tp->opt_append,tp->opt_a_sz);
		pbuf[8] += (tp->opt_a_sz / 4);
		tp->opt_a_sz = 0;
		tp->negibuf = 0;
	}

	ipc.oif = sk2->bound_dev_if;
	ipc.opt = sk2->protinfo.af_inet.opt;
	ipc.addr = sk2->daddr;

	// working out the routing
	re= ip_route_output(&rt, ra, la, RT_CONN_FLAGS(sk2), ipc.oif);

	if (re)
	{
		printk ("ip_route_output error\n");
		*err = re;
		kmem_cache_free (dccp_slab,pbuf);
		return NULL;
	}



	mkbuildt_k (&b, pbuf, pbuf[8]*4, tp->hsd,tp->hsdlen);

	/* ------------------------- */
	if (!tp->shake_defer)
		kfree_skb(skb);	      

	skb= NULL;
	tp->retries = 1;
	tp->retransmit_timer.data = (unsigned long) sk2;
	tp->timer_expired = 1;

	/* the accept side of the connection doesn't do retries, just one big timeout (15s) */
	tp->retransmit_timer.expires = jiffies + DCP_RESPOND_TIMEOUT;
	tp->rtt = 0xffff;
	stamp = jiffies;

	do
	{
		do
		{

			if (tp->retries >1)
			{
#if DCP_DEBUG > 1
				printk ("accept side unable to complete handshake\n");
#endif
				sk->state = DCP_CLOSED;
				unregister_dccp_sk(sk2);

				*err = -ETIMEDOUT;
				kmem_cache_free (dccp_slab,pbuf);
				return NULL;
			}

			/* synack */
			if (tp->timer_expired)
			{
				stamp = jiffies;
				ip_build_xmit (sk2,dccp_getfrag, &b,pbuf[8]*4 + tp->hsdlen,&ipc,rt,MSG_DONTWAIT ); 

#if DCP_DEBUG > 1
				printk ("synack transmitted\n");
#endif
			}

			tp->timer_expired = 0;

			add_timer (&tp->retransmit_timer);

			if (wait_event_interruptible (tp->newdata, DCP_DATA_EVENT_TO))
			{
				*err =  -ERESTARTSYS;
				del_timer_sync (&tp->retransmit_timer);
				kmem_cache_free (dccp_slab,pbuf);
				return NULL;
			}

			del_timer_sync (&tp->retransmit_timer);
		}
		while (tp->timer_expired);

		// OK, we've got a response to our RESPONSE packet
		spin_lock (&tp->rsem);   
		while ((!skb) && (tp->rcvq_h != tp->rcvq_t ))
		{
			skb = tp->rcvq[tp->rcvq_h];
			// it needs to be an ACK or DATA_ACK
			if ((skb->len < 12) ||  
					(((skb->data[4] & 0xF0) != TYPE_ACK) && ((skb->data[4] &0xF0) != TYPE_DATAACK)) )

			{
				printk ("dccp accepting: dropping non ack packet (%d) when in RESPOND state\n",skb->data[4] & 0xf0);
				kfree_skb(skb);		/* drop it */
				skb = NULL;
			}

			// the ack number needs to match the seq. number of the RESPONSE packet we sent out
			if (skb)	
			{
				rackn = dccp_whatis_ackn (skb);
				if (isn != rackn)
				{
					printk ("dccp: accept ack didn't match isn from synack\n");
					kfree_skb(skb);		/* drop it */
					skb = NULL;
				}
			}


			if (skb && ((skb->data[4] &0xF0) != TYPE_DATAACK))
			{			/* if its data too, we want to just leave it on the queue */
				kfree_skb(skb);	/* free skb, but don't clear ptr - DONT DEREFERNCE */
				if (++tp->rcvq_h == DCP_RCVQ_SZ)
					tp->rcvq_h = 0;
			}

		}
		spin_unlock (&tp->rsem);
	}
	while ((!skb) && (sk2->state == DCP_RESPOND));

	kmem_cache_free (dccp_slab,pbuf);
	if (tp->hsdlen)
	{			
		//kfree (tp->hsd);
      vfree(tp->hsd);

		tp->hsdlen = 0;
		tp->hsd = NULL;
	}  

	if (sk2->state != DCP_RESPOND)	/* probably reset */
		goto bail;
	tp->rtt = jiffies - stamp;
	if (tp->rtt < DCP_MIN_RTT)
		tp->rtt = DCP_MIN_RTT;

	tp->rtt_d = 0;
	tp->rto = tp->rtt;

	tp->atask.data =sk2;
	tp->flags |= FLAG_ACKSCHED;
	schedule_task(&tp->atask);

	sk2->state = DCP_OPEN;

#if DCP_DEBUG > 1
	printk ("accept: handshake complete - rtt set to %d jiffies\n",tp->rtt);
#endif
  
   	printk ("dccp_accept: err=%d \n",*err);
   	// return our nicely created socket
	return sk2;

bail:
	if (!*err)
		*err = -EINVAL;
	return NULL;
}


/* Assigns a port number to a socket. Another protocol required function.
 *
 * Parameters:	sk - the socket to assign a port to
 * 		snum - not actually used - required by other protocols, perhaps
 * */
static int dccp_get_port(struct sock *sk, unsigned short snum)
{
#if DCP_DEBUG > 1
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);
	printk ("dccp %d: gimme a port\n",tp->whoami);
#endif

	sk->num = dccp_port_assignment();

	return 0;
}


/* Having sent a CLOSE to the server, this function waits for the server to respond with a RESET. Periodically resends the CLOSE
 * if no response is forthcoming. If no response comes after a certain number of retries, we'll enter the TIMEWAIT state anyway
 *
 * Parameters:	vsk - the socket on which the soon to be closed connection is taking place
 * */
static void dccp_half_closed (void *vsk)
{
	struct sock *sk;
	struct dcp_opt *tp;
	struct sk_buff *skb;

	/* we're in a half closed state - we are a client who has
	   sent a close and are waiting for the reset.. we will periodically
	   resend the close.. eventually we either get the reset or give up..
	   we then set the state to TIMEWAIT and schedule timewait cleanup for
	   30 seconds from now */

	sk = vsk;
	tp  = &(sk->tp_pinfo.tp_dcp);
	skb = NULL;

	tp->retries = 1;
	tp->retransmit_timer.data = (unsigned long) sk;
	skb = NULL;
	tp->timer_expired = 0;
	tp->retransmit_timer.expires = jiffies + (1<< tp->retries >>1) * DCP_TIMEOUT;

	do
	{
		do
		{
			// we're giving up
			if (tp->retries == DCP_MAX_TRIES)
			{
				goto tw;
			}

			if (tp->timer_expired)
			{
				dccp_send_close (sk,TYPE_CLOSE);      /* send close */
				tp->retransmit_timer.expires = jiffies + (1<< tp->retries >>1) * DCP_TIMEOUT;
			}

			tp->timer_expired = 0;

			add_timer (&tp->retransmit_timer);

			if (wait_event_interruptible (tp->newdata, DCP_DATA_EVENT_TO ))
			{
				del_timer_sync (&tp->retransmit_timer);
				goto tw;
			}
			del_timer_sync (&tp->retransmit_timer);
		}
		while (tp->timer_expired);

		spin_lock (&tp->rsem);   

		while ((!skb) && (tp->rcvq_h != tp->rcvq_t ))
		{
			// we only want to receive a RESET packet here
			skb = tp->rcvq[tp->rcvq_h];
			if ((skb->len < 12) ||  ((skb->data[4] & 0xF0) != TYPE_RESET))
			{
				kfree_skb(skb);		/* drop it */
				skb = NULL;
			}

			if (++tp->rcvq_h == DCP_RCVQ_SZ)
				tp->rcvq_h = 0;
		}
		spin_unlock (&tp->rsem);
	}
	while (!skb);
	if (skb)
		kfree_skb(skb);		/* drop it */

// OK, we're done waiting for the reset, let's go into TIMEWAIT before completing the connection close
tw:
	enter_timewait (sk);
	return;
}


/* Does whatever is necessary to close the connection from this end of the connection
 *
 * Parameters:	sk - the socket on which the connection is taking place
 * 		timeout - not used by this function, presumably the amount of time before the connection auto-closes 
 * */
static void dccp_close(struct sock *sk, long timeout)
{
	struct dcp_opt *tp = &(sk->tp_pinfo.tp_dcp);

#if DCP_DEBUG > 1
	printk ("dccp: whoami=%d close state=%d\n",tp->whoami,sk->state);
#endif

	// timer is no longer necessary
	if (tp->rto_num != 0x1000000)
	{
		tp->rto_num = 0x1000000;
		del_timer_sync (&tp->retransmit_timer);
	}

	// if we're already in a closed state, don't need to do anything fancy
	if (sk->state == DCP_CLOSED)
	{
		unregister_dccp_sk (sk);	/* possibly redundant, can't hurt */
		return;
	}

	switch (tp->whoami)		/* servers can't send real active closes */
	{
		case WHOAMI_CLIENT:
			
			if (sk->state == DCP_REQUESTING)
			{
				dccp_reset (sk,0);
				enter_timewait (sk);
			}
			else
			{
				// if we're open then send a CLOSE packet to the server
				if (sk->state == DCP_OPEN) /* we could be in timewait if we got a rest */
				{
					dccp_send_close (sk,TYPE_CLOSE);      /* send close */
					dccp_half_closed(sk);	  
				}

				if (sk->state == DCP_HALF_CLOSE)
					dccp_half_closed(sk);

				sk->state = DCP_HALF_CLOSE;
			}
			break;

		case WHOAMI_SERVER:
			sk->state = DCP_HALF_CLOSE;
			dccp_send_close (sk,TYPE_CLOSEREQ);      /* send close request*/
			break;

		case WHOAMI_BINDER:
			sk->state = DCP_CLOSED;
			unregister_dccp_sk (sk);
			break;

		default:
			sk->state = DCP_CLOSED;
	}


	return;

}

/* Releases a DCCP socket, using inet's standard socket release function. Yet another protocol required function
 *
 * Parameters:	sk - the socket to be released
 * */
static int dccp_destroy_sock(struct sock *sk)
{
#if DCP_DEBUG > 1
	printk ("dccp: destroy\n");
#endif

	inet_sock_release(sk);

	return 0;
}

/* Presumably closes a connection - this function doesn't do anything though
 *
 * Parameters:	sk - the socket representing the connection to be closed
 * 		how - unused
 * */
static void dccp_shutdown(struct sock *sk, int how)
{
#if DCP_DEBUG > 1
	printk ("dccp: shutdown\n");
#endif

	return;
}

/* Describes the state of a connection with regards to whether it is able to send or receive packets.
 * 
 * Parameters:	file - a file structure, used by poll_wait
 * 		sock - the socket on which the connection is taking place
 * 		wait - a poll table, used by poll_wait
 * */
unsigned int dccp_poll(struct file * file, struct socket *sock, poll_table *wait)
{
	unsigned int mask;
	struct sock *sk = sock->sk;
	struct dcp_opt *tp;

	tp =  &(sk->tp_pinfo.tp_dcp);
	mask = 0;
	poll_wait(file, sk->sleep, wait);


	/* exceptional events? */
	if (sk->err)
	{
		printk ("dccp poll %d: marking err %d\n",tp->whoami,sk->err);
		mask |= POLLERR;
	}


	if (sk->shutdown == SHUTDOWN_MASK)
		mask |= POLLHUP;

	// if the connection is closed we cannot be send any packets - we may be able to receive a REQUEST though
	if (sk->state==DCP_CLOSED)
		mask |= POLLIN | POLLHUP;
	if (mask) return mask;

	// packets are coming in
	if (tp->rcvq_h != tp->rcvq_t)
		mask |= POLLIN | POLLRDNORM;

	// if we still have room in the congestion window to send more packets
	if (tp->outstanding <  tp->cwnd)
		mask |= POLLOUT | POLLWRNORM;
	else
	{
		// no room to send packets, set flags to reflect this
		set_bit(SOCK_ASYNC_NOSPACE, &sk->socket->flags);
		set_bit(SOCK_NOSPACE, &sk->socket->flags);
		if (tp->outstanding <  tp->cwnd) /* race condition, test again */
			mask |= POLLOUT | POLLWRNORM;
	}

	return mask;
}


//This lets us MMAP the stuff to do some of that good stuff
//ooooh yeah.

/* Takes some allocated virtual memory and remaps it to physical memory.
 * Used to keep TFRC rate information always in physical memory for easy access by client applications.
 * Also used for maintaining queues.
 *
 * Parameters:	file - unused
 * 		sock - the socket on which the connection is taking place
 * 		vma - a structure describing the virtual memory to be remapped
 * */
int dccp_mmap(struct file *file, struct socket *sock, struct vm_area_struct * vma)
{
	//This isn't very multipurpose
	unsigned long page,pos;
	unsigned long start = (unsigned long)vma->vm_start; 
	unsigned long size = (unsigned long)(vma->vm_end-vma->vm_start); 
	struct sock *sk = sock->sk;
	struct dcp_opt *tp;

	tp =  &(sk->tp_pinfo.tp_dcp);

	printk(KERN_INFO "mmaptest_mmap called\n");

	/* if userspace tries to mmap beyond end of our buffer, fail */ 
	if (size> DCCP_MAP_SIZE)
		return -EINVAL;

	/* start off at the start of the buffer */ 
	pos=(unsigned long) tp->tfrcmem;

	/* loop through all the physical pages in the buffer */ 
	/* Remember this won't work for vmalloc()d memory ! */
	while (size > 0) {
		/* remap a single physical page to the process's vma */ 
		page = virt_to_phys((void *)pos);
		/* fourth argument is the protection of the map. you might
		 * want to use vma->vm_page_prot instead.
		 */
		if (remap_page_range(start, page, PAGE_SIZE, PAGE_SHARED))
			return -EAGAIN;
		start+=PAGE_SIZE;
		pos+=PAGE_SIZE;
		size-=PAGE_SIZE;
	}
	return 0;


}

/* modeled on inet_stream_connect, but a little different cause of TCP
   magic embedded in that other one. prm 05/05/02 */

/* Some sort of general purpose socket connection function. As far as I can tell, this shouldn't be required
 * as dccp_connect() should cover the socket connection. Best to keep it here, just in case though.
 *
 * Parameters:	sock - the socket to be connected
 * 		uaddr - the address of the socket
 * 		addr_len - the length of the socket address
 * 		flags - a set of extra parameters relating to the socket
 * */
int inet_dccp_connect(struct socket *sock, struct sockaddr * uaddr,
		int addr_len, int flags)
{
	struct sock *sk=sock->sk;
	int err;

	lock_sock(sk);

	// we need to be unconnected if we want to connect
	switch (sock->state) {
		default:
			err = -EINVAL;
			goto out;
		case SS_CONNECTED:
			err = -EISCONN;
			goto out;
		case SS_CONNECTING:
			err = -EALREADY;
			/* Fall out of switch with err, set for this state */
			break;
		case SS_UNCONNECTED:
			err = -EISCONN;
			if (sk->state != TCP_CLOSE) 
				goto out;

			err = sk->prot->connect(sk, uaddr, addr_len);
			if (err < 0)
				goto out;

			sock->state = SS_CONNECTED;

			break;
	}


	/* Connection was closed by RST, timeout, ICMP error
	 * or another process disconnected us.
	 */
	if (sk->state == TCP_CLOSE)
		goto sock_error;

	/* sk->err may be not zero now, if RECVERR was ordered by user
	 * and error was received after socket entered established state.
	 * Hence, it is handled normally after connect() return successfully.
	 */

	sock->state = SS_CONNECTED;
	err = 0;

out:
	release_sock(sk);
	return err;

// some error has occured so lets clean things up and report a nice error message
sock_error:
	err = sock_error(sk) ? : -ECONNABORTED;
	sock->state = SS_UNCONNECTED;
	if (sk->prot->disconnect(sk, flags))
		sock->state = SS_DISCONNECTING;
	goto out;

}


struct proto_ops inet_dcp_ops = {
family:		PF_INET,

release:	inet_release,
bind:		inet_bind,
connect:	inet_dccp_connect, /* local */
socketpair:	sock_no_socketpair,
accept:		inet_accept, /* diff */
getname:	inet_getname, 
poll:		dccp_poll, /* diff */
ioctl:		inet_ioctl, 
listen:		inet_listen, /* diff */
shutdown:	inet_shutdown,
setsockopt:	inet_setsockopt,
getsockopt:	inet_getsockopt,
sendmsg:	inet_sendmsg,
recvmsg:	inet_recvmsg,
mmap:		dccp_mmap,/*sock_no_mmap,*/
sendpage:	sock_no_sendpage,
};



static struct proto dccp_prot = {
name:		"DCCP",
close:		dccp_close,
connect:	dccp_connect,
disconnect:	dccp_disconnect,
ioctl:		dccp_ioctl,
init:		dccp_sk_init,
setsockopt:	dccp_setsockopt,
getsockopt:	dccp_getsockopt,
sendmsg:	dccp_sendmsg,
recvmsg:	dccp_recvmsg,
bind:		dccp_bind,
backlog_rcv:	dccp_rcv_skb,
hash:		dccp_v4_hash,
unhash:		dccp_v4_unhash,
accept:         dccp_accept,
get_port:       dccp_get_port,
shutdown:	dccp_shutdown,
destroy:        dccp_destroy_sock
};

extern struct net_proto_family inet_family_ops;

static struct inet_protosw dccp_protosw =
{
type: SOCK_DCCP,
protocol: DCCP_PROTO,
prot: &dccp_prot,
ops: &inet_dcp_ops,
capability : -1,
no_check : 0,
flags : 0,
};


/* module init */
int __init dcp_init(void)
{
	int err;
	int i;

	// registering the protocol
	inet_add_protocol(&dccp_protocol);
	inet_register_protosw(&dccp_protosw);

	for (i=0;i<16;i++)
		dccp_table_lock[i] = RW_LOCK_UNLOCKED;

	spin_lock_init (&dccp_port_lock);
	spin_lock_init (&dccp_reset_lock);

	// creating kernel memory caches
	dccp_slab = kmem_cache_create ("DCCP_PBUFS",MAX_DCP_REQUEST_SZ,
			0, SLAB_HWCACHE_ALIGN,NULL,NULL);

	dccp_slab_sk = kmem_cache_create ("DCCP_SK",sizeof (struct dccp_sk_list_t),
			0, SLAB_HWCACHE_ALIGN,NULL,NULL);

	dccp_slab_ack = kmem_cache_create ("DCCP_ACKC",sizeof (struct ack_collapse_t),
			0, SLAB_HWCACHE_ALIGN,NULL,NULL);

	// setting up various lists to record used ports, sockets etc.
	memset (dccp_sk_hash,0,sizeof (struct dccp_sk_list_t *) * DCP_SK_HASH_SZ);

	dccp_port = 0;
	memset (dccp_port_map,0xff,DCCP_PORT_RANGE/8+1);

	/* We're creating a socket specifically to send RESET packets when we don't want to
	 * start a connection
	 * */
	reset_inode.i_mode = S_IFSOCK;
	reset_inode.i_sock = 1;
	reset_inode.i_uid = 0;
	reset_inode.i_gid = 0;
	init_waitqueue_head(&reset_inode.i_wait);
	init_waitqueue_head(&reset_inode.u.socket_i.wait);


	reset_socket->inode = &reset_inode;
	reset_socket->state = SS_UNCONNECTED;
	reset_socket->type=SOCK_RAW;

	err = inet_family_ops.create (reset_socket,DCCP_PROTO);
	reset_socket->sk->allocation=GFP_ATOMIC;
	reset_socket->sk->protinfo.af_inet.ttl = MAXTTL;

	reset_socket->sk->prot->unhash(reset_socket->sk);
	dccp_sk_init(reset_socket->sk);

	itask.routine = orphaned_reset;
	itask.data = NULL;

	printk ("dccp: loaded compiled on %s at %s\n",__DATE__,__TIME__);

	return 0;

}

/* Unloading the module */
static void __exit dcp_fini(void)
{
	/* Removing the protocol */
	inet_unregister_protosw(&dccp_protosw);
	if ( inet_del_protocol(&dccp_protocol) < 0 )
		printk("can't remove dccp inet_protocol struct\n");

	/* Releasing the orphan reset socket */
	inet_sock_release(reset_socket->sk);  
	// Releasing all that memory cache we'd allocated
	kmem_cache_destroy (dccp_slab);
	kmem_cache_destroy (dccp_slab_sk);
	kmem_cache_destroy (dccp_slab_ack);

	printk ("dccp: disabled\n");
	return;
}


#ifdef MODULE
module_init(dcp_init);
module_exit (dcp_fini);
#endif

MODULE_LICENSE("GPL");
MODULE_AUTHOR ("Patrick McManus <mcmanus@ducksong.com>");
MODULE_DESCRIPTION ("DCCP - Datagram Congestion Controlled Protocol");


/*
   Some notes on socket API binding and what they invoke at this layer

 * sk->rcv_saddr, sk->daddr, sk->num,  sk->dport, sk->saddr are all
 in network byte order

 sock_hold ups a refcount, sock_put decs it, potentially freeing it at 0

 socket()    -> init
 connect()   ->  connect
 bind()      -> bind
 send()      -> sendmsg
 accept()    -> accept

 close()     -> close

 sk_free() to get rid of a socket we allocated with sk_alloc() (from accept)

*/

/*
 * Copyright (c) 2003  Nils-Erik Mattsson 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * $Id: dcp.c,v 1.4 2004/11/13 22:53:01 bjohog Exp $
 */

/* This implementation conforms to the drafts of DCCP dated Mars 2003. The options used are window counter, elapsed time, loss event rate and receive rate.  No support for history discounting or oscillation prevention. */


/* Calculate the send rate according to TCP throughput eq.
 * args: s - packet size (in bytes)
 *       R - Round trip time  (in micro seconds)
 *       p - loss event rate  (0<=p<=1)
 * returns:  calculated send rate (in bytes per second)
 * Tested u:OK
 */
__inline double tfrc_calcX(u_int16_t s, u_int32_t R, double p){ 
	FLOOKUPTEST(p);
	if (FLOOKUP(p) == 0)
	{
		printk("p = %d R = %d s = %d\n", (int) p, R, s);
		panic("flookup ==0\n");
	}
	return  ( ((double) (s)) * 1000000.0 / ( ((double) R) * FLOOKUP(p)) );
}

/* 
 * Function called by the send timer (to send packet)
 * args: cb -  sender congestion control block
 */
void tfrc_time_send(void *ccb){
	struct tfrc_send_ccb *cb = (struct tfrc_send_ccb *) ccb;
	// int s; // compiler flags as unused 
	// struct inpcb *inp; // compiler flags as unused

	printk("TFRC: SEND TIMER TRIGGERED AT %ld", jiffies);
	panic("TFRC: SEND TIMER TRIGGERED AT %ld", jiffies);

	if(cb->state == TFRC_SSTATE_TERM){
		TFRC_DEBUG((LOG_INFO,"TFRC - Send timer is ordered to terminate. (tfrc_time_send)\n"));
		return;
	}
#ifdef LINUX_FROM_BSD
	/*	if (timer_pending(&cb->ch_stimer))
		{
		return;
		}
		*/
#else
	if(cb->ch_stimer.callout == NULL || callout_pending(cb->ch_stimer.callout)){
		TFRC_DEBUG((LOG_INFO,"TFRC - Callout pending. (tfrc_time_send)\n"));
		return;
	}
#endif
	//TODO: TOM
	//use McManus's sending stuff so don't bother locking
	/* aquire locks for dccp_output */
	//  s = splnet();
	//  INP_INFO_RLOCK(&dccpbinfo);
	//  inp = cb->pcb->d_inpcb;
	//  INP_LOCK(inp);
	//  INP_INFO_RUNLOCK(&dccpbinfo); 
	//
	//  cb->ch_stimer.callout = NULL;

	//	dccp_output(cb->pcb, 1);
	//tfrc_send_packet_sent(cb,0,-1); /* make sure we schedule next send time */

	/* release locks */
	//  INP_UNLOCK(inp);
	//    splx(s);
}

/* TODO:	dccp_tfrc.h defines term_timer as the handle to the scheduled send timer. This function needs
 * to be updated to replace ch_stimer with term_timer */

/*
 * Calculate and set when the send timer should expire
 * args: cb -  sender congestion control block
 *       t_now - timeval struct containing actual time
 * Tested u:OK
 */
void tfrc_set_send_timer(struct tfrc_send_ccb *cb, struct timeval t_now){
	struct timeval t_temp;
	long t_ticks;
	/* set send timer to fire in t_ipi - (t_now-t_nom_old) 
	 * or in other words after t_nom - t_now */
	t_temp = cb->t_nom;
	timevalsub(&(t_temp),&(t_now));

#ifdef TFRCDEBUG
	if(t_temp.tv_sec < 0 || t_temp.tv_usec < 0)
		panic("TFRC - scheduled a negative time! (tfrc_set_send_timer)\n");
#endif 

	t_ticks = (t_temp.tv_usec + 1000000*t_temp.tv_sec) / (1000000/hz);
	if (t_ticks == 0)
		t_ticks = 1;
	TFRC_DEBUG_TIME((LOG_INFO,"TFRC scheduled send timer to expire in %i ticks (hz=%u)\n",(int) t_ticks,hz));
#ifdef LINUX_FROM_BSD
	/*	init_timer(&cb->ch_stimer);
		cb->ch_stimer.data = (long)&cb;
		cb->ch_stimer.function = (void  *)(long)tfrc_time_send;
		cb->ch_stimer.expires  = t_ticks; //TODO: check this
		add_timer(&cb->ch_stimer);
		*/
#else
	cb->ch_stimer = timeout(tfrc_time_send,(void *) cb,t_ticks);  
#endif
}

/*
 * Update X by
 *    If (p > 0)
 *       x_calc = calcX(s,R,p);
 *       X = max(min(X_calc, 2*X_recv), s/t_mbi);
 *    Else
 *       If (t_now - tld >= R)
 *          X = max(min("2*X, 2*X_recv),s/R);
 *          tld = t_now;
 * args: cb -  sender congestion control block
 *       t_now - timeval struct containing actual time
 * Tested u:OK
 */ 
void tfrc_updateX(struct tfrc_send_ccb *cb, struct timeval t_now){
	double temp;
	struct timeval t_temp,t_rtt = {0,0};
#ifdef LINUX_FROM_BSD
	struct dcp_rateinfo *rateinf;
	rateinf= (struct dcp_rateinfo *)cb->pcb->tfrcmem;
#endif
	if (cb->p >= TFRC_SMALLEST_P){     /* to avoid large error in calcX */
		cb->x_calc = tfrc_calcX(cb->s, cb->rtt, cb->p);
		temp = 2*cb->x_recv;
		if (cb->x_calc < temp)
			temp = cb->x_calc;
		cb->x = temp;
		if(temp < ((double) (cb->s))/TFRC_MAX_BACK_OFF_TIME)
			cb->x = ((double) (cb->s))/TFRC_MAX_BACK_OFF_TIME;
#ifdef LINUX_FROM_BSD
		rateinf->rate = cb->x;
#endif
		TFRC_DEBUG((LOG_INFO,"TFRC updated send rate to "));
		PRINTFLOAT(cb->x);
		TFRC_DEBUG((LOG_INFO," bytes/s (tfrc_updateX, p>0)\n"));
	} else {
		t_rtt.tv_usec = cb->rtt % 1000000;
		t_rtt.tv_sec = cb->rtt / 1000000;
		t_temp = t_now;
		timevalsub(&t_temp, &(cb->t_ld));
		if (timevalcmp(&t_temp, &t_rtt, >=)) {
			temp = 2*cb->x_recv;
			if (2*cb->x < temp)
				temp = 2*cb->x;
			cb->x = ((double)(cb->s))*1000000.0/((double) (cb->rtt));
			if(temp > cb->x)
				cb->x = temp;
#ifdef LINUX_FROM_BSD
			rateinf->rate = cb->x;
#endif
			cb->t_ld = t_now;
			TFRC_DEBUG((LOG_INFO,"TFRC updated send rate to "));
			PRINTFLOAT(cb->x);
			TFRC_DEBUG((LOG_INFO," bytes/s (tfrc_updateX, p==0)\n"));
		} else
			TFRC_DEBUG((LOG_INFO,"TFRC didn't update send rate! (tfrc_updateX, p==0)\n"));
	} 
}

/* 
 * Function called by the no feedback timer
 * args:  cb -  sender congestion control block
 * Tested u:OK
 */
void tfrc_time_no_feedback(void *ccb){
#ifdef LINUX_FROM_BSD
	unsigned long linuxflags;
#endif
	u_int32_t next_time_out = 1;  /* remove init! */
	struct timeval t_now;
	struct tfrc_send_ccb *cb = (struct tfrc_send_ccb *) ccb;
#ifdef LINUX_FROM_BSD
	struct dcp_rateinfo *rateinf;
	rateinf= (struct dcp_rateinfo *)cb->pcb->tfrcmem;
#endif
	printk("TFRC no feedback triggered at %ld ccb=%#x\n", jiffies,(unsigned int)ccb);
	mtx_lock(&(cb->mutex));

	if(cb->state == TFRC_SSTATE_TERM){
		TFRC_DEBUG((LOG_INFO,"TFRC - No feedback timer is ordered to terminate\n"));
		goto nf_release;
	}
#ifdef LINUX_FROM_BSD
	if (timer_pending (&cb->ch_nftimer))
	{
		panic("NO FEEDBACK: timer called while timer pending\n");
		goto nf_release;
	}
#else
	if(cb->ch_nftimer.callout == NULL || callout_pending(cb->ch_nftimer.callout)){
		TFRC_DEBUG((LOG_INFO,"TFRC - Callout pending, exiting...(tfrc_time_no_feedback)\n"));
		goto nf_release;
	}
	cb->ch_nftimer.callout = NULL;
#endif  
	switch(cb->state){
		case TFRC_SSTATE_NO_FBACK:
			TFRC_DEBUG((LOG_INFO, "TFRC - no feedback timer expired, state NO_FBACK\n"));
			/* half send rate */
			cb->x = cb->x / 2;
			if (cb->x < ((double) (cb->s)) / TFRC_MAX_BACK_OFF_TIME)
				cb->x = ((double) (cb->s)) / TFRC_MAX_BACK_OFF_TIME;
#ifdef LINUX_FROM_BSD
			rateinf->rate = cb->x;
#endif

			TFRC_DEBUG((LOG_INFO,"TFRC updated send rate to "));
			PRINTFLOAT(cb->x);
			TFRC_DEBUG((LOG_INFO," bytes/s (tfrc_time_no_feedback\n"));

			/* reschedule next time out */

			next_time_out = (u_int32_t) ((2.0*((double) (cb->s))/ cb->x)*1000000.0);
			if (next_time_out < TFRC_INITIAL_TIMEOUT*1000000)
				next_time_out = TFRC_INITIAL_TIMEOUT*1000000;
			break;
		case TFRC_SSTATE_FBACK:
			/* Check if IDLE since last timeout and recv rate is less than 4 packets per RTT */ 

			if(!(cb->idle) || (cb->x_recv >= 4.0 * ((double)(cb->s)) / ((double) (cb->rtt))* 1000000.0)){
				TFRC_DEBUG((LOG_INFO, "TFRC - no feedback timer expired, state FBACK, not idle\n"));
				/* Half sending rate */

				/*  If (X_calc > 2* X_recv)
				 *    X_recv = max(X_recv/2, s/(2*t_mbi));
				 *  Else
				 *    X_recv = X_calc/4;
				 */
				if(cb->p >= TFRC_SMALLEST_P && cb->x_calc == 0.0)
					panic("TFRC - X_calc is zero! (tfrc_time_no_feedback)\n");

				/* check also if p i zero -> x_calc is infinity ?? */
				if(cb->p < TFRC_SMALLEST_P || cb->x_calc > 2*cb->x_recv){
					cb->x_recv = cb->x_recv / 2;
					if (cb->x_recv < ((double)cb->s)/(2*TFRC_MAX_BACK_OFF_TIME))
						cb->x_recv = ((double)cb->s)/(2*TFRC_MAX_BACK_OFF_TIME);
				} else {
					cb->x_recv = cb->x_calc / 4;
				}

				/* Update sending rate */
				microtime(&t_now);
				tfrc_updateX(cb,t_now);
			} 

			/* Schedule no feedback timer to
			 * expire in max(4*R, 2*s/X) 
			 */
			next_time_out = (u_int32_t) ((2.0*((double) (cb->s))/ cb->x)*1000000.0);
			if (next_time_out < cb->t_rto)
				next_time_out = cb->t_rto;

			break;
		default:
			printk("no feedback is in state: %d", cb->state);
			panic("tfrc_no_feedback: Illegal state!");
			break;
	}

	/* Set timer */

	next_time_out = next_time_out/(1000000/hz);
	if (next_time_out == 0)
		next_time_out = 1;

	TFRC_DEBUG_TIME((LOG_INFO,"TFRC scheduled no feedback timer to expire in %u ticks (hz=%u)\n",next_time_out,hz));
   printk("TFRC scheduled no feedback timer to expire in %u ticks (hz=%u)\n",next_time_out,hz);
	printk("EEEEEEP is the bug before this??\t");
#ifdef LINUX_FROM_BSD
	if (timer_pending(&cb->ch_nftimer))
		panic("TFRC NO FEEDBACK - TImer was pending");

	cb->ch_nftimer.data = (long)cb;
	cb->ch_nftimer.function = (void *)(long)tfrc_time_no_feedback;

    /*adding check for minimal timout, by BJORN. */
   if(next_time_out < 200)
       next_time_out = 200;
   /*end.*/

	cb->ch_nftimer.expires  = jiffies+next_time_out;//t_ticks; //TODO: check this

	if (cb->stopnftimer ==0)
		add_timer(&cb->ch_nftimer);

	else
		printk("NO FEEDBACK: timer is being deleted as we speak, lets no readd it cause thats antisocial!!!\n");
#else
	cb->ch_nftimer = timeout(tfrc_time_no_feedback, (void*)cb, next_time_out);
#endif
	/* set idle flag */
	cb->idle = 1;
nf_release:  
	//	mtx_unlock(&(cb->mutex));
	return;
}

/* Removes ccb from memory
 * args: ccb - ccb of sender
 */
void tfrc_send_term(void *ccb){
	struct tfrc_send_ccb *cb = (struct tfrc_send_ccb *) ccb;

	if(ccb == 0)
		panic("TFRC - Sender ccb is null! (free)");

	/* free sender */

	mtx_destroy(&(cb->mutex));

	free(cb, M_PCB);
	TFRC_DEBUG((LOG_INFO, "TFRC sender is destroyed\n"));
}


/* Functions declared in struct dccp_cc_sw */

/* Initialises the sender side
 * args:  pcb - dccp protocol control block
 * returns: pointer to a tfrc_send_ccb struct on success, otherwise 0
 * Tested u:OK
 */ 
void *tfrc_send_init(struct dccpcb* pcb){
	struct tfrc_send_ccb *ccb;
#ifdef LINUX_FROM_BSD
	struct dcp_rateinfo *rateinf;
	rateinf= (struct dcp_rateinfo *)pcb->tfrcmem;
#endif

	ccb = malloc(sizeof (struct tfrc_send_ccb), M_PCB, M_DONTWAIT | M_ZERO);
	if (ccb == 0){
		TFRC_DEBUG((LOG_INFO, "Unable to allocate memory for tfrc_send_ccb!\n"));
		return 0;
	}

	/* init sender */

	mtx_init(&(ccb->mutex), "TFRC Sender mutex", NULL, MTX_DEF | MTX_RECURSE);

	ccb->pcb = pcb;
	if (ccb->pcb->avgpsize >= TFRC_MIN_PACKET_SIZE && ccb->pcb->avgpsize <= TFRC_MAX_PACKET_SIZE)
		ccb->s = (u_int16_t) ccb->pcb->avgpsize;
	else
		ccb->s = TFRC_STD_PACKET_SIZE;

	TFRC_DEBUG((LOG_INFO,"TFRC - Sender is using packet size %u", ccb->s));

	ccb->x = (double) ccb->s;        /* set transmissionrate to 1 packet per second */
#ifdef LINUX_FROM_BSD
	rateinf->rate = ccb->x;
#endif
	ccb->t_ld.tv_sec = -1;
	ccb->t_ld.tv_usec = 0;

#ifdef TFRCDEBUG
	ccb->t_last_win_count.tv_sec = -1;
#endif

	/* init packet history */
	STAILQ_INIT(&(ccb->hist));

	ccb->state = TFRC_SSTATE_NO_SENT;

	TFRC_DEBUG((LOG_INFO, "TFRC sender initialised!\n"));
	dccpstat.tfrcs_send_conn++;
#ifdef LINUX_FROM_BSD

	init_timer((&ccb->ch_nftimer));
	init_timer(&ccb->term_timer);
	ccb->stopnftimer =0;

#endif
	return ccb;
} 

/* Free the sender side
 * args: ccb - ccb of sender
 * Tested u:OK
 */
void tfrc_send_free(void *ccb){
#ifdef LINUX_FROM_BSD
	unsigned long linuxflags;
#endif
	struct s_hist_entry *elm,*elm2;
	struct tfrc_send_ccb *cb = (struct tfrc_send_ccb *) ccb;

	TFRC_DEBUG((LOG_INFO, "TFRC send free called!\n"));

	if(ccb == 0)
		panic("TFRC - Sender ccb is null! (free)");

	/* uninit sender */

	/* get mutex */
	mtx_lock(&(cb->mutex));
	cb->state = TFRC_SSTATE_TERM;
	/* unschedule timers */
#ifdef LINUX_FROM_BSD
	//TODO

	//	del_timer(&(cb->ch_stimer));
	del_timer(&(cb->ch_nftimer));

#else
	if (cb->ch_stimer.callout)
		untimeout(tfrc_time_send, (void*) cb, cb->ch_stimer);
	if (cb->ch_nftimer.callout)
		untimeout(tfrc_time_no_feedback, (void*) cb, cb->ch_nftimer);
#endif
	/* Empty packet history */
	elm = STAILQ_FIRST(&(cb->hist));
	while (elm != NULL) {
		elm2 = STAILQ_NEXT(elm, linfo);
		free(elm, M_TEMP); /* M_TEMP ?? */
		elm = elm2;
	}
	STAILQ_INIT(&(cb->hist));

	mtx_unlock(&(cb->mutex));

	/* schedule the removal of ccb */
	//TODO: sort this out
#ifdef LINUX_FROM_BSD
	init_timer(&cb->term_timer);
	//if (timer_pending(&cb->term_timer))
	//		panic("Error timer was already pending!\n");
	cb->term_timer.function = (void *)(long)tfrc_send_term;
	cb->term_timer.data = (long)cb;
	cb->term_timer.expires = jiffies +  TFRC_SEND_WAIT_TERM*hz;

   add_timer(&cb->term_timer);
#else
	timeout(tfrc_send_term, (void*)cb, TFRC_SEND_WAIT_TERM*hz); 
#endif
}


/* Ask TFRC whether one can send a packet or not 
 * args: ccb  -  ccb block for current connection 
 * returns: 1 if ok, else 0.
 * Tested u:OK
 */ 
int tfrc_send_packet(void *ccb, long datasize){
#ifdef LINUX_FROM_BSD
	unsigned long linuxflags;
#endif
	struct s_hist_entry *new_packet;
	u_int8_t answer = 0;
	u_int8_t win_count = 0;
	u_int32_t uw_win_count = 0;
	struct timeval t_now, t_temp;
	struct tfrc_send_ccb *cb = (struct tfrc_send_ccb *) ccb;
#ifdef NOTFRCSENDER
	return 1;
#endif

	/* check if pure ACK or Terminating */
	if(datasize == 0 || cb->state == TFRC_SSTATE_TERM){
		return 1;
	} else if (cb->state == TFRC_SSTATE_TERM) {
		//What the hell? unreachable code??? -TOM
		TFRC_DEBUG((LOG_INFO,"TFRC - Asked to send packet when terminating!\n"));
		return 0;
	}

	/* we have data to send */
	mtx_lock(&(cb->mutex));

	/* check to see if we already have allocated memory last time */
	new_packet = STAILQ_FIRST(&(cb->hist));

	if((new_packet != NULL && new_packet->t_sent.tv_sec >= 0) || new_packet == NULL){  
		/* check to see if we have memory to add to packet history */
		new_packet = malloc(sizeof (struct s_hist_entry), M_TEMP, M_DONTWAIT); /*M_TEMP??*/
		if(new_packet == NULL){
			TFRC_DEBUG((LOG_INFO,"TFRC - Not enough memory to add packet to packet history (send refused)! (tfrc_send_packet)\n"));
			answer = 0;
			dccpstat.tfrcs_send_nomem++;
			goto sp_release;
		}
		new_packet->t_sent.tv_sec = -1; /* mark as unsent */
		STAILQ_INSERT_HEAD(&(cb->hist), new_packet, linfo);
	}

	switch (cb->state){
		case TFRC_SSTATE_NO_SENT :
			TFRC_DEBUG((LOG_INFO,"TFRC - DCCP ask permission to send first data packet (tfrc_send_packet)\n"));
			microtime(&(cb->t_nom));  /* set nominal send time for initial packet */
			t_now = cb->t_nom;


			/* init feedback timer */

			//TODO:
#ifdef LINUX_FROM_BSD
			//		del_timer((&cb->ch_nftimer));
			/*		if (timer_pending(&cb->ch_nftimer))
					panic("Error no feedback timer alreayd added\n");
					init_timer(&	cb->ch_nftimer);
					cb->ch_nftimer.function = (void *)(long)tfrc_time_no_feedback;
					cb->ch_nftimer.data =  (long) cb;
					cb->ch_nftimer.expires = jiffies + TFRC_INITIAL_TIMEOUT*hz; //TODO is this right??

					add_timer(&(cb->ch_nftimer));
					*/
        


         /*Changed by BJORN.seems to add function = NULL */

		//mod_timer(&(cb->ch_nftimer),jiffies + TFRC_INITIAL_TIMEOUT*hz); 
        
         cb->ch_nftimer.function = (void *)(long)tfrc_time_no_feedback;
			cb->ch_nftimer.data =  (long) cb;
         mod_timer(&(cb->ch_nftimer),jiffies + TFRC_INITIAL_TIMEOUT*hz); 

         /*End of changed by BJORN. */


#else
			cb->ch_nftimer = timeout(tfrc_time_no_feedback, (void *) cb, 
					TFRC_INITIAL_TIMEOUT*hz);
#endif
			win_count = 0;
			cb->t_last_win_count = t_now;
			TFRC_DEBUG((LOG_INFO, "TFRC - Permission granted. Scheduled no feedback timer (initial) to expire in %u ticks (hz=%u) (tfrc_send_packet)\n",TFRC_INITIAL_TIMEOUT*hz,hz)); 
			/* start send timer */

			/* Calculate new t_ipi */
			CALCNEWTIPI(cb);
			timevaladd(&(cb->t_nom),&(cb->t_ipi));  /* t_nom += t_ipi */
			/* Calculate new delta */
			CALCNEWDELTA(cb);
			tfrc_set_send_timer(cb,t_now);   /* if so schedule sendtimer */
			printk("TFRC send: CHANGEING STATES TO NO FEEDBACK!\n");
			cb->state = TFRC_SSTATE_NO_FBACK;
			answer = 1;
			break;
		case TFRC_SSTATE_NO_FBACK :
		case TFRC_SSTATE_FBACK :
			//TODO:
#ifdef LINUX_FROM_BSD	
			//TOFO
			//if (!timer_pending(&cb->ch_stimer))
			if(1) //lets always do this, and why the hell not i say?
			{
#else
				if(!(cb->ch_stimer.callout)){
#endif
					microtime(&t_now);

					t_temp = t_now;
					timevaladd(&(t_temp),&(cb->delta)); /* t_temp = t_now+delta */

					if (( timevalcmp(&(t_temp),&(cb->t_nom),>))){
						/* Packet can be sent */

#ifdef TFRCDEBUG
						if (cb->t_last_win_count.tv_sec == -1)
							panic("TFRC - t_last_win_count unitialized (tfrc_send_packet)\n");
#endif
						t_temp = t_now;
						timevalsub(&t_temp, &(cb->t_last_win_count));

						/* calculate win_count option */
						if(cb->state == TFRC_SSTATE_NO_FBACK){
							/* Assume RTT= t_rto(initial)/4 */
							uw_win_count = (((double) (t_temp.tv_sec)) + (((double) (t_temp.tv_usec))/1000000.0))/ (TFRC_INITIAL_TIMEOUT/(4.0*TFRC_WIN_COUNT_PER_RTT));
						}else{
							uw_win_count = (((double) (t_temp.tv_sec)) + (((double) (t_temp.tv_usec))/1000000.0))/ (((double) (cb->rtt))/(1000000.0*TFRC_WIN_COUNT_PER_RTT));
						}
						uw_win_count += cb->last_win_count; 
						win_count = uw_win_count % TFRC_WIN_COUNT_LIMIT;
						answer = 1;
					} else {
						answer = 0;
					}
				} else {
					answer = 0;
				}
				break;
				break;
				default:
				panic("tfrc_send_packet: Illegal state!");
				break;
			}

			/* can we send? if so add options and add to packet history */
			if(answer){
				/* Add packet to history */

				new_packet->win_count = win_count;

				/* todo: remove old option */

				/* add option */
				if(dccp_add_option(cb->pcb, TFRC_OPT_WINDOW_COUNT,(char *) &win_count, 1)){
					TFRC_DEBUG((LOG_INFO,"TFRC - Add window counter option failed, send refused! (tfrc_send_packet)!\n"));
					answer = 0;
					dccpstat.tfrcs_send_erropt++;
				}
			}
sp_release:  
			mtx_unlock(&(cb->mutex));
			return answer;
	}

	/* Notify sender that a packet has been sent 
	 * args: ccb - ccb block for current connection
	 *	 moreToSend - if there exists more packets to send
	 *       dataSize -   packet size
	 */
	void tfrc_send_packet_sent(void *ccb, int moreToSend, long datasize){
#ifdef LINUX_FROM_BSD
		unsigned long linuxflags;
#endif
		struct timeval t_now; // t_temp variable unused according to compiler
		struct s_hist_entry *packet;
		struct tfrc_send_ccb *cb = (struct tfrc_send_ccb *) ccb;

#ifdef NOTFRCSENDER
		return;
#endif 

		if (cb->state == TFRC_SSTATE_TERM) {
			TFRC_DEBUG((LOG_INFO,"TFRC - Packet sent when terminating!\n"));
			return;
		}

		mtx_lock(&(cb->mutex));
		microtime(&t_now);

		/* check if we have sent a data packet */
		if(datasize > 0){
			/* add send time to history */
			packet = STAILQ_FIRST(&(cb->hist));
			if(packet == NULL)
				panic("TFRC - Packet does not exist in history! (tfrc_send_packet_sent)");
			else if(packet != NULL && packet->t_sent.tv_sec >= 0)
				panic("TFRC - No unsent packet in history! (tfrc_send_packet_sent)");
			packet->t_sent = t_now;
			packet->seq = cb->pcb->seq_snd;
			/* check if win_count have changed */
			if(packet->win_count != cb->last_win_count){
				cb->t_last_win_count = t_now;
				cb->last_win_count = packet->win_count;
			}
			TFRC_DEBUG((LOG_INFO, "TFRC - Packet sent (%u,%u,(",packet->seq,packet->win_count));
			PRINTTIMEVALu(&(packet->t_sent));
			TFRC_DEBUG((LOG_INFO, ")) (tfrc_send_packet_sent)\n"));
			cb->idle = 0;
		}

		/* if timer is running, do nothing */
#ifdef LINUX_FROM_BSD

		/*	if(timer_pending(&cb->ch_stimer)){
			goto sps_release;
			}
			*/
#else
		if(cb->ch_stimer.callout){
			goto sps_release;
		}
#endif

		switch (cb->state){
			case TFRC_SSTATE_NO_SENT :
				/* if first was pure ack */
				if(datasize == 0){
					goto sps_release;
				} else
					panic("TFRC - First packet sent is noted as a data packet in tfrc_send_packet_sent\n"); 
				break;
			case TFRC_SSTATE_NO_FBACK :
			case TFRC_SSTATE_FBACK :
				if(datasize <= 0){ /* we have ack (or simulate a sent packet which never can have moreToSend */
					moreToSend = 0;
				} else {
					/* Calculate new t_ipi */
					CALCNEWTIPI(cb);
					timevaladd(&(cb->t_nom),&(cb->t_ipi));  /* t_nom += t_ipi */
					/* Calculate new delta */
					CALCNEWDELTA(cb);
				}
#ifdef WHATTHEHELL
				if(!moreToSend){
					/* loop until we find a send time in the future */
					microtime(&t_now);
					t_temp = t_now;
					timevaladd(&(t_temp),&(cb->delta)); /* t_temp = t_now+delta */
					while((timevalcmp(&(t_temp),&(cb->t_nom),>))){
						/* Calculate new t_ipi */
						CALCNEWTIPI(cb);
						timevaladd(&(cb->t_nom),&(cb->t_ipi));  /* t_nom += t_ipi */
						/* Calculate new delta */
						CALCNEWDELTA(cb);

						microtime(&t_now);
						t_temp = t_now;
						timevaladd(&(t_temp),&(cb->delta)); /* t_temp = t_now+delta */
					}
					tfrc_set_send_timer(cb,t_now);
				} else {
					microtime(&t_now);
					t_temp = t_now;
					timevaladd(&(t_temp),&(cb->delta)); /* t_temp = t_now+delta */
					/* Check if next packet can not be sent immediately */
					if(!(timevalcmp(&(t_temp),&(cb->t_nom),>))){
						tfrc_set_send_timer(cb,t_now);   /* if so schedule sendtimer */
					}
				}
#endif
				break;
			default:
				panic("tfrc_send_packet_sent: Illegal state!");
				break;
		}

sps_release:
		mtx_unlock(&(cb->mutex));
	}

	/* Notify that a an ack package was received (i.e. a feedback packet)
	 * args: ccb  -  ccb block for current connection
	 */ 
	void tfrc_send_packet_recv(void *ccb, char *options, int optlen){
#ifdef LINUX_FROM_BSD
		unsigned long linuxflags;
#endif
		u_int32_t  next_time_out; 
		struct timeval t_now;
		int res;
		u_int16_t t_elapsed;
		u_int32_t pinv;
		u_int32_t x_recv;

		u_int32_t r_sample;

		struct s_hist_entry *elm,*elm2;
		struct tfrc_send_ccb *cb = (struct tfrc_send_ccb *) ccb;

#ifdef NOTFRCSENDER
		return;
#endif

		if (cb->state == TFRC_SSTATE_TERM) {
			TFRC_DEBUG((LOG_INFO,"TFRC - Sender received a packet when terminating!\n"));
			return;
		}

		/* we are only interested in ACKs */
		if (!(cb->pcb->type_rcv == DCCP_TYPE_ACK || cb->pcb->type_rcv == DCCP_TYPE_DATAACK))
		{
			printk("wasn't an ack go home\n");
			return;
		}

		res = dccp_get_option(options, optlen,TFRC_OPT_LOSS_RATE ,(char *) &pinv,4);
		if (res == 0){
			TFRC_DEBUG((LOG_INFO, "TFRC - Missing Loss rate option! (tfrc_send_packet_recv)\n"));
			dccpstat.tfrcs_send_noopt++;
			return;
		}

		res = dccp_get_option(options, optlen,TFRC_OPT_ELAPSED_TIME,(char *) &t_elapsed,2);

		if (res == 0){
			TFRC_DEBUG((LOG_INFO, "TFRC - Missing elapsed time option! (tfrc_send_packet_recv)\n"));
			dccpstat.tfrcs_send_noopt++;
			return;
		}

		res = dccp_get_option(options, optlen,TFRC_OPT_RECEIVE_RATE,(char *) &x_recv,4);
		if (res == 0){
			TFRC_DEBUG((LOG_INFO, "TFRC - Missing x_recv option! (tfrc_send_packet_recv)\n"));
			dccpstat.tfrcs_send_noopt++;
			return;
		}

		dccpstat.tfrcs_send_fbacks++;
		/* change byte order */
		t_elapsed = ntohs(t_elapsed);
		x_recv = ntohl(x_recv);
		pinv = ntohl(pinv);

		TFRC_DEBUG((LOG_INFO, "TFRC - Receieved options on ack %u: pinv=%u, t_elapsed=%u, x_recv=%u ! (tfrc_send_packet_recv)\n",cb->pcb->ack_rcv,pinv,t_elapsed,x_recv));

		mtx_lock(&(cb->mutex));

		switch (cb->state){
			case TFRC_SSTATE_NO_FBACK :
			case TFRC_SSTATE_FBACK :
				/* Calculate new round trip sample by
				 * R_sample = (t_now - t_recvdata)-t_delay;
				 */

				/* get t_recvdata from history */
				elm = STAILQ_FIRST(&(cb->hist));
				while (elm != NULL) {
					if (elm->seq == cb->pcb->ack_rcv)
						break;
					elm = STAILQ_NEXT(elm, linfo);
				}

				if(elm == NULL){
					TFRC_DEBUG((LOG_INFO,"TFRC - Packet does not exist in history (seq=%u)! (tfrc_send_packet_recv)",cb->pcb->ack_rcv));
					goto sar_release;
				}

				/* Update RTT */
				microtime(&t_now);
				timevalsub(&t_now, &(elm->t_sent));
				r_sample = t_now.tv_sec*1000000+t_now.tv_usec;
				r_sample = r_sample - ((u_int32_t)t_elapsed)*1000; /* t_elapsed in ms */

				/* Update RTT estimate by 
				 * If (No feedback recv)
				 *    R = R_sample;
				 * Else
				 *    R = q*R+(1-q)*R_sample;
				 */
				if (cb->state == TFRC_SSTATE_NO_FBACK){
					cb->state = TFRC_SSTATE_FBACK;
					cb->rtt = r_sample;
				} else {
					cb->rtt =(u_int32_t)  ( TFRC_RTT_FILTER_CONST * ((double) (cb->rtt)) +
							(1-TFRC_RTT_FILTER_CONST)* ((double) (r_sample)) );
				}

				TFRC_DEBUG((LOG_INFO, "TFRC - New RTT estimate %u (tfrc_send_packet_recv)\n",cb->rtt));

				/* Update timeout interval */
				cb->t_rto = 4*cb->rtt;

				/* Update receive rate */
				cb->x_recv = ((double) x_recv)/8.0;   /* x_recv in bits per second*/

				/* Update loss event rate */
				if (pinv == 0)
					cb->p = 0;
				else {
					cb->p = 1.0 / ((double) pinv);

					if(cb->p < TFRC_SMALLEST_P){
						cb->p = TFRC_SMALLEST_P;
						TFRC_DEBUG((LOG_INFO, "TFRC - Smallest p used!\n"));
					}
				}

				/* unschedule no feedback timer */

#ifdef LINUX_FROM_BSD

				cb->stopnftimer =1;
				

				if(!del_timer_sync(&cb->ch_nftimer))

					panic("error timer was running");
				//INTERUPT CONTEXT!@!!!

				cb->stopnftimer =0;

#else
				if(cb->ch_nftimer.callout != NULL){
					untimeout(tfrc_time_no_feedback, (void *) cb, cb->ch_nftimer);
				}
#endif

				/* Update sending rate */
				microtime(&t_now);
				tfrc_updateX(cb, t_now);

				/* Update next send time */
				timevalsub(&(cb->t_nom), &(cb->t_ipi));

				/* Calculate new t_ipi */
				CALCNEWTIPI(cb);
				timevaladd(&(cb->t_nom),&(cb->t_ipi));  /* t_nom += t_ipi */
				/* Calculate new delta */
				CALCNEWDELTA(cb);

#ifdef LINUX_FROM_BSD
				//Since this is scheduling an update now, it just gets rid of the acktimeout


				//			del_timer(&cb->ch_stimer);
#else
				if (cb->ch_stimer.callout != NULL)
					untimeout(tfrc_time_send,(void *) cb, cb->ch_stimer);

				cb->ch_stimer.callout = NULL;
#endif
				//			dccp_output(cb->pcb, 1); //TODO: WHY ARE WE ACKING AN ACK???
				//									// We're not we're trying to send a queuend data packet???

				//			tfrc_send_packet_sent(cb,0,-1); /* make sure we schedule next send time */

				/* remove all packets older than the one acked from history */
				/* elm points to acked package! */

				elm2 = STAILQ_NEXT(elm,linfo);

				while(elm2 != NULL){
					STAILQ_REMOVE(&(cb->hist),elm2,s_hist_entry,linfo);
					free(elm2,M_TEMP);
					elm2 = STAILQ_NEXT(elm,linfo);
				}

				/* Schedule no feedback timer to
				 * expire in max(4*R, 2*s/X) 
				 */
				next_time_out = (u_int32_t) (2*((double) (cb->s))*1000000 / cb->x) ;
				if (next_time_out < cb->t_rto)
					next_time_out = cb->t_rto;
				TFRC_DEBUG_TIME((LOG_INFO, "TFRC - Scheduled no feedback timer to expire in %u ticks (%u us) (hz=%u)(tfrc_send_packet_recv)\n",next_time_out/(1000000/hz),next_time_out,hz)); 
				next_time_out = next_time_out/(1000000/hz);
				if(next_time_out == 0)
					next_time_out = 1;
#ifdef LINUX_FROM_BSD
				if (timer_pending(&cb->ch_nftimer))
					printk("Error timer was already pending");
				else
				{

					cb->ch_nftimer.data = (long)cb;
					cb->ch_nftimer.function = (void  *)(long)tfrc_time_no_feedback;

                 /*adding check for minimal timout, by BJORN. */
               if(next_time_out < 200)
                   next_time_out = 200;
               /*end.*/

               
					cb->ch_nftimer.expires  = jiffies+ next_time_out;//t_ticks; //TODO: check this

					add_timer(&cb->ch_nftimer);

				}
#else
				cb->ch_nftimer = timeout(tfrc_time_no_feedback, (void*)cb, next_time_out);
#endif
				/* set idle flag */
				cb->idle = 1;   
				break;
			default:
				printk("State is %d",cb->state);
				panic("tfrc_send_packet_recv: Illegal state!");
				break;
		}
sar_release:  
		mtx_unlock(&(cb->mutex));
	}

	/* Receiver side */

	/*
	 * Calculate avarage loss Interval I_mean
	 * args: cb - ccb of receiver
	 * returns: avarage loss interval 
	 * Tested u:OK
	 */
	double tfrc_calcImean(struct tfrc_recv_ccb *cb){
		struct li_hist_entry *elm;
		double I_tot;
		double I_tot0 = 0.0;
		double I_tot1 = 0.0;
		double W_tot = 0.0;
		int i;
		elm = TAILQ_FIRST(&(cb->li_hist));

		for (i = 0; i< TFRC_RECV_IVAL_F_LENGTH; i++) {
#ifdef TFRCDEBUG
			if (elm == 0)
				goto I_panic;
#endif
			I_tot0 = I_tot0 + (elm->interval * tfrc_recv_w[i]);
			W_tot = W_tot + tfrc_recv_w[i];
			elm = TAILQ_NEXT(elm, linfo);
		}

		elm = TAILQ_FIRST(&(cb->li_hist));
		elm = TAILQ_NEXT(elm, linfo);

		for (i = 1; i <= TFRC_RECV_IVAL_F_LENGTH; i++) {
#ifdef TFRCDEBUG
			if (elm == 0)
				goto I_panic;
#endif
			I_tot1 = I_tot1 + (elm->interval * tfrc_recv_w[i-1]);
			elm = TAILQ_NEXT(elm, linfo);
		}

		I_tot = I_tot0;       /* I_tot = max(I_tot0, I_tot1) */
		if (I_tot0 < I_tot1)
			I_tot = I_tot1;

		if(I_tot < W_tot) 
			I_tot = W_tot;

		return (I_tot/W_tot);
#ifdef TFRCDEBUG
I_panic:  if (elm == NULL)
			  panic("TFRC - Missing entry in interval history! (tfrc_calcImean)");
#endif
	}

	/*
	 * Send a feedback packet
	 * args: cb - ccb for receiver
	 * Tested u:OK
	 */
	void tfrc_recv_send_feedback(struct tfrc_recv_ccb *cb){
		u_int32_t x_recv, pinv;
		u_int16_t t_elapsed;
		struct r_hist_entry *elm;
		struct timeval t_now, t_temp, t_debug;
		int num;

#if DCP_DEBUG > 0
      printk("tfrc_recv_send_feedback has been called.\n");
#endif

		if (cb->p < 0.00000000025)  /* -> 1/p > 4 000 000 000 */
			pinv = 0;
		else
			pinv = (u_int32_t) ((double) 1.0 / cb->p);

		switch (cb->state){
			case TFRC_RSTATE_NO_DATA :
				x_recv = 0;
				break;
			case TFRC_RSTATE_DATA :
				/* Calculate x_recv */
				microtime(&t_temp);
				t_debug.tv_sec= t_temp.tv_sec;
				t_debug.tv_usec= t_temp.tv_usec;
				timevalsub(&t_temp,&(cb->t_last_feedback));

				x_recv = (u_int32_t) (((double) (cb->bytes_recv*8)) / 
						( ((double) t_temp.tv_sec) + ((double) t_temp.tv_usec)/1000000.0));
				if(x_recv == 0)
				{
					if (t_temp.tv_usec == 0 && t_temp.tv_sec ==0)
					{
						//ABORT!!
						return;
					}
					else
					{
#if DCP_DEBUG >2 
						printk("Havn't recieved any packets 0 xrecv (%d)  (%d . %06d) = (%d . %06d) (%ld . %06d) %ld\n", cb->bytes_recv,(int)t_temp.tv_sec ,(int) t_temp.tv_usec,(int) cb->t_last_feedback.tv_sec,(int)cb->t_last_feedback.tv_usec, jiffies, (int) t_debug.tv_sec,t_debug.tv_usec);
#endif
					}
				}
				break;
			default:
				panic("tfrc_recv_send_feedback: Illegal state!");
				break;
		}

		/* Find largest win_count so far (data packet with highest seqnum so far) */
		num = 1;
		TFRC_RECV_FINDDATAPACKET(cb,elm,num);

		if(elm == NULL)
			panic("No data packet in history! (tfrc_recv_send_feedback)");


		microtime(&t_now);
		timevalsub(&t_now, &(elm->t_recv));
		t_elapsed = (u_int16_t)( t_now.tv_sec*1000 + t_now.tv_usec / 1000 );

		/* change byte order */
		t_elapsed = htons(t_elapsed);
		x_recv = htonl(x_recv);
		pinv = htonl(pinv);

		/* add options from variables above */
		if(dccp_add_option(cb->pcb, TFRC_OPT_LOSS_RATE, (char*) &pinv, 4)
				|| dccp_add_option(cb->pcb, TFRC_OPT_ELAPSED_TIME, (char*) &t_elapsed, 2)
				|| dccp_add_option(cb->pcb, TFRC_OPT_RECEIVE_RATE, (char*) &x_recv, 4)){
			TFRC_DEBUG((LOG_INFO,"TFRC - Can't add options, aborting send feedback (tfrc_send_feedback)\n"));
			/* todo: remove options */
			dccpstat.tfrcs_recv_erropt++;
			return;
		}


		cb->pcb->ack_snd = elm->seq;
		cb->last_counter = elm->win_count;
		cb->seq_last_counter = elm->seq;
		microtime(&(cb->t_last_feedback));   
		cb->bytes_recv = 0;
		TFRC_DEBUG((LOG_INFO, "TFRC - Sending a feedback packet with (t_elapsed %u,pinv %u, x_recv %u, ack=%u) (tfrc_recv_send_feedback)\n",ntohs(t_elapsed),ntohl(pinv), ntohl(x_recv),elm->seq));
		dccpstat.tfrcs_recv_fbacks++;
		dccp_output(cb->pcb, 1); 
	}


	/*
	 * Calculate first loss interval
	 * args: cb - ccb of the receiver
	 * returns: loss interval
	 * Tested u:OK
	 */
	u_int32_t tfrc_recv_calcFirstLI(struct tfrc_recv_ccb *cb){
		struct r_hist_entry *elm,*elm2;
		struct li_hist_entry *li_elm;
		struct timeval t_temp;
		double t_rtt;
		int temp;
		double x_recv,fval;
		int win_count;

		temp = 1;
		TFRC_RECV_FINDDATAPACKET(cb,elm,temp);

		if(elm == NULL)
			panic("Packet history contains no data packets! (tfrc_recv_calcFirstLI)\n");
		t_temp = elm->t_recv;
		win_count = elm->win_count;
		elm2 = elm;
		TFRC_RECV_NEXTDATAPACKET(cb,elm2); 
		while(elm2 != NULL){
			temp = win_count-(int) (elm2->win_count);
			if(temp < 0)
				temp = temp + TFRC_WIN_COUNT_LIMIT;

			if(temp > 4)
				break;
			elm = elm2;
			TFRC_RECV_NEXTDATAPACKET(cb,elm2); 
		}

		if(elm2 == NULL){
			TFRC_DEBUG((LOG_INFO,"TFRC - Could not find a win_count interval > 4 \n"));
			elm2=elm;
			if (temp == 0){
				TFRC_DEBUG((LOG_INFO,"TFRC - Could not find a win_count interval > 0. Defaulting to 1 (tfrc_recv_calcFirstLI)\n"));
				temp = 1;
			}
		}
		PRINTRCCB(cb,elm,li_elm);
		timevalsub(&t_temp, &(elm2->t_recv));
		t_rtt = ((double) (t_temp.tv_sec))+ ((double)(t_temp.tv_usec))/((double) 1000000);

		if (t_rtt < 0){
			TFRC_DEBUG((LOG_INFO,"TFRC - Approximation of RTT is negative!\n"));
			t_rtt = -t_rtt;
		}

		t_rtt = t_rtt*4/((double)(temp));

		TFRC_DEBUG((LOG_INFO,"TFRC - Approximated rtt to "));
		PRINTFLOAT(t_rtt);
		TFRC_DEBUG((LOG_INFO, " s (tfrc_recv_calcFirstLI)\n"));

		/* Calculate x_recv */
		microtime(&t_temp);
		timevalsub(&t_temp,&(cb->t_last_feedback));
		x_recv = (((double) (cb->bytes_recv)) / 
				( ((double) t_temp.tv_sec) + ((double) t_temp.tv_usec)/1000000.0));

		TFRC_DEBUG((LOG_INFO,"TFRC - Receive rate "));
		PRINTFLOAT(x_recv);
		TFRC_DEBUG((LOG_INFO," bytes/s (tfrc_recv_calcFirstLI)\n"));

		fval = ((double)(cb->s))/(x_recv * t_rtt);
		TFRC_DEBUG((LOG_INFO,"TFRC - Fvalue to locate "));
		PRINTFLOAT(fval);
		TFRC_DEBUG((LOG_INFO," (tfrc_recv_calcFirstLI)\n"));
		fval = tfrc_flookup_reverse(fval);
		TFRC_DEBUG((LOG_INFO,"TFRC - Lookup gives p= "));
		PRINTFLOAT(fval);
		TFRC_DEBUG((LOG_INFO," (tfrc_recv_calcFirstLI)\n"));
		TFRC_DEBUG((LOG_INFO, "First interval length %u\n", (u_int32_t) (1.0/fval)));
		if (fval == 0)
			return (u_int32_t) 0xFFFFFFFF;
		return (u_int32_t) (1.0/fval);
	}

	/* Add packet to recv history (sorted on seqnum)
	 * Do not add packets that are already lost
	 * args: cb - ccb of receiver
	 *       packet - packet to insert
	 * returns:  1 if the packet was considered lost, 0 otherwise
	 * Tested u:OK
	 */
	int tfrc_recv_add_hist(struct tfrc_recv_ccb *cb, struct r_hist_entry *packet){
		struct r_hist_entry *elm,*elm2;
		u_int8_t num_later = 0, win_count;
		u_int32_t seq_num = packet->seq;
		int temp;

		TFRC_DEBUG((LOG_INFO, "TFRC - Adding packet (seq=%u,win_count=%u,type=%u,ndp=%u) to history! (tfrc_recv_add_hist)\n",packet->seq,packet->win_count,packet->type,packet->ndp));

		if (STAILQ_EMPTY(&(cb->hist))){
			STAILQ_INSERT_HEAD(&(cb->hist), packet, linfo);
		} else {
			elm = STAILQ_FIRST(&(cb->hist));
			if ((seq_num > elm->seq 
						&& seq_num-elm->seq < TFRC_RECV_NEW_SEQ_RANGE) ||
					(seq_num < elm->seq
					 && elm->seq - seq_num > DCCP_SEQ_NUM_LIMIT - TFRC_RECV_NEW_SEQ_RANGE)){
				STAILQ_INSERT_HEAD(&(cb->hist), packet, linfo);
			} else {
				if(elm->type == DCCP_TYPE_DATA || elm->type == DCCP_TYPE_DATAACK)
					num_later = 1;

				elm2 = STAILQ_NEXT(elm,linfo);
				while(elm2 != NULL){
					if ((seq_num > elm2->seq 
								&& seq_num-elm2->seq < TFRC_RECV_NEW_SEQ_RANGE) ||
							(seq_num < elm2->seq
							 && elm2->seq - seq_num > DCCP_SEQ_NUM_LIMIT - TFRC_RECV_NEW_SEQ_RANGE)){
						STAILQ_INSERT_AFTER(&(cb->hist), elm, packet, linfo);
						break;
					}
					elm = elm2;
					elm2 = STAILQ_NEXT(elm,linfo);

					if(elm->type == DCCP_TYPE_DATA || elm->type == DCCP_TYPE_DATAACK)
						num_later++;

					if (num_later == TFRC_RECV_NUM_LATE_LOSS){
						free(packet, M_TEMP);
						TFRC_DEBUG((LOG_INFO, "TFRC - Packet already lost! (tfrc_recv_add_hist)\n"));
						return 1;
						break;
					}
				}

				if(elm2 == NULL && num_later < TFRC_RECV_NUM_LATE_LOSS){
					STAILQ_INSERT_TAIL(&(cb->hist), packet, linfo);
				}
			}
		}

		/* trim history (remove all packets after the NUM_LATE_LOSS+1 data packets)*/
		if(TAILQ_FIRST(&(cb->li_hist)) != NULL){
			num_later = TFRC_RECV_NUM_LATE_LOSS+1;
			TFRC_RECV_FINDDATAPACKET(cb,elm,num_later);
			if(elm != NULL){
				elm2 = STAILQ_NEXT(elm,linfo);
				while(elm2 != NULL){
					STAILQ_REMOVE(&(cb->hist),elm2,r_hist_entry,linfo);
					free(elm2,M_TEMP);
					elm2 = STAILQ_NEXT(elm,linfo);
				}
			}
		} else {
			/* we have no loss interval history so we need at least one rtt:s of data packets to approximate rtt*/
			num_later = TFRC_RECV_NUM_LATE_LOSS+1;
			TFRC_RECV_FINDDATAPACKET(cb,elm2,num_later);
			if(elm2 != NULL){
				num_later = 1;
				TFRC_RECV_FINDDATAPACKET(cb,elm,num_later);
				win_count = elm->win_count;

				elm = elm2;
				TFRC_RECV_NEXTDATAPACKET(cb,elm2);
				while(elm2 != NULL){
					temp = win_count-(int) (elm2->win_count);
					if(temp < 0)
						temp = temp + TFRC_WIN_COUNT_LIMIT;

					if(temp > TFRC_WIN_COUNT_PER_RTT+1){
						/* we have found a packet older than one rtt
						   remove the rest */
						elm = STAILQ_NEXT(elm2,linfo);

						while(elm != NULL){
							STAILQ_REMOVE(&(cb->hist),elm,r_hist_entry,linfo);
							free(elm,M_TEMP);
							elm = STAILQ_NEXT(elm2,linfo);
						}
						break;
					}
					elm = elm2;
					TFRC_RECV_NEXTDATAPACKET(cb,elm2);
				}
			} /* end if(exist atleast 4 data packets) */
		}

		return 0;
	}

	/*
	 * Detect loss events and update loss interval history
	 * args: cb - ccb of the receiver
	 * Tested u:OK
	 */
	void tfrc_recv_detectLoss(struct tfrc_recv_ccb *cb){
		struct r_hist_entry *bLoss,*aLoss,*elm,*elm2;
		u_int8_t num_later = TFRC_RECV_NUM_LATE_LOSS;
		long seq_temp = 0;
		long seq_loss = -1;
		u_int8_t win_loss = 0;

		TFRC_RECV_FINDDATAPACKET(cb,bLoss,num_later);

		if(bLoss == NULL){
			/* not enough packets yet to cause the first loss event */
		} else {  /* bloss != NULL */
			num_later = TFRC_RECV_NUM_LATE_LOSS+1; 
			TFRC_RECV_FINDDATAPACKET(cb,aLoss,num_later);
			if (aLoss == NULL){
				if(TAILQ_EMPTY(&(cb->li_hist))){
					/* no loss event have occured yet */

					/* todo: find a lost data packet by comparing to initial seq num*/

				} else {
					panic("Less than 4 data packets in history (tfrc_recv_detecLossEvent)\n");
				}
			} else {  /* aLoss != NULL */
				/* locate a lost data packet */
				elm = bLoss;
				elm2 = STAILQ_NEXT(elm,linfo);
				do{
					seq_temp = ((long) (elm->seq)) - ((long) elm2->seq);

					if (seq_temp < 0)
						seq_temp = seq_temp + DCCP_SEQ_NUM_LIMIT;

					if(seq_temp != 1){
						/* check no data packets */
						if(elm->type == DCCP_TYPE_DATA || elm->type == DCCP_TYPE_DATAACK)
							seq_temp = seq_temp - 1;
						if(seq_temp % DCCP_NDP_LIMIT != ((int) elm->ndp - (int) elm2->ndp+DCCP_NDP_LIMIT) % DCCP_NDP_LIMIT)
							seq_loss = (elm2->seq + 1) % DCCP_SEQ_NUM_LIMIT;
					}
					elm = elm2;
					elm2 = STAILQ_NEXT(elm2,linfo);
				} while (elm != aLoss);

				if(seq_loss != -1){
					win_loss = aLoss->win_count;
				}
			}
		} /* end if(bLoss == NULL) */
		tfrc_recv_updateLI(cb,seq_loss,win_loss);
	}

	/* Updates the loss interval history
	 * cb   -  congestion control block
	 * seq_loss  -  sequence number of lost packet (-1 for none)
	 * win_loss  -  window counter for previous (from the lost packet view) packet
	 * Tested u:OK
	 */
	void tfrc_recv_updateLI(struct tfrc_recv_ccb *cb, long seq_loss, u_int8_t win_loss){
		struct r_hist_entry *elm, *elm_temp;
		struct li_hist_entry *li_elm, *li_elm2,*li_elm_temp;
		u_int8_t num_later = TFRC_RECV_NUM_LATE_LOSS;
		long seq_temp = 0;
		int i;
		u_int8_t win_start;
		int debug_info = 0;
		if(seq_loss != -1){   /* we have found a packet loss! */
			dccpstat.tfrcs_recv_losts++;
			TFRC_DEBUG((LOG_INFO, "TFRC - seqloss=%i, winloss=%i\n",(int) seq_loss, (int)win_loss));
			if(TAILQ_EMPTY(&(cb->li_hist))){
				debug_info = 1;
				/* first loss detected */
				TFRC_DEBUG((LOG_INFO, "TFRC - First loss event detected! (tfrc_recv_updateLI)\n"));
				/* create history */
				for(i=0; i< TFRC_RECV_IVAL_F_LENGTH+1; i++){
					li_elm = malloc(sizeof (struct li_hist_entry),
							M_TEMP, M_DONTWAIT | M_ZERO); /*M_TEMP??*/
					if (li_elm == NULL){
						TFRC_DEBUG((LOG_INFO, "TFRC - Not enough memory for loss interval history!\n"));
						/* Empty loss interval history */
						li_elm = TAILQ_FIRST(&(cb->li_hist));
						while (li_elm != NULL) {
							li_elm2 = TAILQ_NEXT(li_elm, linfo);
							free(li_elm, M_TEMP); /* M_TEMP ?? */
							li_elm = li_elm2;
						}
						return;
					}
					TAILQ_INSERT_HEAD(&(cb->li_hist),li_elm,linfo);
				}

				li_elm->seq = seq_loss;
				li_elm->win_count = win_loss;

				li_elm = TAILQ_NEXT(li_elm,linfo);
				/* add approx interval */
				li_elm->interval = tfrc_recv_calcFirstLI(cb);

			} else {  /* we have a loss interval history */
				debug_info = 2;
				/* Check if the loss is in the same loss event as interval start */
				win_start = (TAILQ_FIRST(&(cb->li_hist)))->win_count;
				if ((win_loss > win_start 
							&& win_loss - win_start > TFRC_WIN_COUNT_PER_RTT) ||
						(win_loss < win_start
						 && win_start - win_loss < TFRC_WIN_COUNT_LIMIT-TFRC_WIN_COUNT_PER_RTT)){
					/* new loss event detected */
					/* calculate last interval length */
					seq_temp = seq_loss - ((long) ((TAILQ_FIRST(&(cb->li_hist)))->seq));
					if (seq_temp < 0)
						seq_temp = seq_temp + DCCP_SEQ_NUM_LIMIT;

					(TAILQ_FIRST(&(cb->li_hist)))->interval = seq_temp;

					TFRC_DEBUG((LOG_INFO, "TFRC - New loss event detected!, interval %i (tfrc_recv_updateLI)\n",(int)seq_temp));
					/* Remove oldest interval */
					li_elm = TAILQ_LAST(&(cb->li_hist),li_hist_head);
					TAILQ_REMOVE(&(cb->li_hist),li_elm,linfo);

					/* Create the newest interval */
					li_elm->seq = seq_loss;
					li_elm->win_count = win_loss;

					/* insert it into history */
					TAILQ_INSERT_HEAD(&(cb->li_hist),li_elm,linfo);	
				} else
					TFRC_DEBUG((LOG_INFO, "TFRC - Loss belongs to previous loss event (tfrc_recv_updateLI)!\n"));
			}
		}

		if(TAILQ_FIRST(&(cb->li_hist)) != NULL){
			/* calculate interval to last loss event */
			num_later = 1;
			TFRC_RECV_FINDDATAPACKET(cb,elm,num_later);

			seq_temp = ((long) (elm->seq))-
				((long) ((TAILQ_FIRST(&(cb->li_hist)))->seq));
			if (seq_temp < 0)
				seq_temp = seq_temp + DCCP_SEQ_NUM_LIMIT;

			(TAILQ_FIRST(&(cb->li_hist)))->interval = seq_temp;
			if (debug_info > 0){
				TFRC_DEBUG((LOG_INFO,"TFRC - Highest data packet received %u (tfrc_recv_updateLI)\n",elm->seq));
				if(debug_info == 1)
					PRINTRCCB(cb,elm_temp,li_elm_temp);
				else if (debug_info == 2)
					PRINTLIHIST(cb,li_elm_temp);
			}
		}
	}


	/* Functions declared in struct dccp_cc_sw */
	/* Initialises the receiver side
	 * returns: pointer to a tfrc_recv_ccb struct on success, otherwise 0
	 * Tested u:OK
	 */ 
	void *tfrc_recv_init(struct dccpcb *pcb){
		struct tfrc_recv_ccb *ccb;

		ccb = malloc(sizeof (struct tfrc_recv_ccb), M_PCB, M_DONTWAIT | M_ZERO);
		if (ccb == 0){
			TFRC_DEBUG((LOG_INFO, "TFRC - Unable to allocate memory for tfrc_recv_ccb!\n"));
			return 0;
		}

		/* init recv here */

		mtx_init(&(ccb->mutex), "TFRC Receiver mutex", NULL, MTX_DEF);

		ccb->pcb = pcb;  

		if (ccb->pcb->avgpsize >= TFRC_MIN_PACKET_SIZE && ccb->pcb->avgpsize <= TFRC_MAX_PACKET_SIZE)
			ccb->s = (u_int16_t) ccb->pcb->avgpsize;
		else
			ccb->s = TFRC_STD_PACKET_SIZE;

		TFRC_DEBUG((LOG_INFO,"TFRC - Receiver is using packet size %u\n",ccb->s));

		/* init packet history */
		STAILQ_INIT(&(ccb->hist));

		/* init loss interval history */
		TAILQ_INIT(&(ccb->li_hist));

		ccb->state = TFRC_RSTATE_NO_DATA;
		TFRC_DEBUG((LOG_INFO, "TFRC receiver initialised!\n")); 
		dccpstat.tfrcs_recv_conn++;
		return ccb;
	}

	/* Free the receiver side
	 * args: ccb - ccb of recevier
	 * Tested u:OK
	 */
	void tfrc_recv_free(void *ccb){
#ifdef LINUX_FROM_BSD
		unsigned long linuxflags;
#endif
		struct r_hist_entry *elm,*elm2;
		struct li_hist_entry *li_elm,*li_elm2;
		struct tfrc_recv_ccb *cb = (struct tfrc_recv_ccb *) ccb;

		if(ccb == 0)
			panic("TFRC - Receiver ccb is null! (free)");

		/* uninit recv here */

		/* get mutex */

		cb->state = TFRC_RSTATE_TERM;
		mtx_lock(&(cb->mutex));

		/* Empty packet history */
		elm = STAILQ_FIRST(&(cb->hist));
		while (elm != NULL) {
			elm2 = STAILQ_NEXT(elm, linfo);
			free(elm, M_TEMP); /* M_TEMP ?? */
			elm = elm2;
		}
		STAILQ_INIT(&(cb->hist));

		/* Empty loss interval history */
		li_elm = TAILQ_FIRST(&(cb->li_hist));
		while (li_elm != NULL) {
			li_elm2 = TAILQ_NEXT(li_elm, linfo);
			free(li_elm, M_TEMP); /* M_TEMP ?? */
			li_elm = li_elm2;
		}
		TAILQ_INIT(&(cb->li_hist));

		mtx_unlock(&(cb->mutex));
		mtx_destroy(&(cb->mutex));

		free(ccb, M_PCB);

		TFRC_DEBUG((LOG_INFO, "TFRC receiver is destroyed\n"));
	}


	/*
	 * Tell TFRC that a packet has been received
	 * args: ccb  -  ccb block for current connection 
	 */
	void tfrc_recv_packet_recv(void *ccb, char *options, int optlen){
#ifdef LINUX_FROM_BSD
		unsigned long linuxflags;
#endif
		struct r_hist_entry *packet;
		u_int8_t win_count = 0;
		double p_prev; 
		int ins;
		struct tfrc_recv_ccb *cb = (struct tfrc_recv_ccb *) ccb;

#ifdef NOTFRCRECV
		return;  
#endif

		if(!(cb->state == TFRC_RSTATE_NO_DATA || cb->state == TFRC_RSTATE_DATA)){
			panic("TFRC - Illegal state! (tfrc_recv_packet_recv)\n");
			return;
		}

		/* Check which type */
		switch(cb->pcb->type_rcv){
			case DCCP_TYPE_ACK:
				if(cb->state == TFRC_RSTATE_NO_DATA)
					return;
				break;
			case DCCP_TYPE_DATA:
			case DCCP_TYPE_DATAACK:
				break;
			default:
				TFRC_DEBUG((LOG_INFO,"TFRC - Received not data/dataack/ack packet! (tfrc_recv_packet_recv)"));
				return;
		}

		mtx_lock(&(cb->mutex));

		/* Add packet to history */

		packet = malloc(sizeof (struct r_hist_entry), M_TEMP, M_DONTWAIT); /*M_TEMP??*/
		if (packet == NULL){
			TFRC_DEBUG((LOG_INFO,"TFRC - Not enough memory to add received packet to history (consider it lost)! (tfrc_recv_packet_recv)"));
			dccpstat.tfrcs_recv_nomem++;
			goto rp_release;
		}

		microtime(&(packet->t_recv));
		packet->seq = cb->pcb->seq_rcv;
		packet->type = cb->pcb->type_rcv;
		packet->ndp = cb->pcb->ndp_rcv;

		ins = dccp_get_option(options, optlen, TFRC_OPT_WINDOW_COUNT, (char *)&win_count,1);

		if((packet->type == DCCP_TYPE_DATA || packet->type == DCCP_TYPE_DATAACK) &&
				(ins != 1)){
			TFRC_DEBUG((LOG_INFO,"TFRC - No window counter (size %i) option on data packet! (consider it lost)! (tfrc_recv_packet_recv)",ins));
			free(packet,M_TEMP);
			dccpstat.tfrcs_recv_noopt++;
			goto rp_release;
		}

		packet->win_count = win_count;

		ins = tfrc_recv_add_hist(cb,packet);

		/* check if we got a data packet */
		if (cb->pcb->type_rcv != DCCP_TYPE_ACK){

			switch (cb->state){
				case TFRC_RSTATE_NO_DATA :
					TFRC_DEBUG((LOG_INFO, "TFRC - Send an inital feedback packet (tfrc_recv_packet_recv)\n"));
					tfrc_recv_send_feedback(cb);
					cb->state = TFRC_RSTATE_DATA;
					break;
				case TFRC_RSTATE_DATA : 
					cb->bytes_recv = cb->bytes_recv + cb->pcb->len_rcv;
					if(!ins){
						/* find loss event */
						tfrc_recv_detectLoss(cb);
						p_prev = cb->p;

						/* Calculate loss event rate */
						if(!TAILQ_EMPTY(&(cb->li_hist))){
							cb->p = 1/tfrc_calcImean(cb);
						}  
						/* check send conditions then send */
						if(cb->p > p_prev){
							TFRC_DEBUG((LOG_INFO, "TFRC - Send a feedback packet because p>p_prev (tfrc_recv_packet_recv)\n"));
							tfrc_recv_send_feedback(cb);
						} else {
							if ((cb->pcb->seq_rcv > cb->seq_last_counter 
										&& cb->pcb->seq_rcv - cb->seq_last_counter < TFRC_RECV_NEW_SEQ_RANGE) ||
									(cb->pcb->seq_rcv < cb->seq_last_counter
									 && cb->seq_last_counter - cb->pcb->seq_rcv > DCCP_SEQ_NUM_LIMIT - TFRC_RECV_NEW_SEQ_RANGE)){

								/* the sequence number is newer than seq_last_count */
								if ((win_count > cb->last_counter 
											&& win_count-cb->last_counter > TFRC_WIN_COUNT_PER_RTT) ||
										(win_count < cb->last_counter
										 && cb->last_counter - win_count < TFRC_WIN_COUNT_LIMIT-TFRC_WIN_COUNT_PER_RTT)){

									TFRC_DEBUG((LOG_INFO, "TFRC - Send a feedback packet (%i)(win_count larger) (tfrc_recv_packet_recv)\n",(win_count-cb->last_counter+TFRC_WIN_COUNT_LIMIT) % TFRC_WIN_COUNT_LIMIT));

									tfrc_recv_send_feedback(cb);
								}
							}  /* end newer seqnum */
						}  /* end p > p_prev */

					}
					break;
				default:
               /*shuld this realy be a panic? (BJORN)*/
					panic("tfrc_recv_packet_recv: Illegal state!");
					break;
			}

		} /* end if not pure ack */
rp_release:
		mtx_unlock(&(cb->mutex)); 
	}
