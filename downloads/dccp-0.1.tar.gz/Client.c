#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h> /* memset() */
#include <sys/time.h> /* select() */ 
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>

#include <asm/page.h> /*PAGE_SIZE*/

struct dcp_rateinfo 
{
	double rate;
};


#define REMOTE_SERVER_PORT 1502
#define SOCK_DCCP 6

	static void 
timevalfix(struct timeval *t1)
{

	if (t1->tv_usec < 0) {
		t1->tv_sec--;
		t1->tv_usec += 1000000;
	}
	if (t1->tv_usec >= 1000000) {
		t1->tv_sec++;
		t1->tv_usec -= 1000000;
	}
}
	void
timevalsub(struct timeval *t1, struct timeval *t2)
{

	t1->tv_sec -= t2->tv_sec;
	t1->tv_usec -= t2->tv_usec;
	timevalfix(t1);
}


struct datapack
{
    int nr;
    char dumb[1436];
};


int main(int argc, char *argv[]) {

	int sd, rc, i, bbb;
	struct sockaddr_in cliAddr, remoteServAddr;
	struct hostent *h;
   struct datapack dp;
   int wait;
	
	struct timeval t1,t2;
	struct timezone tz; 
#ifdef DCCP
	struct dcp_rateinfo *ri;
#endif

	/* check command line args */
	if(argc<2) {
		printf("usage : %s <server> \n", argv[0]);
		exit(1);
	}

	
	/* get server IP address (no check if input is IP address or DNS name */
	h = gethostbyname(argv[1]);
	if(h==NULL) {
		printf("%s: unknown host '%s' \n", argv[0], argv[1]);
		exit(1);
	}

	printf("%s: trying to connect to '%s' (IP : %s) \n", argv[0], h->h_name,
			inet_ntoa(*(struct in_addr *)h->h_addr_list[0]));

	remoteServAddr.sin_family = h->h_addrtype;
	memcpy((char *) &remoteServAddr.sin_addr.s_addr, 
			h->h_addr_list[0], h->h_length);
	remoteServAddr.sin_port = htons(REMOTE_SERVER_PORT);

	/* socket creation */
#ifdef DCCP
	sd = socket(AF_INET,SOCK_DCCP,0);
#else
#ifdef UDP
	sd = socket(AF_INET,SOCK_DGRAM,0);
#else
	sd = socket(AF_INET,SOCK_STREAM,0);
#endif
#endif

	
	if(sd<0) {
		printf("%s: cannot open socket \n",argv[0]);
		exit(1);
	}

	/* bind any port */
	cliAddr.sin_family = AF_INET;
	cliAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	cliAddr.sin_port = 12322;//htons(0);

   printf("%s: socket not yet connected\n", argv[0]);
   
   rc=connect(sd, (struct sockaddr *) &remoteServAddr,sizeof(remoteServAddr));

	
	if (rc < 0)
	{
		printf("%s: socket cannot connect (%s) \n ", argv[0], strerror(errno));
		exit(1);
	}
   else
       printf("%s: socket connected\n",argv[0]);

   
#ifdef DCCP
       ri=(struct dcp_rateinfo *) mmap(NULL,PAGE_SIZE,PROT_READ,MAP_PRIVATE,sd,0);

	if (ri == MAP_FAILED)
	{

		printf("%s: cannot mmap  %s \n ", argv[0],strerror(errno));
		exit(1);

	}
#endif
	/* send data after 3 sec.*/
	sleep(3);
   bbb=0;
   for(i=0; ; ) { 
		gettimeofday(&t1, &tz);
      dp.nr = i;
      rc = send(sd,&dp, sizeof(struct datapack), 0);

		gettimeofday(&t2, &tz);
		if(rc<1) {
			bbb++;
			usleep(1);
		}
		else
		{
        #ifdef DCCP
         wait = ((sizeof(struct datapack)/(ri->rate))*1000)/10;// ms to wait befor next send.
         wait *= 10;
         
			timevalsub(&t2,&t1);
         if(i%1 == 0)
				printf("%d (%d) call took %ld . %.6ld tfrc says we can use rate: %f (%d ms)\n",i,bbb,t2.tv_sec,t2.tv_usec, ri->rate,wait);
			#else
            if(i%1 == 0)
    				printf("%d (%d) call took %ld . %.6ld\n",i,bbb,t2.tv_sec,t2.tv_usec );
			#endif
			bbb=0;
			i++;

         
		}
	}
	sleep(3);
   close(sd);
	return 1;
}

