#! /bin/bash
gcc $1.c -Wall -o$1 -DDCCP -g
