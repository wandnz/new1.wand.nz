#ifndef _COMPAT_H_
#define _COMPAT_H_
//#include <asm/types.h>

#define LINUX_FROM_BSD

#include <linux/time.h>
#include <linux/timer.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <asm/semaphore.h>
#include <linux/spinlock.h>

#define DCCP_MAP_SIZE	PAGE_SIZE	

//#define DCCP_TPYE_ACK 3
#define DCCP_TYPE_REQUEST        0
#define DCCP_TYPE_RESPONSE       1
#define DCCP_TYPE_DATA           2
#define DCCP_TYPE_ACK            3
#define DCCP_TYPE_DATAACK        4
#define DCCP_TYPE_CLOSEREQ       5
#define DCCP_TYPE_CLOSE          6
#define DCCP_TYPE_RESET          7
#define DCCP_TYPE_MOVE           8
#define DCCP_SEQ_NUM_LIMIT      16777216


#define DCCP_NDP_LIMIT          16


#define M_TEMP 0
#define M_DONTWAIT 1
#define M_PCB 0
#define M_ZERO 0x2

#define mtx spinlock_t//semaphore
#define mtx_init(x,y,z,a) spin_lock_init(x)//SPIN_LOCK_UNLOCKED//init_MUTEX(x)
#define mtx_lock(x) spin_lock_irqsave(x,linuxflags)// down_interruptible(x)
#define mtx_unlock(x) spin_unlock_irqrestore(x,linuxflags)//up(x)
#define mtx_destroy(x)

#define malloc(x,y,z) mykmalloc(x,y,z)
#define free(x,y) kfree(x)
#define u_int32_t unsigned int //__u32 //uint32_t
#define u_int8_t unsigned char //__u8 //uint8_t
#define hz HZ

#define dccpcb dcp_opt

#define callout_handle timer_list

int dccp_get_option(char *options, int optlen, int type, char *buffer, int buflen);

/* static void jiffiestotv(unsigned long jiffies, struct timeval *value)
{
	value->tv_usec = (jiffies % HZ) * (1000000 / HZ);
	value->tv_sec = jiffies / HZ;
	return;
} flagged by compiler as not used */

//#define microtime(x) jiffiestotv(jiffies,x) 
#define microtime(x) do_gettimeofday(x)	

//My fbsd->linux malloc
//
void * mykmalloc(unsigned long size, void * flagsone, int flagstwo)
{
	void *ptr;
	if ((flagstwo & M_DONTWAIT))
	{
		ptr=kmalloc(size, GFP_ATOMIC);

	}
	else
	{
		ptr=kmalloc(size, GFP_KERNEL);

	}
	if (ptr !=NULL)
	{
		if((flagstwo & M_ZERO) != 0)
		{
			//zero it 
			memset(ptr,0,size);
		}
	}
	return ptr;

}

//#taken from FreeBSD
/*
 * Copyright (c) 1982, 1986, 1989, 1993
 *      The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the University of
 *      California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *      @(#)kern_time.c 8.1 (Berkeley) 6/10/93
 * $FreeBSD: src/sys/kern/kern_time.c,v 1.73 2001/05/01 08:12:57 markm Exp $
 */
#define timevalcmp(tvp, uvp, cmp)                                       \
(((tvp)->tv_sec == (uvp)->tv_sec) ?                             \
 ((tvp)->tv_usec cmp (uvp)->tv_usec) :                       \
 ((tvp)->tv_sec cmp (uvp)->tv_sec))

//#define printk noprintk


/*void printk(char *e, ...)
{

}*/
static void 
timevalfix(struct timeval *t1)
	//	struct timeval *t1;
{

	if (t1->tv_usec < 0) {
		t1->tv_sec--;
		t1->tv_usec += 1000000;
	}
	if (t1->tv_usec >= 1000000) {
		t1->tv_sec++;
		t1->tv_usec -= 1000000;
	}
}
	void
timevalsub(struct timeval *t1, struct timeval *t2)
	/* [<][>][^][v][top][bottom][index][help] */
	//	struct timeval *t1, *t2;
{

	t1->tv_sec -= t2->tv_sec;
	t1->tv_usec -= t2->tv_usec;
	timevalfix(t1);
}

	void
timevaladd(struct timeval *t1, struct timeval *t2)
	/* [<][>][^][v][top][bottom][index][help] */
	//struct timeval *t1, *t2;
{

	t1->tv_sec += t2->tv_sec;
	t1->tv_usec += t2->tv_usec;
	timevalfix(t1);
}

//To de defined/fixed
//

//This should send a packet?
int
dccp_output(register struct dccpcb *dp, u_int8_t extra );

#ifndef eeeepeeeee
#define do_weird_debug(a,b, ...)  printk(b ,## __VA_ARGS__)
//#define do_weird_debug(a,b,...args) { printk(fmt, args)};
#else
void do_weird_debug(int level, char *fmt, ...)
{
	char buffer[100];
	va_list args;
	va_start(args, fmt);
	vsprintf(buffer, fmt, args);
	va_end(args);
	printk("%s",buffer);
}
#endif


struct	dccpstat {
	u_long	dccps_connattempt;	/* Initiated connections */
	u_long	dccps_connects;		/* Established connections */
	u_long	dccps_ipackets;		/* Total input packets */
	u_long	dccps_ibytes;		/* Total input bytes */
	u_long	dccps_drops;		/* Dropped packets  */
	u_long	dccps_badsum;		/* Checksum error */
	u_long	dccps_badlen;		/* Bad length */
	u_long	dccps_badseq;		/* Sequence number not inside loss_window  */
	u_long	dccps_noport;		/* No socket on port */

	/* TFRC Sender */
	u_long  tfrcs_send_conn;        /* Number of conn used TFRC sender */
	u_long  tfrcs_send_noopt;       /* No options on feedback packet */
	u_long  tfrcs_send_nomem;       /* Send refused: No mem for history */
	u_long  tfrcs_send_fbacks;      /* Correct feedback packets received */
	u_long  tfrcs_send_erropt;      /* Err add option on data */

	/* TFRC Receiver */
	u_long  tfrcs_recv_conn;        /* Number of conn used TFRC receiver */
	u_long  tfrcs_recv_noopt;       /* Packet lost: No options on packet */
	u_long  tfrcs_recv_nomem;       /* Packet lost: No mem for history */
	u_long  tfrcs_recv_losts;       /* Detected lost packets */
	u_long  tfrcs_recv_fbacks;      /* Feedback packets sent */
	u_long  tfrcs_recv_erropt;      /* Err add option on feedback */      

	/* TCPlike Sender */
	u_long  tcplikes_send_conn;     /* Connections established */
	u_long  tcplikes_send_reploss;  /* Data packets reported lost */
	u_long  tcplikes_send_assloss;  /* Data packets assumed lost */
	u_long  tcplikes_send_ackrecv;  /* Acknowledgement (w/ Ack Vector) packets received */
	u_long  tcplikes_send_missack;  /* Ack packets assumed lost */
	u_long  tcplikes_send_badseq;   /* Bad sequence number on outgoing packet */
	u_long  tcplikes_send_memerr;   /* Memory allocation errors */

	/* TCPlike Receiver */
	u_long  tcplikes_recv_conn;     /* Connections established */
	u_long  tcplikes_recv_datarecv; /* Number of data packets received */
	u_long  tcplikes_recv_ackack;   /* Ack-on-acks received */
	u_long  tcplikes_recv_acksent;  /* Acknowledgement (w/ Ack Vector) packets sent */
	u_long  tcplikes_recv_memerr;   /* Memory allocation errors */

	/*	Some CCID statistic should also be here */

	u_long	dccps_opackets;		/* Total output packets */
	u_long	dccps_obytes;		/* Total output bytes */
};

#ifndef DCCP_STAT_EXTERN 
#define DCCP_STAT_EXTERN extern
#endif

struct dccpstat dccpstat;
#endif
