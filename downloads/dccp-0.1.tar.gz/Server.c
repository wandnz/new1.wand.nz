#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>
#include <unistd.h> /* close() */
#include <string.h> /* memset() */
#include <errno.h>

#define LOCAL_SERVER_PORT 1502
#define MAX_MSG 10000
#define SOCK_DCCP 6

int main(int argc, char *argv[]) {

	int sd,sd2, rc, n, i;
	struct sockaddr_in cliAddr, servAddr;
	socklen_t cliLen;
	char msg[MAX_MSG];
   int last;

	/* socket creation */
   	/* sd = socket descriptor */
#ifdef DCCP
	sd = socket(AF_INET,SOCK_DCCP,0);
#else
#ifdef UDP
	sd = socket(AF_INET,SOCK_DGRAM,0);
#else
	sd = socket(AF_INET,SOCK_STREAM,0);
#endif
#endif
	if(sd<0) {
		printf("%s: cannot open socket \n",argv[0]);
		exit(1);
	}

	/* bind local server port */
	servAddr.sin_family = AF_INET;
	servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servAddr.sin_port = htons(LOCAL_SERVER_PORT);
	rc = bind (sd, (struct sockaddr *) &servAddr,sizeof(servAddr));
	if(rc<0) {
		printf("%s: cannot bind port number %d \n", 
				argv[0], LOCAL_SERVER_PORT);
		exit(1);
	}

	printf("%s: waiting for data on port %u\n", 
			argv[0],LOCAL_SERVER_PORT);

	
	sd2 = sd;
#ifdef UDP
//#else
//#ifdef DCCP
#else
	rc = listen(sd,1);
   
	if (rc < 0)
	{
		if(errno ==  EADDRINUSE)
			printf("Another socket is already  listening.\n");
		else if(errno == EBADF)
			printf("The argument sd is not a valid descriptor.\n");
		else if(errno == ENOTSOCK)
			printf("The argument sd is not a socket.\n");
		else if(errno == EOPNOTSUPP)
			printf("The  socket does not supports listen.\n");
		else
			printf("rc < 0\n");
	}

   cliLen=sizeof(cliAddr); //maybe???
   sd2 = accept(sd,(struct sockaddr *)&cliAddr,&cliLen);

//#endif
#endif
	
	/* server infinite loop */
   last = i = 0;
	while(1) {

		n = recv(sd2,msg,MAX_MSG,0);
      
		if(n<0) {
			printf("%s: cannot receive data \n",argv[0]);
         close(sd2);
			exit(0);
		}
      else if(n == 0) {
          usleep(1);
      }

		/* print received message */
      else if(n > 0) {
#ifdef DCCP
          if(last < ((((int*)msg)[0])-1))
              printf("Dropped %d messages.\n",((int*)msg)[0]-last);
          if(((int*)msg)[0]%1==0)
              printf("recvd: %d (%d)\n",((int*)msg)[0],n);
#else
          i++;
          if(i%1 == 0)
              printf("recvd: %d (%d)\n",((int*)msg)[0],n);
#endif
      }
        last = ((int*)msg)[0];
	}/* end of server infinite loop */

	return 0;

}
