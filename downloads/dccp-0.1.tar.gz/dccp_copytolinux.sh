#! /bin/bash

SRC=$1
DEST=$2
cp $SRC/dcp.c $DEST/net/ipv4/
cp $SRC/dccp* $DEST/net/ipv4/
cp $SRC/compat.h $DEST/net/ipv4/
cp $SRC/queue.h $DEST/net/ipv4/
cp $SRC/sock.h $DEST/include/net/
cp $SRC/af_inet.c $DEST/net/ipv4/
cp $SRC/socket.h $DEST/include/linux/
cp $SRC/asmumarchsocket.h $DEST/include/asm-i386/socket.h
cp $SRC/netsyms.c $DEST/net/
cp $SRC/Makefile $DEST/net/ipv4/
cp $SRC/Config.in $DEST/net/ipv4/
