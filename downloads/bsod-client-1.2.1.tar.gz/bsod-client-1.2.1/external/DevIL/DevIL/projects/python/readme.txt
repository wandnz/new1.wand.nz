The test program require Pygame and PyOpenGL to work but 
you don't need them to use the library. You can find the 
needed package at:

Pygame   - http://www.pygame.org
PyOpenGL - http://pyopengl.sourceforge.net

