void func()
{
    static int sl_self_ref = sizeof(sl_self_ref);
}
