struct tvec_base_s;

extern struct tvec_base_s boot_tvec_bases;

struct tvec_base_s *base = &boot_tvec_bases;
