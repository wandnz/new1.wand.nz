
struct Sam
{
    int a;
};

struct Sam my_struct = (struct Sam) { 1, };
