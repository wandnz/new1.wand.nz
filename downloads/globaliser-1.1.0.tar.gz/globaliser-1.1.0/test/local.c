static int ip6_dst_gc()
{
        static unsigned long last_gc;

        last_gc = 1;
        
        return 0;
}

