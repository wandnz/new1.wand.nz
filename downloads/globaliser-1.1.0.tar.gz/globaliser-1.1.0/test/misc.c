typedef struct { unsigned long bits[(((1)+32 -1)/32)]; } cpumask_t;

void func()
{
  cpumask_t cspan;

  cspan = (cpumask_t) { { [0 ... (((1)+32 -1)/32) -1] = 0UL } };
}
