LD_LIBRARY_PATH=./external/DevIL/lib $1 ./bsod-client
