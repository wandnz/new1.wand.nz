/*
Copyright (c) Sam Jansen and Jesse Baker.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

3. The end-user documentation included with the redistribution, if
any, must include the following acknowledgment: "This product includes
software developed by Sam Jansen and Jesse Baker 
(see http://www.wand.net.nz/~stj2/bung)."
Alternately, this acknowledgment may appear in the software itself, if
and wherever such third-party acknowledgments normally appear.

4. The hosted project names must not be used to endorse or promote
products derived from this software without prior written
permission. For written permission, please contact sam@wand.net.nz or
jtb5@cs.waikato.ac.nz.

5. Products derived from this software may not use the "Bung" name
nor may "Bung" appear in their names without prior written
permission of Sam Jansen or Jesse Baker.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL COLLABNET OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
// $Id: sdl_net_driver.cpp,v 1.6 2005/01/25 01:19:17 sjd18 Exp $
#include "stdafx.h"
#include "world.h"
#include "net_driver.h"
#include "exception.h"
#include "entity_manager.h"
#include "player.h"
#include "partvis.h"
#include "misc.h"

#include <SDL.h>
#include <SDL_net.h>

#include "sdl_net_driver.h"

CNetDriver *CNetDriver::Create()
{
    return new CSDLNetDriver();
}
////////////////////////////////////////////////////////////////////////
CSDLNetDriver::CSDLNetDriver()
{
    // Assumes SDL_Init() has been called
    if(SDLNet_Init() == -1)
	throw CException(SDLNet_GetError());
}

CSDLNetDriver::~CSDLNetDriver()
{
    SDLNet_Quit();
}


void CSDLNetDriver::Connect(string address)
{
    string::size_type c = address.find(':', 0);
    string host = address.substr(0, c);
    string port = address.substr(c+1, string::npos);
    IPaddress ip;

    Log("Connecting to Host: '%s' Port: '%s'\n", host.c_str(), port.c_str());
    
    if(SDLNet_ResolveHost(&ip, (char *)host.c_str(), 
		(unsigned short)atoi(port.c_str())) == -1) {
        // Note: SDLNet_GetError() doesn't seem to say anything useful here.
	throw CException(bsprintf("Error: Unable to resolve host '%s'",
                    host.c_str()));
    }

    clientsock = SDLNet_TCP_Open(&ip);

    if(!clientsock)
	throw CException(bsprintf("Unable to connect to server '%s': '%s'",
                    host.c_str(), SDLNet_GetError()));

    set = SDLNet_AllocSocketSet(16);
    if(!set)
	throw CException(SDLNet_GetError());

    if(SDLNet_TCP_AddSocket(set, clientsock) == -1)
	throw CException(SDLNet_GetError());
    
    Log("Connected!\n");
    
}

void CSDLNetDriver::SendData(CPlayer *p)
{
    throw CException("CSDLNetDriver::SendData: This function is currently not"
	    " implemented!");
}

#ifdef _WIN32
#pragma pack(push)
#pragma pack(1)
#define PACKED
#else
#define PACKED __attribute__((packed))
#endif

struct flow_update_t {
    unsigned char type; // 0
    float x1;
    float y1;
    float z1;
    float x2;
    float y2;
    float z2;
    unsigned int id;
} PACKED;

struct pack_update_t {
    unsigned char type; // 1
    uint32 ignored, ts;
    unsigned int id;
    unsigned char colour[3];
    unsigned short size;
    float speed;
} PACKED;

struct flow_remove_t {
    unsigned char type; // 2
    unsigned int id;
} PACKED;

union fp_union {
    struct flow_update_t flow;
    struct pack_update_t packet;
    struct flow_remove_t rem;
};

#ifdef _WIN32
#pragma pack(pop)
#endif

//#define NET_DEBUG

void CSDLNetDriver::ReceiveData()
{
	byte buffer[1024];
	int  readlen;
	union fp_union *fp;

	while(SDLNet_CheckSockets(set, 0) > 0)
	{
		if((readlen = SDLNet_TCP_Recv(clientsock, buffer, 1024)) > 0)
		{
			int sam = databuf.size();
			databuf.resize( sam + readlen );
			memcpy(&databuf[sam], buffer, readlen);

#ifdef NET_DEBUG
			Log("Read %d bytes\n", readlen);
#endif
		}
		if(readlen == 0)
			break;
	}

	// Log("Databuf.size()=%d\n", databuf.size());
	world.partVis->BeginUpdate();

	unsigned char *buf = &databuf[0];
	while(true) {
		const unsigned int s = &databuf[databuf.size()] - &buf[0];
		fp = (fp_union *)buf;
		if(s == 0) {
			databuf.erase(databuf.begin(), databuf.end());
			break;
		}
		if(fp->flow.type == 0x00) {
			// Flow
			if(sizeof(flow_update_t) <= s) {
#ifdef NET_DEBUG
				Log("Flow: (%f,%f,%f)->(%f,%f,%f):%u\n", 
				fp->flow.x1,
				fp->flow.y1,
				fp->flow.z1,
				fp->flow.x2,
				fp->flow.y2,
				fp->flow.z2,
				fp->flow.id);
#endif

				world.partVis->UpdateFlow(
					fp->flow.id,
					Vector3f(fp->flow.x1, fp->flow.y1, fp->flow.z1),
					Vector3f(fp->flow.x2, fp->flow.y2, fp->flow.z2));

				buf += sizeof(flow_update_t);
			} else {
				if(buf != &databuf[0])
					databuf.erase(databuf.begin(), databuf.begin() 
					+ (buf - &databuf[0]));
				break;
			}
		} else if(fp->flow.type == 0x01) {
			// Packet
			if(sizeof(pack_update_t) <= s) {
#ifdef NET_DEBUG
				Log("Packet: ts:%u id:%u (%d,%d,%d) size:%u\n",
				fp->packet.ts,
				fp->packet.id,
				(int)fp->packet.colour[0],
				(int)fp->packet.colour[1],
				(int)fp->packet.colour[2],
				fp->packet.size);
#endif

				world.partVis->UpdatePacket(
					fp->packet.id, fp->packet.ts,
					fp->packet.colour[0],
					fp->packet.colour[1],
					fp->packet.colour[2],
					fp->packet.size,
					fp->packet.speed);

				buf += sizeof(pack_update_t);
			} else {
				if(buf != &databuf[0])
					databuf.erase(databuf.begin(), databuf.begin() 
					+ (buf - &databuf[0]));
				break;
			}
		} else if(fp->flow.type == 0x02) {
			if(sizeof(flow_remove_t) <= s) {
				world.partVis->RemoveFlow(fp->rem.id);

				buf += sizeof(flow_remove_t);
			} else {
				if(buf != &databuf[0])
					databuf.erase(databuf.begin(), databuf.begin() 
					+ (buf - &databuf[0]));
				break;
			}
		} else {
			Log("Unknown packet type...s:%u r:%u d:%u \n",
				databuf.size(), 
				(int)(buf-&databuf[0]), 
				(int)(&databuf[databuf.size()]-buf)
				);
			databuf.erase(databuf.begin(), databuf.end());
			break;
		}
	}

	world.partVis->EndUpdate();
}
