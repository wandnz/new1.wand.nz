/*
Copyright (c) Sam Jansen and Jesse Baker.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

3. The end-user documentation included with the redistribution, if
any, must include the following acknowledgment: "This product includes
software developed by Sam Jansen and Jesse Baker 
(see http://www.wand.net.nz/~stj2/bung)."
Alternately, this acknowledgment may appear in the software itself, if
and wherever such third-party acknowledgments normally appear.

4. The hosted project names must not be used to endorse or promote
products derived from this software without prior written
permission. For written permission, please contact sam@wand.net.nz or
jtb5@cs.waikato.ac.nz.

5. Products derived from this software may not use the "Bung" name
nor may "Bung" appear in their names without prior written
permission of Sam Jansen or Jesse Baker.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL COLLABNET OR ITS CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
// $Id: config.cpp,v 1.7 2006/06/28 23:26:29 perry Exp $
#include "stdafx.h"
#include "exception.h"
#include "config.h"
#include "vfs.h"
#include "misc.h"

void CConfig::ParseFile(string fileName)
{
	CXMLParser parser;
	CReader *reader = CVFS::LoadFile(fileName);

	parser.Parse( reader, this );

	delete reader;
}

void CConfig::BeginTagFunc(const string &tag, const map<string, string, string_less> &attrs)
{
	map<string, string, string_less>::const_iterator i = attrs.begin();
	for(; i != attrs.end(); ++i)
	{
		Attribute at;
		at.value = (*i).second;

		attrMap[ (*i).first ] = at;
	}
}

void CConfig::EndTagFunc(const string &contents)
{
}

void CConfig::ParseAttr(Attribute &attr)
{
	attr.parsed = true;
	
	if( attr.value.length() == 0 )
		return;
	
	attr.intVal = atoi( attr.value.c_str() );
	attr.floatVal = (float)atof( attr.value.c_str() );
	
	string boolCheck = attr.value;
	uint32 i = 0;
	while(i < boolCheck.size()) {
		boolCheck[i] = tolower(boolCheck[i]);
		i++;
	}
	
	if(boolCheck == "true" || boolCheck == "yes")
		attr.boolVal = true;
	else
		attr.boolVal = false;
	
	sscanf( attr.value.c_str(), "(%f,%f,%f)", &attr.vector3fVal.x, 
		&attr.vector3fVal.y, &attr.vector3fVal.z);
}

bool CConfig::GetBoolean(const string attr)
{
	map<string, Attribute>::iterator i = attrMap.find(attr);
	
	if(i == attrMap.end()) {
		throw CException(CReporter::R_WARNING, bsprintf("GetBoolean('%s') failed.", attr.c_str()));
	} else {
		if( !(*i).second.parsed )
		{
			// Lazy evaluation: only parse if needed!
			ParseAttr((*i).second);
		}
	
		return (*i).second.boolVal;
	}
}

int CConfig::GetInt(const string attr)
{
	map<string, Attribute>::iterator i = attrMap.find(attr);
	
	if(i == attrMap.end()) {
		throw CException(CReporter::R_WARNING, bsprintf("GetInt('%s') failed.", attr.c_str()));
	} else {
		if( !(*i).second.parsed )
		{
			// Lazy evaluation: only parse if needed!
			ParseAttr((*i).second);
		}
	
		return (*i).second.intVal;
	}
}

float CConfig::GetFloat(const string attr)
{
	map<string, Attribute>::iterator i = attrMap.find(attr);
	
	if(i == attrMap.end()) {
		throw CException(CReporter::R_WARNING, bsprintf("GetFloat('%s') failed.", attr.c_str()));
	} else {
		if( !(*i).second.parsed )
		{
			// Lazy evaluation: only parse if needed!
			ParseAttr((*i).second);
		}
	
		return (*i).second.floatVal;
	}
}

Vector3f CConfig::GetVector3f(const string attr)
{
	map<string, Attribute>::iterator i = attrMap.find(attr);
	
	if(i == attrMap.end()) {
		throw CException(CReporter::R_WARNING, bsprintf("GetVector3f('%s') failed.", attr.c_str()));
	} else {
		if( !(*i).second.parsed )
		{
			// Lazy evaluation: only parse if needed!
			ParseAttr((*i).second);
		}
	
		return (*i).second.vector3fVal;
	}
}

string CConfig::GetString(const string attr)
{
	map<string, Attribute>::iterator i = attrMap.find(attr);
	
	if(i == attrMap.end()) {
		throw CException(CReporter::R_WARNING, bsprintf("GetString('%s') failed.", attr.c_str()));
	} else {
		return (*i).second.value;
	}
}
