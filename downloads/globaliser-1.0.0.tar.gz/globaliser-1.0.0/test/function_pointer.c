void (*func1)(void);

void (*func2)(void) = 0;

void (*func3[2])(void);

void (*func4[2])(void) = { 0, 0 };

int (*func5)(int, char, char **) = 0;

typedef int (*GLOBAL_func5_T)(int a, char b, char **c);

void stuff()
{
    func1 = func2;

    func3[0] = func4[0];
}
