int my_glob = sizeof(my_glob);
