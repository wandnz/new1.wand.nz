#define NULL (void *)0

extern long mtus[];

int array[10];

typedef void (*func)(int);

func array2[2] = { NULL, NULL };
