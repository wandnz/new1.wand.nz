/* Wand Project - Ethernet Over UDP
 * $Id: daemons.h,v 1.1 2004/10/13 21:44:02 dlawson Exp $
 * Licensed under the GPL, see file COPYING in the top level for more
 * details.
 */
    
#ifndef DAEMONS_H
#define DAEMONS_H

// $Id: daemons.h,v 1.1 2004/10/13 21:44:02 dlawson Exp $

#ifdef __cplusplus
extern "C" {
#endif


void put_pid( char *fname );
void daemonise( char *name, int ch ) ;

extern int daemonised;

#ifdef __cplusplus
}
#endif

#endif /* DEAMONS_H */
    
