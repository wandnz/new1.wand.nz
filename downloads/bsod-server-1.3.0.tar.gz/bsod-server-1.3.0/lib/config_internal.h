#ifndef config_internal
#define config_internal

int set_config_int(char *key,int value);
int set_config_str(char *key,char *value);

#endif
