/*
 * This file is part of bsod-server
 *
 * Copyright (c) 2004 The University of Waikato, Hamilton, New Zealand.
 * Authors: Brendon Jones
 *	    Daniel Lawson
 *	    Sebastian Dusterwald
 *          
 * All rights reserved.
 *
 * This code has been developed by the University of Waikato WAND 
 * research group. For further information please see http://www.wand.net.nz/
 *
 * bsod-server is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * bsod-server is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with bsod-server; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Id: colours.h,v 1.6 2005/04/06 05:31:43 perry Exp $
 *
 */

#ifndef _COLOURS_H
#define _COLOURS_H

#include <stdint.h>
/** get_colour() accepts an array of 3 chars, and the IP protocol 
 *  and TCP or UDP port value. It then makes "a decision" on these two 
 *  parameters, and fills in the color array with appropriate RGB values.
 */

extern "C" {
int mod_get_colour(unsigned char *id_num, struct libtrace_packet_t *packet);
void mod_get_info(uint8_t colours[3], char name[256], int id );
}


#endif // _COLOURS_H
