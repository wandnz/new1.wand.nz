#ifndef NETLINK_H
#define NETLINK_H

int init_netlink(void);

#endif
